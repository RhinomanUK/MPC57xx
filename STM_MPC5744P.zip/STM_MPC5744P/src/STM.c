/*
 * STM.c
 *
 * System Timer Module routines for SPC57xx and MPC57xx
 * SPC572L and MPC5744 have one 32-bit timer
 * with four compare channels
 *
  * v0.1
 * 27th October 2021
 * J Holland
 * copyright RhinoPower Ltd - all rights reserved
 */

/*****************************************************************************
Notes:
The STM registers can only be accessed using 32-bit (word) accesses. Attempted
references using a different size or to a reserved address generates a bus error
termination.
The STM is clocked from the PBRIDGE? clock, max. freq is 50MHz

*****************************************************************************/

#include "project.h"


void STM_begin( uint8_t sysClkDivider )
{
	uint32_t temp = 3; // FRZ=1, TEN=1

	temp |= (sysClkDivider << 8);		// CPS = bits[15-8]
	STM_0.CR.R = temp;
	
}

/*****************************************************************************/

void STM_stop( void )
{
	uint32_t temp;

	temp = STM_0.CR.R;
	temp &= 0xFFFFFFFE;			// TEN=0
	STM_0.CR.R = temp;
}


/*****************************************************************************/


uint32_t STM_currentTime( void )
{

	return STM_0_CNT;					// return the current count

}

/*****************************************************************************/

void STM_attachInterrupt( uint8_t Channel, uint32_t count )
{
	
	switch(Channel){
		case 0:	INTC_0.PSR[36].B.PRC_SELN0 = 1;  	/* IRQ sent to Core 0 */
				INTC_0.PSR[36].B.PRIN =10;       	/* IRQ priority = 10 (15 = highest) */
				STM_0_CIR0 = 1;						// clear any pending interrupt
				STM_0_CMP0 = count;					// set up compare register
				STM_0_CCR0 = 1;						// enable counter
				break;
		case 1:	INTC_0.PSR[37].B.PRC_SELN0 = 1;
				INTC_0.PSR[37].B.PRIN =10;
				STM_0_CIR1 = 1;
				STM_0_CMP1 = count;
				STM_0_CCR1 = 1;
				break;
		case 2:	INTC_0.PSR[38].B.PRC_SELN0 = 1;
				INTC_0.PSR[38].B.PRIN =10;
				STM_0_CIR2 = 1;
				STM_0_CMP2 = count;
				STM_0_CCR2 = 1;
				break;
		case 3:	INTC_0.PSR[39].B.PRC_SELN0 = 1;
				INTC_0.PSR[39].B.PRIN =10;
				STM_0_CIR3 = 1;
				STM_0_CMP3 = count;
				STM_0_CCR3 = 1;
				break;
		default: break;
	}
	
}


/*****************************************************************************/

void STM_detachInterrupt( uint8_t Channel )
{

	switch(Channel){
			case 0:	STM_0_CCR0 = 0;
					break;
			case 1:	STM_0_CCR0 = 0;
					break;
			case 2:	STM_0_CCR0 = 0;
					break;
			case 3:	STM_0_CCR0 = 0;
					break;
			default: break;
	}
	

}

/************** Arduino style routines - assumes a 1us clock!!!***************/
/*****************************************************************************/

uint32_t micros( void )
{

	return STM_0_CNT;					// return the current count (assumes 1us clock)

}

/*****************************************************************************/

uint32_t millis( void )
{
	return STM_0_CNT/1000;

}

/*****************************************************************************/

uint32_t seconds( void )
{
	return STM_0_CNT/60000;

}


