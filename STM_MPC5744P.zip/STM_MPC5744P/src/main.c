/* main.c -STM example for MPC5744P-DEV-KIT
 *
 *
 * System Timer Module routines for SPC57xx and MPC57xx
 * SPC572L and MPC5744 have one 32-bit timer
 * with four compare channels
 *
 * J Holland
 * v0.1
 * 27th October 2021
 * copyright RhinoPower Ltd - all rights reserved
 *
 ********************************************************************************/

#include "project.h"
#include "mode_entry.h"
#include "STM.h"
#include "digital.h"


#define	XTAL			40000000					//SPC5744-DEV-KIT has 40MHz xtal
#define SYS_CLK 		160000000					// we want system clock = 160MHz
#define PB_CLK_DIV		4							// we want PBridge clock = 160Mhz/4

#define STM_CLOCK_IN	SYS_CLK/PB_CLK_DIV		// STM is clocked by pbridge clock
#define STM_TMR_FREQ 	1000000						// we want a system timer tick of 1us/1MHz
#define STM_TMR_DIV  	STM_CLOCK_IN/STM_TMR_FREQ  	// this is the prescale value for the STM

#define TMR_CMP_CH0 	0							// this demo uses timer comparator channels 0 to 3
#define TMR_CMP_CH1 	1
#define TMR_CMP_CH2 	2
#define TMR_CMP_CH3		3

#define TEN_SECS		10*STM_TMR_FREQ
#define TWENTY_SECS		20*STM_TMR_FREQ
#define THIRTY_SECS		30*STM_TMR_FREQ
#define FORTY_SECS		40*STM_TMR_FREQ

#define LED_OFF	1
#define LED_ON  0

extern void xcptn_xmpl(void);
void peri_clock_gating(void);


__attribute__ ((section(".text")))
int main(void)
{
	
	xcptn_xmpl ();              		/* Configure and Enable Interrupts */

	peri_clock_gating();       			/* Config gating/enabling peri. clocks for modes*/
                             	 		/* Configuration occurs after mode transition */
	systemClocks(XTAL, SYS_CLK, PB_CLK_DIV);  		/* sysclk=160MHz, dividers configured, mode trans*/

	pinMode(LED_RED, OUTPUT);			// output on LED (MPC5744P-DEV-KIT)
	pinMode(LED_GREEN, OUTPUT);			// output on LED (MPC5744P-DEV-KIT)
	pinMode(LED_BLUE, OUTPUT);			// output on LED (MPC5744P-DEV-KIT)

	digitalWrite(LED_RED, LED_OFF);
	digitalWrite(LED_GREEN, LED_OFF);
	digitalWrite(LED_BLUE, LED_OFF);


	STM_attachInterrupt( TMR_CMP_CH0, TEN_SECS );
	STM_attachInterrupt( TMR_CMP_CH1, TWENTY_SECS );
	STM_attachInterrupt( TMR_CMP_CH2, THIRTY_SECS );
	STM_attachInterrupt( TMR_CMP_CH3, FORTY_SECS );
	STM_begin( STM_TMR_DIV );

	for(;;); //Loop forever

	return 0;
}

/*****************************************************************************/

void STM_CH0_ISR(void)
{
	STM_0_CIR0 = 1;							// clear interrupt
	digitalWrite(LED_RED, LED_ON);
}

void STM_CH1_ISR(void)
{
	STM_0_CIR1 = 1;							// clear interrupt
	digitalWrite(LED_RED, LED_OFF);
	digitalWrite(LED_GREEN, LED_ON);
}

void STM_CH2_ISR(void)
{
	STM_0_CIR2 = 1;							// clear interrupt
	digitalWrite(LED_GREEN, LED_OFF);
	digitalWrite(LED_BLUE, LED_ON);
}

void STM_CH3_ISR(void)
{
	STM_0_CIR3 = 1;							// clear interrupt
	digitalWrite(LED_BLUE, LED_OFF);
}


/*****************************************************************************/
/* peri_clock_gating                                                         */
/* Description: Configures enabling clocks to peri modules or gating them off*/
/*              Default PCTL[RUN_CFG]=0, so by default RUN_PC[0] is selected.*/
/*              RUN_PC[0] is configured here to gate off all clocks.         */
/*****************************************************************************/

void peri_clock_gating (void) {
  MC_ME.RUN_PC[0].R = 0x00000000;  /* gate off clock for all RUN modes */
  MC_ME.RUN_PC[1].R = 0x000000FE;  /* config. peri clock for all RUN modes */

}
