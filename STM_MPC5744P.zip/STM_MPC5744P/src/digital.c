/*
 * digital.c
 *
 * GPIO routines for SPC572L and MPC5744
 *
 * J Holland
 * v0.1
 * 27th October 2021
 * copyright RhinoPower Ltd - all rights reserved
 */
/*****************************************************************************/
/*****************************************************************************/

#include "project.h"
#include "digital.h"


/*****************************************************************************/

void pinMode(uint8_t pin, uint8_t mode)
{
	
		// disable analogue pad - is this needed

	if(mode == INPUT)
	{
		SIUL2.MSCR[pin].B.IBE = 1;
		SIUL2.MSCR[pin].B.OBE = 0;
		SIUL2.MSCR[pin].B.HYS = 0;
		SIUL2.MSCR[pin].B.PUE = 0;

	}
	else if(mode == INPUT_HYS)
	{
		SIUL2.MSCR[pin].B.IBE = 1;
		SIUL2.MSCR[pin].B.OBE = 0;
		SIUL2.MSCR[pin].B.HYS = 1;
	}
	else if(mode == INPUT_PULLUP)
	{
		SIUL2.MSCR[pin].B.IBE = 1;
		SIUL2.MSCR[pin].B.OBE = 0;
		SIUL2.MSCR[pin].B.PUE = 0;
		SIUL2.MSCR[pin].B.HYS = 0;
	}
	else if(mode == INPUT_PULLDOWN)
	{
		SIUL2.MSCR[pin].B.IBE = 1;
		SIUL2.MSCR[pin].B.OBE = 0;
		SIUL2.MSCR[pin].B.PUE = 0;
		SIUL2.MSCR[pin].B.HYS = 0;
	}
	else if(mode == INPUT_PULLUP_HYS)
	{
		SIUL2.MSCR[pin].B.IBE = 1;
		SIUL2.MSCR[pin].B.OBE = 0;
		SIUL2.MSCR[pin].B.PUE = 1;
		SIUL2.MSCR[pin].B.PUS = 1;
		SIUL2.MSCR[pin].B.HYS = 1;
	}
	else if(mode == INPUT_PULLDOWN_HYS)
	{
		SIUL2.MSCR[pin].B.IBE = 1;
		SIUL2.MSCR[pin].B.OBE = 0;
		SIUL2.MSCR[pin].B.PUE = 1;
		SIUL2.MSCR[pin].B.PUS = 1;
		SIUL2.MSCR[pin].B.HYS = 1;
	}
	else if(mode == OUTPUT)
	{
		SIUL2.MSCR[pin].B.IBE = 0;
		SIUL2.MSCR[pin].B.OBE = 1;
		SIUL2.MSCR[pin].B.ODE = 0;
	}
	else if(mode == OUTPUT_OD)
	{
		SIUL2.MSCR[pin].B.IBE = 0;
		SIUL2.MSCR[pin].B.OBE = 1;
		SIUL2.MSCR[pin].B.ODE = 1;
	}

}

/*****************************************************************************/

uint8_t digitalRead(uint8_t pin)
{

return SIUL2.GPDO[pin].R;

}

/*****************************************************************************/


void digitalWrite(uint8_t pin, uint8_t value)
{
	SIUL2.GPDO[pin].R = value;
}


/*****************************************************************************/
