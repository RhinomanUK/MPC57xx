/*
 * STM.h
 *
 * System Timer Module routines for SPC57xx and MPC57xx
 * SPC572L and MPC5744 have one 32-bit timer
 * with four compare channels
 *
 * Arduino style micros() and millis() requires a 1us clock
 *
 * J Holland
 * v0.1
 * 27th October 2021
 * copyright RhinoPower Ltd - all rights reserved
 */

/*****************************************************************************/
/*****************************************************************************/

#ifndef STM_H_
#define STM_H_

#include "project.h"


extern void STM_begin( uint8_t sysClkDivider );
extern void STM_stop( void );
extern uint32_t STM_currentTime( void);
extern void STM_attachInterrupt( uint8_t Channel, uint32_t count );
extern void STM_detachInterrupt( uint8_t Channel );
extern uint32_t micros( void );
extern uint32_t millis( void );
extern uint32_t seconds( void );


#endif /* STM_H_ */
