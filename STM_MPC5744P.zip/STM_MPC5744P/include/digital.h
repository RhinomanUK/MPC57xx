/*
 * digital.h
 *
 * GPIO routines for SPC572L and MPC5744
 *
 * J Holland
 * v0.1
 * 27th October 2021
 * copyright RhinoPower Ltd - all rights reserved
 */

#ifndef DIGITAL_H_
#define DIGITAL_H_


#include "typedefs.h"

// pin defs


// mode defs

#define INPUT				0
#define INPUT_HYS			1
#define INPUT_PULLUP		2
#define INPUT_PULLDOWN		3
#define INPUT_PULLUP_HYS	4
#define INPUT_PULLDOWN_HYS	5
#define OUTPUT 				6
#define OUTPUT_OD			7



void pinMode(uint8_t pin, uint8_t mode);
uint8_t digitalRead(uint8_t pin);
void digitalWrite(uint8_t pin, uint8_t value);



#endif /* DIGITAL_H_ */
