/*
 * mode_entry.h
 *
 *  Created on: Feb 26, 2016
 *      Author: B48683
 */

#ifndef MODE_ENTRY_H_
#define MODE_ENTRY_H_

void PLL_Freq(uint32_t xtal, uint32_t sysClk);

void systemClocks(uint32_t xtal, uint32_t sysClk, uint32_t pbClkDiv);

void enter_STOP_mode();

#endif /* MODE_ENTRY_H_ */
