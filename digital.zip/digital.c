/*
 * Digital.c
 *
 *  Created on: 2 Jun 2021
 *      Author: j_hol
 *      Version: rev 1 - pinout corrected
 *      Date: 25th July 2021
 */

/* Arduino style digital read write routines for the MPC5744-DEV-KIT
 * uses the pinout from the Rev E schematic (not the user guide!)
 */

#include "project.h"
#include "derivative.h"
#include "digital.h"
#include "project.h"			// includes port definitions
//#include "globals.h"			// for HIGH and LOW

// map digital pins to port names (only 0 to 23 for now)
const uint8_t digitalPinMap[24] = { PA11, PA10, PD10, PD11, PF0, PD14, PG3, PG4, PD2,\
									PG7, PE15, PC6, PC7, PC5, PA12, PA9, PB0, PB1, PG9,\
									PD0, PF9, PF8, PF6, PF4 };


void pinMode(uint8_t pin, uint8_t mode)
{
	
	uint8_t temp_pin = digitalPinMap[pin];

	// disable analogue pad - is this needed?
	// SIUL2.MSCR[pinmap[pin]].B.APC = 0;

	if(mode == INPUT)
	{
		SIUL2.MSCR[temp_pin].B.IBE = 1;
		SIUL2.MSCR[temp_pin].B.OBE = 0;
		SIUL2.MSCR[temp_pin].B.HYS = 0;
		SIUL2.MSCR[temp_pin].B.PUE = 0;

	}
	else if(mode == INPUT_HYS)
	{
		SIUL2.MSCR[temp_pin].B.IBE = 1;
		SIUL2.MSCR[temp_pin].B.OBE = 0;
		SIUL2.MSCR[temp_pin].B.HYS = 1;
	}
	else if(mode == INPUT_PULLUP)
	{
		SIUL2.MSCR[temp_pin].B.IBE = 1;
		SIUL2.MSCR[temp_pin].B.OBE = 0;
		SIUL2.MSCR[temp_pin].B.PUE = 0;
		SIUL2.MSCR[temp_pin].B.HYS = 0;
	}
	else if(mode == INPUT_PULLDOWN)
	{
		SIUL2.MSCR[temp_pin].B.IBE = 1;
		SIUL2.MSCR[temp_pin].B.OBE = 0;
		SIUL2.MSCR[temp_pin].B.PUE = 0;
		SIUL2.MSCR[temp_pin].B.HYS = 0;
	}
	else if(mode == INPUT_PULLUP_HYS)
	{
		SIUL2.MSCR[temp_pin].B.IBE = 1;
		SIUL2.MSCR[temp_pin].B.OBE = 0;
		SIUL2.MSCR[temp_pin].B.PUE = 1;
		SIUL2.MSCR[temp_pin].B.PUS = 1;
		SIUL2.MSCR[temp_pin].B.HYS = 1;
	}
	else if(mode == INPUT_PULLDOWN_HYS)
	{
		SIUL2.MSCR[temp_pin].B.IBE = 1;
		SIUL2.MSCR[temp_pin].B.OBE = 0;
		SIUL2.MSCR[temp_pin].B.PUE = 1;
		SIUL2.MSCR[temp_pin].B.PUS = 1;
		SIUL2.MSCR[temp_pin].B.HYS = 1;
	}
	else if(mode == OUTPUT)
	{
		SIUL2.MSCR[temp_pin].B.IBE = 1;
		SIUL2.MSCR[temp_pin].B.OBE = 0;
		SIUL2.MSCR[temp_pin].B.ODE = 0;
	}
	else if(mode == OUTPUT_OD)
	{
		SIUL2.MSCR[temp_pin].B.IBE = 1;
		SIUL2.MSCR[temp_pin].B.OBE = 0;
		SIUL2.MSCR[temp_pin].B.ODE = 0;
	}

}

uint8_t digitalRead(uint8_t pin)
{
	
return SIUL2.GPDO[digitalPinMap[pin]].R;

}


void digitalWrite(uint8_t pin, uint8_t value)
{
	SIUL2.GPDO[digitalPinMap[pin]].R = value;


}


// digitalWriteByte - not required with Arduino pinout - we can't write synchronously to multiple ports
