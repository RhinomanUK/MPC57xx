/****************************************************************************
*
* Copyright © 2017-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY – NOT FOR USE IN PRODUCTION
*****************************************************************************/

/* Inclusion of the main header files of all the imported components in the
   order specified in the application wizard. The file is generated
   automatically.*/
#include "components.h"
#include "stm_lld_cfg.h"

/*stm2 channel 0 callback*/
void cb_stm2_ch0 (void){
  uint8_t message[]= "STM2 Channel 0 expired!\r\n";
  while (sd_lld_write(&SD1,message,(uint16_t)(sizeof(message)/sizeof(message[0]))) == SERIAL_MSG_WAIT){}
}

/*stm2 channel 1 callback*/
void cb_stm2_ch1 (void){
  uint8_t message[]= "STM2 Channel 1 expired!\r\n";
  while (sd_lld_write(&SD1,message,(uint16_t)(sizeof(message)/sizeof(message[0]))) == SERIAL_MSG_WAIT){}
}

/*stm2 channel 2 callback*/
void cb_stm2_ch2 (void){
  uint8_t message[]= "STM2 Channel 2 expired!\r\n";
  while (sd_lld_write(&SD1,message,(uint16_t)(sizeof(message)/sizeof(message[0]))) == SERIAL_MSG_WAIT){}
}

/*stm2 channel 3 callback*/
void cb_stm2_ch3 (void){
  uint8_t message[]= "STM2 Channel 3 expired!\r\n";
  while (sd_lld_write(&SD1,message,(uint16_t)(sizeof(message)/sizeof(message[0]))) == SERIAL_MSG_WAIT){}
}

/*
 * Application entry point.
 */
int main(void) {

  /* Initialization of all the imported components in the order specified in
     the application wizard. The function is generated automatically.*/
  componentsInit();

  /* Activates STM Drivers */
  stm_lld_start(&STMD3, stm2_config);

  /* Enable channels and start global counter */
  stm_lld_enable(&STMD3);

  /* Enable Interrupts */
  irqIsrEnable();

  /* Start Serial Driver */
  sd_lld_start(&SD1,NULL);

  /* Application main loop.*/
  for ( ; ; ) {
      pal_lld_togglepad(PORT_A, PA_LED1);
      osalThreadDelayMilliseconds(300);
      pal_lld_togglepad(PORT_A, PA_LED3);
      osalThreadDelayMilliseconds(300);
    }
}
