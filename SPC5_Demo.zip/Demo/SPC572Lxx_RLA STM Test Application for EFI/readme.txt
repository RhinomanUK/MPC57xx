In this example, STM2 driver is configured as follows:

4 timers are set to expire respectively after 1,2,3 and 4 seconds.

Each timers has its own callback defined in main.c which will
send a string to serial port when expired. Also, leds are blinking during 
program execution.

This code is released just as reference code.