This example show how to use the PWM drive over GTM

PWM is based on the GTM IP TOM submodule.
On SPC572L are available 2 TOM modules with 16 channel for each.

Each TOM channel can generate a PWM signal.

The channel can be configured either in GTM component or in PWM driver

The channel0 of TOM0 is used in this demo ; it is configured in the GTM component.

In the PWM GUI this channel can be selected for the usage but the values of
Period or Duty Cycle are not editable (already configured in the GTM pages)

A main loop change the value of duty cycle and period of TOM0 Channel0.
PWM signal can be analyzed with an oscillator.

This code is released just as reference code.