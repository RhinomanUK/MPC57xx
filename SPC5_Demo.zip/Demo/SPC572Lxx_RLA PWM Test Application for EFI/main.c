/****************************************************************************
*
* Copyright © 2017-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY - NOT FOR USE IN PRODUCTION
*****************************************************************************/

/* Inclusion of the main header files of all the imported components in the
   order specified in the application wizard. The file is generated
   automatically.*/
#include "components.h"
#include "pwm_lld_cfg.h"

/*
 * There is one channel per PWM driver, setting it ot zero even if not used.
 */
#define PWM_CHANNEL 0

/*
 * Application entry point.
 */
int main(void) {

  /* Initialization of all the imported components in the order specified in
     the application wizard. The function is generated automatically.*/
  componentsInit();

  /* Enable Interrupts */
  irqIsrEnable();

  /* Enable clock management unit */
  gtm_cmuStart(&CMUD1);

  /* Application main loop.*/
  for ( ; ; ) {
	    /*
	     * Note:
	     *   duty cycle changed on-the-fly, without calling pwm_lld_disable_channel()
	     */

	    /* PWM0 used in the Configuration */
	    pwm_lld_start(&PWMD1, &pwm_config_pwm1);

	    /*
	     * Starts the PWM0 using 75% duty cycle.
	     */
	    pwm_lld_enable_channel(&PWMD1, PWM_CHANNEL, PWM_PERCENTAGE_TO_WIDTH(&PWMD1, PWM_CHANNEL, 7500));
	    osalThreadDelayMilliseconds(1000);

	    /*
	     * Changes the PWM0 to 50% duty cycle.
	     */
	    pwm_lld_enable_channel(&PWMD1, PWM_CHANNEL, PWM_PERCENTAGE_TO_WIDTH(&PWMD1, PWM_CHANNEL, 5000));
	    osalThreadDelayMilliseconds(1000);

	    /*
	     * Changes the PWM0 to 25% duty cycle.
	     */
	    pwm_lld_enable_channel(&PWMD1, PWM_CHANNEL, PWM_PERCENTAGE_TO_WIDTH(&PWMD1, PWM_CHANNEL, 2500));
	    osalThreadDelayMilliseconds(1000);

	    /*
	     * Changes the PWM0 to 50% duty cycle.
	     */
	    pwm_lld_enable_channel(&PWMD1, PWM_CHANNEL, PWM_PERCENTAGE_TO_WIDTH(&PWMD1, PWM_CHANNEL, 5000));
	    osalThreadDelayMilliseconds(1000);

	    /*
	     * Changes PWM period, by doubling it; the duty cycle was at 50%,
	     * doubling the period, the duty cycle will be now at 25%.
	     */
	    pwm_lld_change_period(&PWMD1, (pwmcnt_t)(pwm_config_pwm1.period * 2U));
	    osalThreadDelayMilliseconds(1000);

	    /*
	     * Disables PWM0 and stops the drivers.
	     */
	    pwm_lld_disable_channel(&PWMD1, PWM_CHANNEL);
	    pwm_lld_stop(&PWMD1);
  }
}
