/****************************************************************************
*
* Copyright © 2017-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY – NOT FOR USE IN PRODUCTION
*****************************************************************************/

/* Inclusion of the main header files of all the imported components in the
   order specified in the application wizard. The file is generated
   automatically.*/
#include "components.h"
#include "spi_lld_cfg.h"

void L9177A_callback(SPIDriver *spip)
{
	(void)spip;
	return;
}

/*
 * Application entry point.
 */
int main(void) {

  uint8_t txbuf[3];
  uint8_t rxbuf[3];

  /* Initialization of all the imported components in the order specified in
     the application wizard. The function is generated automatically.*/
  componentsInit();

  /* Enable Interrupts */
  irqIsrEnable();

  /* Application main loop.*/
  for ( ; ; ) {

	  txbuf[0] = 0x00;
	  txbuf[1] = 0x00;
	  txbuf[2] = 0x00;

	  rxbuf[0] = 1;
	  rxbuf[1] = 2;
	  rxbuf[2] = 3;

	  spi_lld_start(&SPID1, &spi_config_L9177A);
	  spi_lld_select(&SPID1);
	  spi_lld_exchange(&SPID1, 3, txbuf, rxbuf);
	  spi_lld_unselect(&SPID1);
	  spi_lld_stop(&SPID1);

	  osalThreadDelayMilliseconds(300);
  }
}
