This application shows how to use the SPI driver 0.

The SPI PAD used:
1) PA[2] for the CS0_1
2) PA[13] for the SCK_0
3) PD[5]  for the SOUT_0
4) PE[9]  for the SIN_0

This software is released just as reference code