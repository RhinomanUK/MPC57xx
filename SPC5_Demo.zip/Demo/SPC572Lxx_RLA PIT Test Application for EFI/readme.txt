This application shows how to the use PIT Driver and related 
callback function.

2 PIT channels are enabled with a frequency of 125ms e 250ms respectively.
Each time a channel expires, a different variable is incremented 
using its callback function.

NOTE:
PIT channel 0 is always used by the system and cannot be deactivated

This code is released just as reference code
