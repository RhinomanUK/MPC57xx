/****************************************************************************
*
* Copyright © 2017-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY – NOT FOR USE IN PRODUCTION
*****************************************************************************/

/* Inclusion of the main header files of all the imported components in the
   order specified in the application wizard. The file is generated
   automatically.*/
#include "components.h"
#include "pit_lld_cfg.h"


/* Callback function for PIT Channel 1 */
void cb_pit_ch1(void){
  int a = 0;
  while (a < 100) {
	  a++;
  }
}

/* Callback function for PIT Channel 2 */
void cb_pit_ch2(void){
	  int a = 0;
	  while (a < 10000) {
		  a++;
	  }
}

/*
 * Application entry point.
 */
int main(void) {

  /* Initialization of all the imported components in the order specified in
     the application wizard. The function is generated automatically.*/
  componentsInit();

  /* Enable Interrupts */
  irqIsrEnable();

  /* Start PIT driver */
  pit_lld_start(&PITD1, pit0_config);

  /* Enable PIT Channels */
  /* Channel 0 already enabled and used by system */
  pit_lld_channel_start(&PITD1, 1U);
  pit_lld_channel_start(&PITD1, 2U);

  /* Application main loop.*/
  for ( ; ; ) {
  }
}
