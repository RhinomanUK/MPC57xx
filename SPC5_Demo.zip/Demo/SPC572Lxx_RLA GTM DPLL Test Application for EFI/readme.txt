This application shows how to the use the DPLL to generate injection and ignition pulse
based on angle/tooth and duration.

Crank waveform is internally generated using PSM and ATOM0_0.
Live RPM update is available.


Configuration
-------------

- INJECTION #1:
    ATOM1_0   PD14

- INJECTION #2:
    ATOM1_1   PD15

- IGNITION #1:
    ATOM1_2   PE0

- IGNITION #2:
    ATOM1_3   PE1

- TACKOMETER (2ms pulse on the crank gap):
    ATOM1_6   PC5

- Reference Position (could be the active/passive TDC)
    ATOM1_7   PC4


Enjoy.