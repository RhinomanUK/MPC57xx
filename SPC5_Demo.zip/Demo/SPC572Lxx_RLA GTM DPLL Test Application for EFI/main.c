/****************************************************************************
*
* Copyright © 2017-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY - NOT FOR USE IN PRODUCTION
*****************************************************************************/

/* Inclusion of the main header files of all the imported components in the
   order specified in the application wizard. The file is generated
   automatically.*/
#include "components.h"
#include <build/mcs/mcs0.h>

extern unsigned long mcs0_mem[];

/*
 * Tested with:
 *   60 - 2
 *   24 - 2
 *   24 - 1
 */

#define NOMINAL_TEETH						24U
#define MISSING_TEETH						2U


/*
 * Multiplier resolution:
 *    1 : 1 degree
 *   10 : 1/10th degree
 */
#define MULTIPLIER_RESOLUTION				10U
#define TOOTH_MULTIPLIER					(MULTIPLIER_RESOLUTION * NOMINAL_TEETH)


#define NOMINAL_TEETH_HALF_SCALE			NOMINAL_TEETH
#define NOMINAL_TEETH_FULL_SCALE			(2U * NOMINAL_TEETH_HALF_SCALE)

#define SUBINC_PER_FULL_SCALE				(NOMINAL_TEETH_FULL_SCALE * TOOTH_MULTIPLIER)

/* Time stamps are 24 bits */
#define ROUND_24BIT(x)						(uint32_t)(((uint32_t)(x)) & 0x00FFFFFFUL)

/*
 * LED macros:
 *
 * Mapping:
 *   LED1:
 *     - Toggling at half RPM frequency
 *
 *   LED2:
 *     - On:  DPLL got the lock on profile/input waveform
 *     - Off: DPLL lost the lock on profile/input waveform
 *
 *   LED3:
 *     - alive led, toggling every second
 */
#define LED1_ON()		//pal_clearpad(PORT_E, PE_LED1)
#define LED2_ON()		//pal_clearpad(PORT_E, PE_LED2)
#define LED3_ON()		//pal_clearpad(PORT_E, PE_LED3)

#define LED1_OFF()		//pal_setpad(PORT_E, PE_LED1)
#define LED2_OFF()		//pal_setpad(PORT_E, PE_LED2)
#define LED3_OFF()		//pal_setpad(PORT_E, PE_LED3)

#define LED1_TOGGLE()	//pal_togglepad(PORT_E, PE_LED1)
#define LED2_TOGGLE()	//pal_togglepad(PORT_E, PE_LED2)
#define LED3_TOGGLE()	//pal_togglepad(PORT_E, PE_LED3)

/*****************************************************************************/
/* Start of Crank simulation                                                 */
/*****************************************************************************/


#define ATOM_SIGNAL_CLOCK_FREQUENCY 8000000UL
#define ATOM_SIGNAL_CLOCK_FREQ     (float)(1.0f/(float)ATOM_SIGNAL_CLOCK_FREQUENCY)
#define ATOM_CLOCK_SELECT          3U
#define ATOM_ACBI                  ((uint32_t)ATOM_CLOCK_SELECT << 2U)
#define MAX_ATOM_PERIOD_CNTS       0xFFFFFFU


/*
 * All arrays size must be defined in full scale
 * Number correlates to the duty cycle high time of the period 10 => 10% High 90% low
 *
 */
static uint8_t CrankDutyCycles[NOMINAL_TEETH_FULL_SCALE];
static uint32_t CrankProfile[NOMINAL_TEETH_FULL_SCALE];

static void updateProfile(uint16_t rpm) {
	uint32_t *fifo;
	uint16_t i;
	float tmp;
	uint32_t tooth_period;

	/* Number of teeth per second */
	tmp = (((float)rpm * (float)NOMINAL_TEETH_HALF_SCALE) / 60.0f);

	/* Time for tooth */
	tmp = (1.0f / tmp);

	/* Tooth period at ATOM frequency */
	tmp = (tmp / ATOM_SIGNAL_CLOCK_FREQ);
	tooth_period = ROUND_24BIT((uint32_t) (tmp));

	/* Update the crank profile */
	fifo = gtm_psmGetMemoryAddress(&PSMD1, PSM_CHANNEL0);

	for(i = 0; i < NOMINAL_TEETH_FULL_SCALE; i++) {
		/* Period */
		*fifo++ = tooth_period + (ATOM_ACBI << 24U);

		/* Duty cycle */
		*fifo++ = (((tooth_period * CrankDutyCycles[i]) / 100U) * CrankProfile[i]) + (ATOM_ACBI << 24U);
	}
}

static void setToothWheel(uint8_t channel) {
	uint32_t i;

	gtm_psmFlush(&PSMD1, channel);

	gtm_psmSetStartAddress(&PSMD1, channel, 0);
	gtm_psmSetEndAddress(&PSMD1, channel, (uint32_t)(2U * NOMINAL_TEETH_FULL_SCALE));
	gtm_psmSetLowerWM(&PSMD1, channel, 0UL);
	gtm_psmSetUpperWM(&PSMD1, channel, (uint32_t)((2U * NOMINAL_TEETH_FULL_SCALE) - 1U));

	/* Pre-fill Channel0 FIFO */
	for (i = 0;  i < NOMINAL_TEETH_FULL_SCALE; i++) {
		/* Pre-fill Channel FIFO */
		gtm_psmWrite(&PSMD1, channel, 0UL);
		gtm_psmWrite(&PSMD1, channel, 0UL);

		/* Generate crank profiles for RPM live updates */
		CrankDutyCycles[i] = 50;
		CrankProfile[i] = 1;
	}

	/* Now set the hole */
	for (i = 0;  i < MISSING_TEETH; i++) {
		CrankProfile[i] = 0;
		CrankProfile[i + NOMINAL_TEETH_HALF_SCALE] = 0;
	}

}

/*****************************************************************************/
/* End of Crank simulation                                                   */
/*****************************************************************************/

/*
 * This is the Reference Position, a specific tooth of the crank wheel
 * used as reference to generate injection and ignition events.
 *
 * By default it set to 0, that is the second tooth after the whole.
 * It can be changed by changing the following define.
 *
 * It should be in the range [-NOMINAL_TEETH, +NOMINAL_TEETH]
 *
 * For example, setting to 5, the reference position will be 7 teeth after the missing tooth/teeth.
 *
 * It is also possible to use angles instead of teeth to have fractional teeth.
 *
 */
#define REFERENCE_POSITION_OFFSET_IN_TEETH		0U
#define REFERENCE_POSITION_SCALING				(SUBINC_PER_FULL_SCALE + (REFERENCE_POSITION_OFFSET_IN_TEETH * TOOTH_MULTIPLIER))

static vuint32_t Reference_Position = 0;


/* Cylinder ID */
#define CYLINDER_1				0UL
#define CYLINDER_2				1UL


/* Injection ID */
#define INJECTOR_1				0UL
#define INJECTOR_2				1UL

/* Ignition ID */
#define IGNITOR_1				0UL
#define IGNITOR_2				1UL


/*
 * Cylinder #1:
 *    MCS0 Channel 0 controls injection
 *    MCS0 Channel 2 controls ignition
 *
 * Cylinder #2:
 *    MCS0 Channel 1 controls injection
 *    MCS0 Channel 3 controls ignition
 *
 * Injection:
 *    Position, Time
 *
 * Ignition:
 *    Position, Time
 */


typedef struct EFIParameter_s {
	uint32_t mcs_channel;
	uint32_t time;
	uint32_t position;
} EFIParameter_t;

typedef struct Cylinder_s {
	GTM_MCSDriver *mcsd;
	EFIParameter_t injection;
	EFIParameter_t ignition;
} Cylinder_t;


/* MCS0 Variable defines */

#define INJ1_TIME_VAR			((uint32_t)LABEL_MCS0_MEM_INJ1TIME << 2U)
#define INJ2_TIME_VAR			((uint32_t)LABEL_MCS0_MEM_INJ2TIME << 2U)

#define INJ1_POSITION_VAR		((uint32_t)LABEL_MCS0_MEM_INJ1POS << 2U)
#define INJ2_POSITION_VAR		((uint32_t)LABEL_MCS0_MEM_INJ2POS << 2U)

#define IGN1_TIME_VAR			((uint32_t)LABEL_MCS0_MEM_IGN1TIME << 2U)
#define IGN2_TIME_VAR			((uint32_t)LABEL_MCS0_MEM_IGN2TIME << 2U)

#define IGN1_POSITION_VAR		((uint32_t)LABEL_MCS0_MEM_IGN1POS << 2U)
#define IGN2_POSITION_VAR		((uint32_t)LABEL_MCS0_MEM_IGN2POS << 2U)


static const Cylinder_t Cylinder[2] = {
	{
		&MCSD1,
		{ MCS_CHANNEL0, INJ1_TIME_VAR, INJ1_POSITION_VAR },  /* Injection */
		{ MCS_CHANNEL2, IGN1_TIME_VAR, IGN1_POSITION_VAR },  /* Ignition */
	},
	{
		&MCSD1,
		{ MCS_CHANNEL1, INJ2_TIME_VAR, INJ2_POSITION_VAR },  /* Injection */
		{ MCS_CHANNEL3, IGN2_TIME_VAR, IGN2_POSITION_VAR },  /* Ignition */
	},
};


static inline void pwt_injStart(uint32_t cylinder, uint32_t inj_id, uint32_t position, uint32_t duration) {

	vuint32_t *p;
	uint32_t base;
	uint32_t addr;

	/*
	 * Injection id is not used.
	 * It could be used in case or multiple injector devices.
	 */
	(void) inj_id;

	base = gtm_mcsGetRAMBaseAddress(Cylinder[cylinder].mcsd);

	/* Set injection position value */
	addr = base + Cylinder[cylinder].injection.position;
	p = (vuint32_t *)(addr);
	*p = position;

	/* Set injection time value */
	addr = base + Cylinder[cylinder].injection.time;
	p = (vuint32_t *)(addr);
	*p = duration;

	/* Signal MCS to update */
	gtm_mcsSetTriggerBit(Cylinder[cylinder].mcsd, Cylinder[cylinder].injection.mcs_channel);
}


static inline void pwt_ignStart(uint32_t cylinder, uint32_t ign_id, uint32_t position, uint32_t duration) {

	vuint32_t *p;
	uint32_t base;
	uint32_t addr;

	/*
	 * Ignition id is not used.
	 * It could be used in case or multiple ignition devices.
	 */
	(void) ign_id;

	base = gtm_mcsGetRAMBaseAddress(Cylinder[cylinder].mcsd);

	/* Set injection position value */
	addr = base + Cylinder[cylinder].ignition.position;
	p = (vuint32_t *)(addr);
	*p = position;

	/* Set injection time value */
	addr = base + Cylinder[cylinder].ignition.time;
	p = (vuint32_t *)(addr);
	*p = duration;

	/* Signal MCS to update */
	gtm_mcsSetTriggerBit(Cylinder[cylinder].mcsd, Cylinder[cylinder].ignition.mcs_channel);
}


/*
 * Use tooth as example, angle for not-aligned tooth is easy to calculate
 */

/* Injection #1 */
#define INJECTION_1_TOOTH			(NOMINAL_TEETH_HALF_SCALE / 4U)
#define INJECTION_1_ANGLE			(INJECTION_1_TOOTH * TOOTH_MULTIPLIER)
#define INJECTION_1_POSITION		(Reference_Position + INJECTION_1_ANGLE)
#define INJECTION_1_POSITION_24		ROUND_24BIT(INJECTION_1_POSITION)

/* 1 ms @ 8MHz */
#define INJECTION_1_DURATION       8000


/* Injection #2 */
#define INJECTION_2_TOOTH			((NOMINAL_TEETH_HALF_SCALE / 4U) + NOMINAL_TEETH_HALF_SCALE)
#define INJECTION_2_ANGLE			(INJECTION_2_TOOTH * TOOTH_MULTIPLIER)
#define INJECTION_2_POSITION		(Reference_Position + INJECTION_2_ANGLE)
#define INJECTION_2_POSITION_24		ROUND_24BIT(INJECTION_2_POSITION)

/* 1 ms @ 8MHz */
#define INJECTION_2_DURATION       8000


/* Ignition #1 */
#define IGNITION_1_TOOTH			((NOMINAL_TEETH_HALF_SCALE / 4U) + 1U)
#define IGNITION_1_ANGLE			(IGNITION_1_TOOTH * TOOTH_MULTIPLIER)
#define IGNITION_1_POSITION			(Reference_Position + IGNITION_1_ANGLE)
#define IGNITION_1_POSITION_24		ROUND_24BIT(IGNITION_1_POSITION)

/* 0.5 ms @ 8MHz */
#define IGNITION_1_DURATION       4000


/* Ignition #1 */
#define IGNITION_2_TOOTH          ((NOMINAL_TEETH_HALF_SCALE / 4U) + 1U + NOMINAL_TEETH_HALF_SCALE)
#define IGNITION_2_ANGLE          (IGNITION_2_TOOTH * TOOTH_MULTIPLIER)
#define IGNITION_2_POSITION       (Reference_Position + IGNITION_2_ANGLE)
#define IGNITION_2_POSITION_24    ROUND_24BIT(IGNITION_2_POSITION)


/* 0.5 ms @ 8MHz */
#define IGNITION_2_DURATION       4000



/*
 * TIM0_0 interrupt routine called each time
 * a new value is detected on its input pin.
 */
void new_value(GTM_TIMDriver *timd, uint8_t channel) {

	static uint32_t previous_time_stamp;
	static uint32_t new_time_stamp = 0;
	static uint32_t previous_diff = 0;
	static uint32_t diff = 0;
	static uint32_t iter = 0;

	uint32_t time_stamp;

	time_stamp = timd->tim->GTM_CH_REG(0,GPR0).R;

	if ((time_stamp & 0x01000000UL) == 0UL) {
		previous_time_stamp = new_time_stamp;
		previous_diff = diff;

		new_time_stamp = time_stamp & 0x00FFFFFFUL;

		if (++iter > 1UL) {

			if (new_time_stamp > previous_time_stamp) {
				diff = new_time_stamp - previous_time_stamp;
			} else {
				diff = (0x00FFFFFFUL - previous_time_stamp) + new_time_stamp + 1UL;
			}

			if (previous_diff >= ((2UL * diff))) {

				/* Clear all DPLL interrupts */
				gtm_dpllAckInt(&DPLLD1, 0xFFFFFFFFUL);

				/* Synchronization tooth index depends on compiler optimisation level
				 * and if the program is going to be executed from flash or from RAM:
				 *
				 *               +-------+-----+
				 *               | Flash | RAM |
				 * +-------------+-------+-----+
				 * | -O2 (speed) |   3   |  2  |
				 * | -O0 (none)  |   3   |  3  |
				 * +-------------+-------+-----+
				 *
				 */
				#define SYNC_TOOTH_INDEX	3UL

				gtm_dpllTriggerRAM2C(&DPLLD1, SYNC_TOOTH_INDEX);
				gtm_dpllEnableSubInc1(&DPLLD1);

				/* Got the gap, disable TIM interrupts */
				gtm_timDisableInt(timd, channel, SPC5_GTM_TIM_IRQ_ENABLE_NEW_VALUE);

				/* Compensation */
				uint32_t fractionalTeeth;
				uint32_t temp1;
				float temp2;
				temp1 = ((gtm_tbuGetTimeBaseChannel(&TBUD1, TBU_CHANNEL0) - new_time_stamp) * TOOTH_MULTIPLIER);
				temp2 = ((float)((float)temp1 / (float)diff)) + 0.5f;
				fractionalTeeth = (uint32_t)(temp2);

				/* Synchronize and start the TBU counter for subinc 1 */
				/* Second falling edge after the gap = 0 */
				gtm_tbuSetRunningModeChannel_12(&TBUD1, TBU_CHANNEL1, SPC5_GTM_TBU_MODE_FORWARD_BACKWARD);
				gtm_tbuSetTimeBaseChannel(&TBUD1, TBU_CHANNEL1, ROUND_24BIT((2U * TOOTH_MULTIPLIER) + fractionalTeeth));
				gtm_tbuStartChannel(&TBUD1, TBU_CHANNEL1);

				/* Update Reference Position */
				Reference_Position =  ROUND_24BIT(((gtm_tbuGetTimeBaseChannel(&TBUD1, TBU_CHANNEL1) + REFERENCE_POSITION_SCALING) - fractionalTeeth));

				uint32_t tmp;

				/*
				 * Initialize the TACH event.
				 * It uses ATOM1 Channel 6
				 */
				(void)gtm_atomGetShadowReg0(&ATOMD2, ATOM_CHANNEL6);
				(void)gtm_atomGetShadowReg1(&ATOMD2, ATOM_CHANNEL6);

				/* Assume the zero 5 teeth before the reference position */
				tmp = ROUND_24BIT(Reference_Position - (TOOTH_MULTIPLIER * 5U));
				gtm_atomSetCompare1(&ATOMD2, ATOM_CHANNEL6, tmp);

				/* Set compare strategy to compare in CCU1 only using TBU_TS1 */
				gtm_atomSignalLevelControl(&ATOMD2, ATOM_CHANNEL6, SPC5_GTM_ATOM_SIGNAL_LEVEL_CRTL_HIGH);
				gtm_atomCompareControl(&ATOMD2, ATOM_CHANNEL6, SPC5_GTM_ATOM_COMPARE_ONLY_CCU1_TS12);


				/* Schedule event for falling edge tooth 1 to falling edge tooth2 */
				/* Make sure the rising edge is always after the falling edge of tooth 2 */
				(void)gtm_atomGetShadowReg0(&ATOMD2, ATOM_CHANNEL7);
				(void)gtm_atomGetShadowReg1(&ATOMD2, ATOM_CHANNEL7);

				tmp = ROUND_24BIT(Reference_Position - (TOOTH_MULTIPLIER * 1U));
				gtm_atomSetCompare0(&ATOMD2, ATOM_CHANNEL7, tmp);
				tmp = ROUND_24BIT(Reference_Position - (TOOTH_MULTIPLIER * 0U));
				gtm_atomSetCompare1(&ATOMD2, ATOM_CHANNEL7, tmp);

				/*
				 * Do first injection(s) and ignition(s)
				 */

				/* Cylinder #1 */
				pwt_injStart(CYLINDER_1, INJECTOR_1, INJECTION_1_POSITION_24, INJECTION_1_DURATION);
				pwt_ignStart(CYLINDER_1, IGNITOR_1, IGNITION_1_POSITION_24, IGNITION_1_DURATION);

				/* Cylinder #2 */
				pwt_injStart(CYLINDER_2, INJECTOR_2, INJECTION_2_POSITION_24, INJECTION_2_DURATION);
				pwt_ignStart(CYLINDER_2, IGNITOR_2, IGNITION_2_POSITION_24, IGNITION_2_DURATION);
			}
		}
	}
}

/*
 * ATOM1_6 interrupt routine called after a number of millisecond
 * after the zero angle is detected.
 *
 *
 */
void atom1_ch6_ccu0(GTM_ATOMDriver *atomd, uint8_t channel) {
	uint32_t match_angle;

	(void)gtm_atomGetShadowReg1(atomd, channel);

	/* Read and set Compare register 1 for next comparison */
	match_angle = gtm_atomGetCompare1(atomd, channel);
	gtm_atomSetCompare1(atomd, channel, match_angle);

	/* Set compare strategy to compare in CCU0 only using TBU_TS0 */
	gtm_atomSignalLevelControl(&ATOMD2, ATOM_CHANNEL6, SPC5_GTM_ATOM_SIGNAL_LEVEL_CRTL_HIGH);
	gtm_atomCompareControl(&ATOMD2, ATOM_CHANNEL6, SPC5_GTM_ATOM_COMPARE_ONLY_CCU1_TS12);
}

/*
 * ATOM1_6 interrupt routine called each time
 * the zero angle is detected.
 *
 */
void atom1_ch6_ccu1(GTM_ATOMDriver *atomd, uint8_t channel) {
	uint32_t match_time;
	uint32_t match_angle;

	match_time = gtm_atomGetShadowReg0(atomd, channel);

	/* Add 2 millisecond */
#define TACHOMETER_TIME   20000UL
	match_time = ROUND_24BIT(TACHOMETER_TIME + match_time);

	/* Set time for matching */
	gtm_atomSetCompare0(atomd, channel, match_time);

	/* Set angle for matching */
	match_angle = gtm_atomGetShadowReg1(atomd, channel);
	match_angle = ROUND_24BIT(SUBINC_PER_FULL_SCALE + match_angle);
	gtm_atomSetCompare1(atomd, channel, match_angle);

	/* Set compare strategy to compare in CCU0 only using TBU_TS0 */
	gtm_atomSignalLevelControl(&ATOMD2, ATOM_CHANNEL6, SPC5_GTM_ATOM_SIGNAL_LEVEL_CRTL_LOW);
	gtm_atomCompareControl(atomd, channel, SPC5_GTM_ATOM_COMPARE_ONLY_CCU0_TS0);
}

/*
 * ATOM1_7 interrupt routine called each time
 * the reference point is detected.
 *
 * Reference point could be set to active/passive TDC.
 *
 */
void atom1_ch7_tdc(GTM_ATOMDriver *atomd, uint8_t channel) {
	uint32_t tmp;

	/* Update reference position */
	Reference_Position = ROUND_24BIT(SUBINC_PER_FULL_SCALE + Reference_Position);

	/* Read SR register to re-activate comparison */
	(void)gtm_atomGetShadowReg0(atomd, channel);
	(void)gtm_atomGetShadowReg1(atomd, channel);

	/* Read and set Compare register 0 for next comparison */
	tmp = gtm_atomGetCompare0(atomd, channel);
	tmp = ROUND_24BIT(SUBINC_PER_FULL_SCALE + tmp);
	gtm_atomSetCompare0(atomd, channel, tmp);

	/* Read and set Compare register 1 for next comparison */
	tmp = gtm_atomGetCompare1(atomd, channel);
	tmp = ROUND_24BIT(SUBINC_PER_FULL_SCALE + tmp);
	gtm_atomSetCompare1(atomd, channel, tmp);

	/*
	 * Do next injection(s) and ignition(s)
	 */

	/* Cylinder #1 */
	pwt_injStart(CYLINDER_1, INJECTOR_1, INJECTION_1_POSITION_24, INJECTION_1_DURATION);
	pwt_ignStart(CYLINDER_1, IGNITOR_1, IGNITION_1_POSITION_24, IGNITION_1_DURATION);

	/* Cylinder #2 */
	pwt_injStart(CYLINDER_2, INJECTOR_1, INJECTION_2_POSITION_24, INJECTION_2_DURATION);
	pwt_ignStart(CYLINDER_2, IGNITOR_2, IGNITION_2_POSITION_24, IGNITION_2_DURATION);
}


/*
 * DPLL user interrupt 0.
 *
 * It is set on the first teeth after the first hole
 *
 * This interrupt is fired once per full scale (720 degree),
 * it could be used to calculate the current RPMs.
 *
 */
void dpll_trigger_event_0(GTM_DPLLDriver *dplld, uint32_t int_num) {
	(void)int_num;

	if ((gtm_dpllGetStatus(dplld) & SPC5_GTM_DPLL_STATUS_LOCK1) != 0UL) {
		LED1_TOGGLE();
	}
}

/*
 * DPLL get lock interrupt.
 *
 * This interrupt is fired each time the DPLL locks on profile
 * that is there is a match between the input signal waveform and
 * the provided user profile.
 *
 */
void dpll_sub_inc1_get_lock(GTM_DPLLDriver *dplld, uint32_t int_num) {
	(void)dplld;
	(void)int_num;

	LED2_ON();
}

/*
 * DPLL loss lock interrupt.
 *
 * This interrupt is fired each time the DPLL looses the lock on profile
 * that is there is a mismatch between the input signal waveform and
 * the provided user profile.
 *
 */
void dpll_sub_inc1_loss_lock(GTM_DPLLDriver *dplld, uint32_t int_num) {
	(void)dplld;
	(void)int_num;

	LED2_OFF();
}


/*
 * Initializes the DPLL.
 */
static void init_DPLL(void) {
	uint32_t i;
	uint32_t *p;

	/* Initialize RAM regions */
	gtm_dpllInitRAM(&DPLLD1);

	/* RAM2 offset to 128 Kb for each section (2a, 2b, 2c, 2d) */
	gtm_dpllSetRAM2Offset(&DPLLD1, SPC5_GTM_DPLL_RAM2_OFFSET_128);


	/* Fill-in the reference profile */
	p = gtm_dpllRAMBaseAddress(&DPLLD1, SC5_GTM_DPLL_RAM_REGION_2C);

#define NOMINAL_INC	0x10000U
	/* First gap */
	p[0] = (uint32_t)(NOMINAL_INC * (MISSING_TEETH + 1U));
	/* Add TINT0 tooth interrupt just after the first gap */
	p[1] = (uint32_t)(((uint32_t)NOMINAL_INC) | SPC5_GTM_DPLL_ADT_TINT_0);
	for(i = 2; i < NOMINAL_TEETH_FULL_SCALE; i++) {
		p[i] = NOMINAL_INC;
	}

	/* Second gap */
	p[NOMINAL_TEETH - MISSING_TEETH] = (uint32_t)(NOMINAL_INC * (MISSING_TEETH + 1U));


	/* Time Out Value of Active TRIGGER Slope (for missing TRIGGER generation) */
	gtm_dpllSetMemoryRegister(&DPLLD1, SPC5_GTM_DPLL_TRIGGER_TIME_OUT_VALUE_REG, 0x0800);

	gtm_dpllSetMultiplier(&DPLLD1, TOOTH_MULTIPLIER);
	gtm_dpllSetTriggerNumber(&DPLLD1, NOMINAL_TEETH);
	gtm_dpllTriggerSyncNum(&DPLLD1, MISSING_TEETH);
	gtm_dpllEnableTrigger(&DPLLD1);

	gtm_dpllTriggerSlope(&DPLLD1, SPC5_GTM_DPLL_SLOPE_HIGH);
	gtm_dpllTriggerPlausibility(&DPLLD1, SPC5_GTM_DPLL_TIME_RELATED_PLAUSIBILITY);

	/* Use PMT channel 0, gets requests from MCS Channel 0 */
	gtm_dpllSetPMT(&DPLLD1, SPC5_GTM_DPLL_PMT_ID_0, SPC5_GTM_WRITE_ADDRESS_MCS0_MCS0_0);
	gtm_dpllEnableAction(&DPLLD1, SPC5_GTM_DPLL_ACTION_ID_0);

	/* Use PMT channel 1, gets requests from MCS Channel 1 */
	gtm_dpllSetPMT(&DPLLD1, SPC5_GTM_DPLL_PMT_ID_1, SPC5_GTM_WRITE_ADDRESS_MCS0_MCS0_1);
	gtm_dpllEnableAction(&DPLLD1, SPC5_GTM_DPLL_ACTION_ID_1);

	/* Use PMT channel 2, gets requests from MCS Channel 2 */
	gtm_dpllSetPMT(&DPLLD1, SPC5_GTM_DPLL_PMT_ID_2, SPC5_GTM_WRITE_ADDRESS_MCS0_MCS0_2);
	gtm_dpllEnableAction(&DPLLD1, SPC5_GTM_DPLL_ACTION_ID_2);

	/* Use PMT channel 3, gets requests from MCS Channel 3 */
	gtm_dpllSetPMT(&DPLLD1, SPC5_GTM_DPLL_PMT_ID_3, SPC5_GTM_WRITE_ADDRESS_MCS0_MCS0_3);
	gtm_dpllEnableAction(&DPLLD1, SPC5_GTM_DPLL_ACTION_ID_3);

	/* Now enable the DPLL */
	gtm_dpllEnable(&DPLLD1);
}

/*
 * Initializes the MCS.
 */
static void initMCS(void) {

	/* Reset the RAM and wait for action complete */
	gtm_mcsResetRAM(&MCSD1);
	while (gtm_mcsGetResetRAM(&MCSD1) == 1U) {
		;
	}

	/* Set round-robin scheduler policy */
	gtm_mcsSetScheduler(&MCSD1, SPC5_GTM_MCS_SCHEDULER_ROUND_ROBIN);

	/* Load the MCS program */
	gtm_mcsLoadProgram(&MCSD1, mcs0_mem, SIZE_MCS0_MEM, OFFSET_MCS0_MEM);

	/* Enable the channel */
	gtm_mcsEnableChannel(&MCSD1, MCS_CHANNEL0);
	gtm_mcsEnableChannel(&MCSD1, MCS_CHANNEL1);
	gtm_mcsEnableChannel(&MCSD1, MCS_CHANNEL2);
	gtm_mcsEnableChannel(&MCSD1, MCS_CHANNEL3);
}

/*
 * Application entry point.
 */
int main(void) {

  /* Initialization of all the imported components in the order specified in
     the application wizard. The function is generated automatically.*/
	componentsInit();

	LED1_OFF();
	LED2_OFF();
	LED3_OFF();

	/* Enable Interrupts */
	irqIsrEnable();

	/* Enable Clock Management Unit */
	gtm_cmuStart(&CMUD1);

	/* Enable Timer Base Unit */
	gtm_tbuStart(&TBUD1);

	/* Set a specific tooth wheel pattern */
	setToothWheel(PSM_CHANNEL0);

	/* Set initial RPMs */
	updateProfile(1000);

	/* Start providing data */
	gtm_psmStart(&PSMD1, PSM_CHANNEL0);

	/* ATOM Channel0 reads data, via ARU both words (high & low), from PSM FIFO0 Stream0 */
	gtm_atomSetDataSource(&ATOMD1, ATOM_CHANNEL0, SPC5_GTM_WRITE_ADDRESS_F2A0_F2A0_0);

	/* Connect ATOM0_CH0 to TIM0_CH0 */
	gtm_SetAuxIN(&GTMD, TIM_0, TIM_CHANNEL0, SPC5_GTM_IP_TIM_AUXIN_ATOM);

	/*
	 * ARU source address to read from.
	 * In compare mode, ARU delivers to ATOM CCU0 first, then CCU1,
	 * so set ATOM read address zero and read address one to same source address.
	 */

	/* Injection #1 */
	gtm_atomSetDataSource(&ATOMD2, ATOM_CHANNEL0, SPC5_GTM_WRITE_ADDRESS_MCS0_MCS0_9);
	gtm_atomSetDataSource1(&ATOMD2, ATOM_CHANNEL0, SPC5_GTM_WRITE_ADDRESS_MCS0_MCS0_9);

	/* Injection #2 */
	gtm_atomSetDataSource(&ATOMD2, ATOM_CHANNEL1, SPC5_GTM_WRITE_ADDRESS_MCS0_MCS0_10);
	gtm_atomSetDataSource1(&ATOMD2, ATOM_CHANNEL1, SPC5_GTM_WRITE_ADDRESS_MCS0_MCS0_10);

	/* Ignition #1 */
	gtm_atomSetDataSource(&ATOMD2, ATOM_CHANNEL2, SPC5_GTM_WRITE_ADDRESS_MCS0_MCS0_11);
	gtm_atomSetDataSource1(&ATOMD2, ATOM_CHANNEL2, SPC5_GTM_WRITE_ADDRESS_MCS0_MCS0_11);

	/* Ignition #2 */
	gtm_atomSetDataSource(&ATOMD2, ATOM_CHANNEL3, SPC5_GTM_WRITE_ADDRESS_MCS0_MCS0_12);
	gtm_atomSetDataSource1(&ATOMD2, ATOM_CHANNEL3, SPC5_GTM_WRITE_ADDRESS_MCS0_MCS0_12);

	/* Start ATOM for injection #1 event */
	gtm_atomStart(&ATOMD2, ATOM_CHANNEL0);

	/* Start ATOM for injection #2 event */
	gtm_atomStart(&ATOMD2, ATOM_CHANNEL1);

	/* Start ATOM for ignition #1 event */
	gtm_atomStart(&ATOMD2, ATOM_CHANNEL2);

	/* Start ATOM for ignition #2 event */
	gtm_atomStart(&ATOMD2, ATOM_CHANNEL3);

	/* Start ATOM for Tachometer event */
	gtm_atomStart(&ATOMD2, ATOM_CHANNEL6);

	/* Start ATOM for Reference Position (active/passive TDC) event */
	gtm_atomStart(&ATOMD2, ATOM_CHANNEL7);

	/* Initialize the DPLL */
	init_DPLL();

	/* Initialize the MCS */
	initMCS();

	/*
	 * Start crank simulation routing ATOM0_0 to TIM0_0
	 */
	gtm_timStart(&TIMD1, TIM_CHANNEL0);

	/* Start reading/writing */
	gtm_atomStart(&ATOMD1, ATOM_CHANNEL0);

	uint8_t counter = 0;
	int32_t rpm_incr = 1000;
	int32_t rpm = 1000;

	/*
	 * Application main loop.
	 *
	 * RPM is incremented every three seconds by 1000,
	 * up to 8000, then is gradually decreased to 1000.
	 */
	for ( ; ; ) {
		osalThreadDelayMilliseconds(1000);
		LED3_TOGGLE();
		counter++;
		if (counter == 3U) {
			rpm += rpm_incr;

			updateProfile((uint16_t)rpm);

			counter = 0U;
			if (rpm == 1000) {
				rpm_incr = 1000;
			}
			if (rpm == 8000) {
				rpm_incr = -1000;
			}
		}
	}
}
