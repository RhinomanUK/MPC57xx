For this test application the file debug.wsx points to the target configuration
file for SPC574K-DISP Discovery Board (stm_spc574k72_core2_debug_jtag.cfg).
