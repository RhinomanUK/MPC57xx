This application shows how to the use SWT Driver.
The watchdog is served in the SWT interrupt calback.

1) SWT is enabled with a timeout period of 1000ms.

2) The application loops for a while

3) The watchdog is served in the SWT interrupt callback.

4) After 10 times the watchdog is not longer served

5) A system reset happens

6) Application restarts
