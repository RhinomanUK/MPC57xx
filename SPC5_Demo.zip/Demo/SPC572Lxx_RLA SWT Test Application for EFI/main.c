/****************************************************************************
*
* Copyright © 2017-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY – NOT FOR USE IN PRODUCTION
*****************************************************************************/

/* Inclusion of the main header files of all the imported components in the
   order specified in the application wizard. The file is generated
   automatically.*/
#include "components.h"
#include "swt_lld_cfg.h"

static uint8_t serve_watchdog;

void swt2_callback(SWTDriver *swtp) {
  if (serve_watchdog == TRUE) {
    swt_lld_keep_alive(swtp);
  }
}

/*
 * Application entry point.
 */
int main(void) {

  uint8_t counter;

  /* Initialisation of all the imported components in the order specified in
     the application wizard. The function is generated automatically.*/
  componentsInit();

  /* Enable Interrupts */
  irqIsrEnable();

  /* Start watchdog driver */
  swt_lld_start(&SWTD3, &swt2_config);

  counter = 0;
  serve_watchdog = TRUE;

  /* Application main loop.*/
  for ( ; ; ) {

    /* serve the watchdog only for 10 times */
    counter++;

    if (counter > 10U) {
      serve_watchdog = FALSE;
    }

    osalThreadDelayMilliseconds(100);
  }
}
