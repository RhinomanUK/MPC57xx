This application demonstrates how to send and receive can message using MCAN.

Two CAN configured:
- MCAN_1 
- MCAN_2 

Using loopback features, each time a message is received in the configured RX buffer 
a led is toggled (one for MCAN_1 and one for MCAN_2)

Read could be perfomed in two ways:
- using can_lld_read function
- using callback function defined in each configuration created

By default the app uses callbacks. if you want to use read funciont instead
 - comment #define USE_READ_CALLBACK 
 - uncomment #define USE_READ_FUNCTION
 - remove rx buffer callbacks in both configurations (mcanconf and mcanconf1)
 
This software is released just as reference code 


