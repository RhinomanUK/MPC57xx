/****************************************************************************
*
* Copyright © 2015-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY – NOT FOR USE IN PRODUCTION
*****************************************************************************/

/* Inclusion of the main header files of all the imported components in the
 order specified in the application wizard. The file is generated
 automatically.*/
#include "components.h"
#include "can_lld_cfg.h"

static uint32_t counter;

/* comment this define and remove the callback field
 * in the configurator if you want to use the can_lld_receive
 * instead of the read callback routines
 */
#define USE_READ_CALLBACK

/* Use this define and remove the callback field
 * in the configurator if you want to use the can_lld_receive
 * instead of the read callback routines
 */
//#define USE_READ_FUNCTION

#if defined  USE_READ_CALLBACK
void mcanconf_rxreceive(uint32_t msgbuf, CANRxFrame crfp) {
  if (crfp.ID == 0x7f0U) {
    if (crfp.data32[1] == counter) {
    	pal_lld_togglepad(PORT_A, PA_LED1);
    }
  }
  (void)msgbuf;
}

void mcanconf1_rxreceive(uint32_t msgbuf, CANRxFrame crfp) {
  if (crfp.ID == 0x8901234UL) {
    if (crfp.data32[1] == counter) {
    	pal_lld_togglepad(PORT_A, PA_LED3);
    }
  }
  (void)msgbuf;
}
#endif
/*
 * Application entry point.
 */
int main(void) {

  CANTxFrame txf, txf1;
  uint32_t returnvalue;

  /* Initialization of all the imported components in the order specified in
   the application wizard. The function is generated automatically.*/
  componentsInit();

  can_lld_start(&CAND2, &can_config_mcanconf);  /*MCAN1*/
  can_lld_start(&CAND3, &can_config_mcanconf1); /*MCAN2*/

  txf.TYPE = CAN_ID_STD;
  txf.ID = 0x7f0U;
  txf.DLC = 8U;
  txf.data32[0] = 0xDDEEFFAAUL;

  txf1.TYPE = CAN_ID_XTD;
  txf1.ID = 0x8901234;
  txf1.DLC = 8U;
  txf1.data32[0] = 0xAABBCCDDUL;

  counter = 0UL;

  /* Enable Interrupts */
   irqIsrEnable();

  // can_lld_transmit(&CAND2, 0, &txf);

  /* Application main loop.*/
  for (;;) {

    txf.data32[1] = counter;
    txf1.data32[1] = counter;

    returnvalue = can_lld_transmit(&CAND2, CAN_ANY_TXBUFFER, &txf);
    osalThreadDelayMilliseconds(1);
    if (returnvalue != CAN_MSG_OK) {
      for (;;) {

      }
    }
    returnvalue = can_lld_transmit(&CAND3, CAN_ANY_TXBUFFER, &txf1);
    osalThreadDelayMilliseconds(1);
    if (returnvalue != CAN_MSG_OK) {
      for (;;) {

      }
    }

#if defined   USE_READ_FUNCTION
    {
      CANRxFrame rxf;

      returnvalue = can_lld_receive(&CAND2, CAN_ANY_RXBUFFER, &rxf);
      if (returnvalue == CAN_MSG_OK) {
        if (rxf.ID == 0x7f0U) {
          if (rxf.data32[1] == counter) {
        	  pal_lld_togglepad(PORT_A, PA_LED1);
          }
        }
      }
      returnvalue = can_lld_receive(&CAND3, CAN_ANY_RXBUFFER, &rxf);
      if (rxf.ID == 0x8901234UL) {
        if (rxf.data32[1] == counter) {
        	pal_lld_togglepad(PORT_A, PA_LED3);
        }
      }
    }
#endif

    osalThreadDelayMilliseconds(250);
    counter++;
  }
}
