By default the file debug.wsx points to the target configuration file for
SPC572LADPT80S minimodule (stm_spc572L64_minimodule_core2_debug_jtag.cfg).
For other platforms be careful to update the file debug.wsx in order to
point to the correct target configuration file.
