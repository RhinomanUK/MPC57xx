This app configures the following channels to be converted on SARADC supervisor
module (SARADC_B):

 - ANP[0] --> PB0 --> Regulator 0-5V RV1
 
 Conversion mode is set to SCAN and channels configuration is the following:

- ANP[0] - 12BIT conversion 

For each conversion read value is printed on serial port
 
This code is released just as reference code.
