/****************************************************************************
*
* Copyright © 2016-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY – NOT FOR USE IN PRODUCTION
*****************************************************************************/

/* Inclusion of the main header files of all the imported components in the
   order specified in the application wizard. The file is generated
   automatically.*/
#include "components.h"
#include "saradc_lld_cfg.h"

/* define a vector containing the channels to be converted */
#define NUMOFCHANNELS 1U
extern uint8_t anp[NUMOFCHANNELS];
extern uint16_t value[NUMOFCHANNELS];

/* set channels to convert */
uint8_t anp[NUMOFCHANNELS] = {0U};
uint16_t value[NUMOFCHANNELS] = {0U};

/* conversion callback */
void saradcconf_conv_cb(SARADCDriver *saradcp) {
  uint8_t i;
  /* Read converted channels */
  for (i = 0; i < NUMOFCHANNELS; i++) {
    value[i] = saradc_lld_readchannel(saradcp, anp[i]);
  }
}

/*
 * Application entry point.
 */
int main(void) {

  uint8_t i;
  SARADCDriver* driverUnderTest;

  /* change driverUnderTest value to test others SARADC modules. */
  driverUnderTest = &SARADC12DSV;

  /* Initialization of all the imported components in the order specified in
   the application wizard. The function is generated automatically.*/
  componentsInit();

  /* Enable Interrupts */
  irqIsrEnable();

  /* Start Serial Driver */
  sd_lld_start(&SD1, NULL);

  /* Start SARADC Driver */
  saradc_lld_start(driverUnderTest, &saradc_config_saradcconf);

  /* start SARADC conversion */
  saradc_lld_start_conversion(driverUnderTest);

  /* Application main loop.*/
  for (;;) {

    /* print converted value on serial port each 10ms */
    for (i = 0; i < NUMOFCHANNELS; i++) {
      printf("CHANNEL %d: VALUE: %d - ", anp[i], value[i]);
    }
    printf("\n\r");
    pal_lld_togglepad(PORT_A, PA_LED1);
    pal_lld_togglepad(PORT_A, PA_LED3);
    osalThreadDelayMilliseconds(100U);

  }
}

