In this test application PIT0 Timer is enabled and, using the RLA IRQ component, relative
interrupt vector is configured.

This code is reelased just as reference code