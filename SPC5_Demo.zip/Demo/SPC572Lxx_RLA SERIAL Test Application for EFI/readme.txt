This application shows how to the use the PAL and SERIAL driver. It writes
"hello world!" on serial port and lights 2 LEDs.

In order to receive from serial, please set the baud rate of the COM port on 
your PC to 38400.

This code is released just as reference code