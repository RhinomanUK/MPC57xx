/****************************************************************************
*
* Copyright © 2016-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY – NOT FOR USE IN PRODUCTION
*****************************************************************************/

/* Inclusion of the main header files of all the imported components in the
   order specified in the application wizard. The file is generated
   automatically.*/
#include "components.h"

/*
 * Application entry point.
 */
int main(void) {

  uint8_t message[]= "Hello World!\r\n";
  /* Initialization of all the imported components in the order specified in
     the application wizard. The function is generated automatically.*/
  componentsInit();

  /* Enable Interrupts */
  irqIsrEnable();

  /* Start Serial Driver */
  sd_lld_start(&SD1,NULL);

  /* Application main loop.*/
  for ( ; ; ) {
    if (sd_lld_write(&SD1, message, (uint16_t)(sizeof(message)/sizeof(message[0]))) == SERIAL_MSG_OK) {
      pal_lld_togglepad(PORT_A, PA_LED1);
      osalThreadDelayMilliseconds(300);
      pal_lld_togglepad(PORT_A, PA_LED3);
      osalThreadDelayMilliseconds(300);
    }
  }
}
