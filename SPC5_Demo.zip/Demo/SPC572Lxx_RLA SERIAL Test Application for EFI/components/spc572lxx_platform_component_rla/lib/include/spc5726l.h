/****************************************************************************
*
* Copyright � 2018-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY � NOT FOR USE IN PRODUCTION
*****************************************************************************/
  
/**************************************************************************
 * Example register & bit field write:                                    *
 *                                                                        *
 *  <MODULE>.<REGISTER>.B.<BIT> = 1;                                      *
 *  <MODULE>.<REGISTER>.R       = 0x10000000;                             *
 *                                                                        *
 **************************************************************************/ 
    
#ifndef _SPC572L_H_
#define _SPC572L_H_
    
#include "typedefs.h"
    
#ifdef __MWERKS__
#pragma push
#pragma ANSI_strict off
#endif  /* 
 */
/**************************************************************************/
/*                   Module: CMU                                          */
/**************************************************************************/
    struct CMU_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t SFM:1;
              vuint32_t:13;
            vuint32_t CKSEL1:2;
              vuint32_t:5;
            vuint32_t RCDIV:2;
            vuint32_t CME:1;
        } B;
    } CSR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:12;
            vuint32_t FD:20;
        } B;
    } FDR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:20;
            vuint32_t HFREF:12;
        } B;
    } HFREFR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:20;
            vuint32_t LFREF:12;
        } B;
    } LFREFR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:29;
            vuint32_t FHHI:1;
            vuint32_t FLLI:1;
            vuint32_t OLRI:1;
        } B;
    } ISR;

    uint8_t CMU_reserved1[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:12;
            vuint32_t MD:20;
        } B;
    } MDR;
};

/****************************************************************************/
/*       DMA Transfer Control Descriptor (TCD)                              */
/****************************************************************************/

struct EDMA_TCD_STD_tag {       /* for "standard" format TCDs (when EDMA.TCD[x].CITER.E_LINK==BITER.E_LINK=0 && EDMA.EMLM=0 ) */
    /* 00 */
    vuint32_t SADDR;            /* Source Address */

    /* 04 *//* Transfer Attributes */
    vuint16_t SMOD:5;           /* Source Address Modulo */
    vuint16_t SSIZE:3;          /* Source Data Transfer Size */
    vuint16_t DMOD:5;           /* Destination Address Modulo */
    vuint16_t DSIZE:3;          /* Destination Data Transfer Size */

    /* 06 */
    vint16_t SOFF;              /* Signed Source Address Offset */

    /* 08 */
    vuint32_t NBYTES;           /* Inner ("Minor") Byte Transfer Count */

    /* 0C */
    vint32_t SLAST;             /* Last Source Address Adjustment */

    /* 10 */
    vuint32_t DADDR;            /* Destination Address */

    /* 14 */
    vuint16_t CITER_ELINK:1;    /* Enable Channel-to-Channel        */
    /* Linking on Minor Loop Completion */
    vuint16_t CITER:15;         /* Current Major Iteration Count    */

    /* 16 */
    vint16_t DOFF;              /* Signed Destination Address Offset */

    /* 18 */
    vint32_t DLAST_SGA;         /* Last Destination Address Adjustment, or  */
    /* Scatter/Gather Address (if E_SG = 1)     */

    /* 1C */
    vuint16_t BITER_ELINK:1;    /* Enable Channel-to-Channel           */
    /* Linking on Minor Loop Complete      */
    vuint16_t BITER:15;         /* Starting ("Major") Iteration Count */

    /* 1E *//* Channel Control/Status */
    vuint16_t BWC:2;            /* bandwidth control */
    vuint16_t MAJORLINKCH:6;    /* enable channel-to-channel link */
    vuint16_t DONE:1;           /* channel done */
    vuint16_t ACTIVE:1;         /* channel active */
    vuint16_t MAJORELINK:1;     /* enable channel-to-channel link */
    vuint16_t ESG:1;            /* enable scatter/gather descriptor */
    vuint16_t DREQ:1;           /* disable ipd_req when done */
    vuint16_t INTHALF:1;        /* interrupt on citer = (biter >> 1) */
    vuint16_t INTMAJ:1;         /* interrupt on major loop completion */
    vuint16_t START:1;          /* explicit channel start */
};

struct EDMA_TCD_alt1_tag {      /*for alternate format TCDs (when EDMA.TCD[x].CITER.E_LINK==BITER.E_LINK=1 ) */

    /* 00 */
    vuint32_t SADDR;            /* Source Address */

    /* 04 *//* Transfer Attributes */
    vuint16_t SMOD:5;           /* Source Address Modulo */
    vuint16_t SSIZE:3;          /* Source Data Transfer Size */
    vuint16_t DMOD:5;           /* Destination Address Modulo */
    vuint16_t DSIZE:3;          /* Destination Data Transfer Size */

    /* 06 */
    vint16_t SOFF;              /* Signed Source Address Offset */

    /* 08 */
    vuint32_t NBYTES;           /* Inner ("Minor") Byte Transfer Count */

    /* 0C */
    vint32_t SLAST;             /* Last Source Address Adjustment */

    /* 10 */
    vuint32_t DADDR;            /* Destination Address */

    /* 14 */
    vuint16_t CITER_ELINK:1;    /* Enable Channel-to-Channel        */
    /* Linking on Minor Loop Completion */
    vuint16_t CITER_LINKCH:6;   /* Link Channel Number              */
    vuint16_t CITER:9;          /* Current Major Iteration Count    */

    /* 16 */
    vint16_t DOFF;              /* Signed Destination Address Offset */

    /* 18 */
    vint32_t DLAST_SGA;         /* Last Destination Address Adjustment, or  */
    /* Scatter/Gather Address (if E_SG = 1)     */

    /* 1C */
    vuint16_t BITER_ELINK:1;    /* Enable Channel-to-Channel           */
    /* Linking on Minor Loop Complete      */
    vuint16_t BITER_LINKCH:6;   /* Link Channel Number                 */
    vuint16_t BITER:9;          /* Starting ("Major") Iteration Count  */

    /* 1E *//* Channel Control/Status */
    vuint16_t BWC:2;            /* bandwidth control */
    vuint16_t MAJORLINKCH:6;    /* enable channel-to-channel link */
    vuint16_t DONE:1;           /* channel done */
    vuint16_t ACTIVE:1;         /* channel active */
    vuint16_t MAJORELINK:1;     /* enable channel-to-channel link */
    vuint16_t ESG:1;            /* enable scatter/gather descriptor */
    vuint16_t DREQ:1;           /* disable ipd_req when done */
    vuint16_t INTHALF:1;        /* interrupt on citer = (biter >> 1) */
    vuint16_t INTMAJ:1;         /* interrupt on major loop completion */
    vuint16_t START:1;          /* explicit channel start */
};

struct EDMA_TCD_alt2_tag {      /*       for alternate format TCDs (when EDMA.EMLM=1) */

    vuint32_t SADDR;            /* source address */

    vuint16_t SMOD:5;           /* source address modulo */
    vuint16_t SSIZE:3;          /* source transfer size */
    vuint16_t DMOD:5;           /* destination address modulo */
    vuint16_t DSIZE:3;          /* destination transfer size */
    vint16_t SOFF;              /* signed source address offset */

    vuint16_t SMLOE:1;          /* Source minor loop offset enable */
    vuint16_t DMLOE:1;          /* Destination minor loop offset enable */
    vuint32_t MLOFF:20;         /* Minor loop Offset */
    vuint16_t NBYTES:10;        /* inner (�minor�) byte count */

    vint32_t SLAST;             /* last destination address adjustment, or

                                   scatter/gather address (if e_sg = 1) */
    vuint32_t DADDR;            /* destination address */

    vuint16_t CITER_ELINK:1;
    vuint16_t CITER:15;

    vint16_t DOFF;              /* signed destination address offset */

    vint32_t DLAST_SGA;

    vuint16_t BITER_ELINK:1;    /* beginning ("major") iteration count */
    vuint16_t BITER:15;

    vuint16_t BWC:2;            /* bandwidth control */
    vuint16_t MAJORLINKCH:6;    /* enable channel-to-channel link */
    vuint16_t DONE:1;           /* channel done */
    vuint16_t ACTIVE:1;         /* channel active */
    vuint16_t MAJORELINK:1;     /* enable channel-to-channel link */
    vuint16_t ESG:1;            /* enable scatter/gather descriptor */
    vuint16_t DREQ:1;           /* disable ipd_req when done */
    vuint16_t INTHALF:1;        /* interrupt on citer = (biter >> 1) */
    vuint16_t INTMAJ:1;         /* interrupt on major loop completion */
    vuint16_t START:1;          /* explicit channel start */
};

/**************************************************************************/
/*                   Module: DMA                                          */
/**************************************************************************/
struct DMA_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:14;
            vuint32_t CX:1;
            vuint32_t ECX:1;
            vuint32_t GRP3PRI:2;
            vuint32_t GRP2PRI:2;
            vuint32_t GRP1PRI:2;
            vuint32_t GRP0PRI:2;
            vuint32_t EMLM:1;
            vuint32_t CLM:1;
            vuint32_t HALT:1;
            vuint32_t HOE:1;
            vuint32_t ERGA:1;
            vuint32_t ERCA:1;
            vuint32_t EDBG:1;
              vuint32_t:1;
        } B;
    } CR;

    union {
        vuint32_t R;
        struct {
            vuint32_t VLD:1;
              vuint32_t:14;
            vuint32_t ECX:1;
            vuint32_t GPE:1;
            vuint32_t CPE:1;
            vuint32_t ERRCHN:6;
            vuint32_t SAE:1;
            vuint32_t SOE:1;
            vuint32_t DAE:1;
            vuint32_t DOE:1;
            vuint32_t NCE:1;
            vuint32_t SGE:1;
            vuint32_t SBE:1;
            vuint32_t DBE:1;
        } B;
    } ES;

    union {
        vuint32_t R;
        struct {
            vuint32_t ERQ63:1;
            vuint32_t ERQ62:1;
            vuint32_t ERQ61:1;
            vuint32_t ERQ60:1;
            vuint32_t ERQ59:1;
            vuint32_t ERQ58:1;
            vuint32_t ERQ57:1;
            vuint32_t ERQ56:1;
            vuint32_t ERQ55:1;
            vuint32_t ERQ54:1;
            vuint32_t ERQ53:1;
            vuint32_t ERQ52:1;
            vuint32_t ERQ51:1;
            vuint32_t ERQ50:1;
            vuint32_t ERQ49:1;
            vuint32_t ERQ48:1;
            vuint32_t ERQ47:1;
            vuint32_t ERQ46:1;
            vuint32_t ERQ45:1;
            vuint32_t ERQ44:1;
            vuint32_t ERQ43:1;
            vuint32_t ERQ42:1;
            vuint32_t ERQ41:1;
            vuint32_t ERQ40:1;
            vuint32_t ERQ39:1;
            vuint32_t ERQ38:1;
            vuint32_t ERQ37:1;
            vuint32_t ERQ36:1;
            vuint32_t ERQ35:1;
            vuint32_t ERQ34:1;
            vuint32_t ERQ33:1;
            vuint32_t ERQ32:1;
        } B;
    } ERQH;

    union {
        vuint32_t R;
        struct {
            vuint32_t ERQ31:1;
            vuint32_t ERQ30:1;
            vuint32_t ERQ29:1;
            vuint32_t ERQ28:1;
            vuint32_t ERQ27:1;
            vuint32_t ERQ26:1;
            vuint32_t ERQ25:1;
            vuint32_t ERQ24:1;
            vuint32_t ERQ23:1;
            vuint32_t ERQ22:1;
            vuint32_t ERQ21:1;
            vuint32_t ERQ20:1;
            vuint32_t ERQ19:1;
            vuint32_t ERQ18:1;
            vuint32_t ERQ17:1;
            vuint32_t ERQ16:1;
            vuint32_t ERQ15:1;
            vuint32_t ERQ14:1;
            vuint32_t ERQ13:1;
            vuint32_t ERQ12:1;
            vuint32_t ERQ11:1;
            vuint32_t ERQ10:1;
            vuint32_t ERQ9:1;
            vuint32_t ERQ8:1;
            vuint32_t ERQ7:1;
            vuint32_t ERQ6:1;
            vuint32_t ERQ5:1;
            vuint32_t ERQ4:1;
            vuint32_t ERQ3:1;
            vuint32_t ERQ2:1;
            vuint32_t ERQ1:1;
            vuint32_t ERQ0:1;
        } B;
    } ERQL;

    union {
        vuint32_t R;
        struct {
            vuint32_t EEI63:1;
            vuint32_t EEI62:1;
            vuint32_t EEI61:1;
            vuint32_t EEI60:1;
            vuint32_t EEI59:1;
            vuint32_t EEI58:1;
            vuint32_t EEI57:1;
            vuint32_t EEI56:1;
            vuint32_t EEI55:1;
            vuint32_t EEI54:1;
            vuint32_t EEI53:1;
            vuint32_t EEI52:1;
            vuint32_t EEI51:1;
            vuint32_t EEI50:1;
            vuint32_t EEI49:1;
            vuint32_t EEI48:1;
            vuint32_t EEI47:1;
            vuint32_t EEI46:1;
            vuint32_t EEI45:1;
            vuint32_t EEI44:1;
            vuint32_t EEI43:1;
            vuint32_t EEI42:1;
            vuint32_t EEI41:1;
            vuint32_t EEI40:1;
            vuint32_t EEI39:1;
            vuint32_t EEI38:1;
            vuint32_t EEI37:1;
            vuint32_t EEI36:1;
            vuint32_t EEI35:1;
            vuint32_t EEI34:1;
            vuint32_t EEI33:1;
            vuint32_t EEI32:1;
        } B;
    } EEIH;

    union {
        vuint32_t R;
        struct {
            vuint32_t EEI31:1;
            vuint32_t EEI30:1;
            vuint32_t EEI29:1;
            vuint32_t EEI28:1;
            vuint32_t EEI27:1;
            vuint32_t EEI26:1;
            vuint32_t EEI25:1;
            vuint32_t EEI24:1;
            vuint32_t EEI23:1;
            vuint32_t EEI22:1;
            vuint32_t EEI21:1;
            vuint32_t EEI20:1;
            vuint32_t EEI19:1;
            vuint32_t EEI18:1;
            vuint32_t EEI17:1;
            vuint32_t EEI16:1;
            vuint32_t EEI15:1;
            vuint32_t EEI14:1;
            vuint32_t EEI13:1;
            vuint32_t EEI12:1;
            vuint32_t EEI11:1;
            vuint32_t EEI10:1;
            vuint32_t EEI9:1;
            vuint32_t EEI8:1;
            vuint32_t EEI7:1;
            vuint32_t EEI6:1;
            vuint32_t EEI5:1;
            vuint32_t EEI4:1;
            vuint32_t EEI3:1;
            vuint32_t EEI2:1;
            vuint32_t EEI1:1;
            vuint32_t EEI0:1;
        } B;
    } EEIL;

    union {
        vuint8_t R;
        struct {
            vuint8_t NOP:1;
            vuint8_t SAER:1;
            vuint8_t SERQ:6;
        } B;
    } SERQ;

    union {
        vuint8_t R;
        struct {
            vuint8_t NOP:1;
            vuint8_t CAER:1;
            vuint8_t CERQ:6;
        } B;
    } CERQ;

    union {
        vuint8_t R;
        struct {
            vuint8_t NOP:1;
            vuint8_t SAEE:1;
            vuint8_t SEEI:6;
        } B;
    } SEEI;

    union {
        vuint8_t R;
        struct {
            vuint8_t NOP:1;
            vuint8_t CAEE:1;
            vuint8_t CEEI:6;
        } B;
    } CEEI;

    union {
        vuint8_t R;
        struct {
            vuint8_t NOP:1;
            vuint8_t CAIR:1;
            vuint8_t CINT:6;
        } B;
    } CINT;

    union {
        vuint8_t R;
        struct {
            vuint8_t NOP:1;
            vuint8_t CAEI:1;
            vuint8_t CERR:6;
        } B;
    } CERR;

    union {
        vuint8_t R;
        struct {
            vuint8_t NOP:1;
            vuint8_t SAST:1;
            vuint8_t SSRT:6;
        } B;
    } SSRT;

    union {
        vuint8_t R;
        struct {
            vuint8_t NOP:1;
            vuint8_t CADN:1;
            vuint8_t CDNE:6;
        } B;
    } CDNE;

    union {
        vuint32_t R;
        struct {
            vuint32_t INT63:1;
            vuint32_t INT62:1;
            vuint32_t INT61:1;
            vuint32_t INT60:1;
            vuint32_t INT59:1;
            vuint32_t INT58:1;
            vuint32_t INT57:1;
            vuint32_t INT56:1;
            vuint32_t INT55:1;
            vuint32_t INT54:1;
            vuint32_t INT53:1;
            vuint32_t INT52:1;
            vuint32_t INT51:1;
            vuint32_t INT50:1;
            vuint32_t INT49:1;
            vuint32_t INT48:1;
            vuint32_t INT47:1;
            vuint32_t INT46:1;
            vuint32_t INT45:1;
            vuint32_t INT44:1;
            vuint32_t INT43:1;
            vuint32_t INT42:1;
            vuint32_t INT41:1;
            vuint32_t INT40:1;
            vuint32_t INT39:1;
            vuint32_t INT38:1;
            vuint32_t INT37:1;
            vuint32_t INT36:1;
            vuint32_t INT35:1;
            vuint32_t INT34:1;
            vuint32_t INT33:1;
            vuint32_t INT32:1;
        } B;
    } INTH;

    union {
        vuint32_t R;
        struct {
            vuint32_t INT31:1;
            vuint32_t INT30:1;
            vuint32_t INT29:1;
            vuint32_t INT28:1;
            vuint32_t INT27:1;
            vuint32_t INT26:1;
            vuint32_t INT25:1;
            vuint32_t INT24:1;
            vuint32_t INT23:1;
            vuint32_t INT22:1;
            vuint32_t INT21:1;
            vuint32_t INT20:1;
            vuint32_t INT19:1;
            vuint32_t INT18:1;
            vuint32_t INT17:1;
            vuint32_t INT16:1;
            vuint32_t INT15:1;
            vuint32_t INT14:1;
            vuint32_t INT13:1;
            vuint32_t INT12:1;
            vuint32_t INT11:1;
            vuint32_t INT10:1;
            vuint32_t INT9:1;
            vuint32_t INT8:1;
            vuint32_t INT7:1;
            vuint32_t INT6:1;
            vuint32_t INT5:1;
            vuint32_t INT4:1;
            vuint32_t INT3:1;
            vuint32_t INT2:1;
            vuint32_t INT1:1;
            vuint32_t INT0:1;
        } B;
    } INTL;

    union {
        vuint32_t R;
        struct {
            vuint32_t ERR63:1;
            vuint32_t ERR62:1;
            vuint32_t ERR61:1;
            vuint32_t ERR60:1;
            vuint32_t ERR59:1;
            vuint32_t ERR58:1;
            vuint32_t ERR57:1;
            vuint32_t ERR56:1;
            vuint32_t ERR55:1;
            vuint32_t ERR54:1;
            vuint32_t ERR53:1;
            vuint32_t ERR52:1;
            vuint32_t ERR51:1;
            vuint32_t ERR50:1;
            vuint32_t ERR49:1;
            vuint32_t ERR48:1;
            vuint32_t ERR47:1;
            vuint32_t ERR46:1;
            vuint32_t ERR45:1;
            vuint32_t ERR44:1;
            vuint32_t ERR43:1;
            vuint32_t ERR42:1;
            vuint32_t ERR41:1;
            vuint32_t ERR40:1;
            vuint32_t ERR39:1;
            vuint32_t ERR38:1;
            vuint32_t ERR37:1;
            vuint32_t ERR36:1;
            vuint32_t ERR35:1;
            vuint32_t ERR34:1;
            vuint32_t ERR33:1;
            vuint32_t ERR32:1;
        } B;
    } ERRH;

    union {
        vuint32_t R;
        struct {
            vuint32_t ERR31:1;
            vuint32_t ERR30:1;
            vuint32_t ERR29:1;
            vuint32_t ERR28:1;
            vuint32_t ERR27:1;
            vuint32_t ERR26:1;
            vuint32_t ERR25:1;
            vuint32_t ERR24:1;
            vuint32_t ERR23:1;
            vuint32_t ERR22:1;
            vuint32_t ERR21:1;
            vuint32_t ERR20:1;
            vuint32_t ERR19:1;
            vuint32_t ERR18:1;
            vuint32_t ERR17:1;
            vuint32_t ERR16:1;
            vuint32_t ERR15:1;
            vuint32_t ERR14:1;
            vuint32_t ERR13:1;
            vuint32_t ERR12:1;
            vuint32_t ERR11:1;
            vuint32_t ERR10:1;
            vuint32_t ERR9:1;
            vuint32_t ERR8:1;
            vuint32_t ERR7:1;
            vuint32_t ERR6:1;
            vuint32_t ERR5:1;
            vuint32_t ERR4:1;
            vuint32_t ERR3:1;
            vuint32_t ERR2:1;
            vuint32_t ERR1:1;
            vuint32_t ERR0:1;
        } B;
    } ERRL;

    union {
        vuint32_t R;
        struct {
            vuint32_t HRS63:1;
            vuint32_t HRS62:1;
            vuint32_t HRS61:1;
            vuint32_t HRS60:1;
            vuint32_t HRS59:1;
            vuint32_t HRS58:1;
            vuint32_t HRS57:1;
            vuint32_t HRS56:1;
            vuint32_t HRS55:1;
            vuint32_t HRS54:1;
            vuint32_t HRS53:1;
            vuint32_t HRS52:1;
            vuint32_t HRS51:1;
            vuint32_t HRS50:1;
            vuint32_t HRS49:1;
            vuint32_t HRS48:1;
            vuint32_t HRS47:1;
            vuint32_t HRS46:1;
            vuint32_t HRS45:1;
            vuint32_t HRS44:1;
            vuint32_t HRS43:1;
            vuint32_t HRS42:1;
            vuint32_t HRS41:1;
            vuint32_t HRS40:1;
            vuint32_t HRS39:1;
            vuint32_t HRS38:1;
            vuint32_t HRS37:1;
            vuint32_t HRS36:1;
            vuint32_t HRS35:1;
            vuint32_t HRS34:1;
            vuint32_t HRS33:1;
            vuint32_t HRS32:1;
        } B;
    } HRSH;

    union {
        vuint32_t R;
        struct {
            vuint32_t HRS31:1;
            vuint32_t HRS30:1;
            vuint32_t HRS29:1;
            vuint32_t HRS28:1;
            vuint32_t HRS27:1;
            vuint32_t HRS26:1;
            vuint32_t HRS25:1;
            vuint32_t HRS24:1;
            vuint32_t HRS23:1;
            vuint32_t HRS22:1;
            vuint32_t HRS21:1;
            vuint32_t HRS20:1;
            vuint32_t HRS19:1;
            vuint32_t HRS18:1;
            vuint32_t HRS17:1;
            vuint32_t HRS16:1;
            vuint32_t HRS15:1;
            vuint32_t HRS14:1;
            vuint32_t HRS13:1;
            vuint32_t HRS12:1;
            vuint32_t HRS11:1;
            vuint32_t HRS10:1;
            vuint32_t HRS9:1;
            vuint32_t HRS8:1;
            vuint32_t HRS7:1;
            vuint32_t HRS6:1;
            vuint32_t HRS5:1;
            vuint32_t HRS4:1;
            vuint32_t HRS3:1;
            vuint32_t HRS2:1;
            vuint32_t HRS1:1;
            vuint32_t HRS0:1;
        } B;
    } HRSL;

    uint8_t DMA_reserved1[200];

    union {
        vuint8_t R;
        struct {
            vuint8_t ECP:1;
            vuint8_t DPA:1;
            vuint8_t GRPPRI:2;
            vuint8_t CHPRI:4;
        } B;
    } DCHPRI[64];

    union {
        vuint8_t R;
        struct {
            vuint8_t EMI:1;
            vuint8_t PAL:1;
              vuint8_t:2;
            vuint8_t MID:4;
        } B;
    } DCHMID[64];

    uint8_t DMA_reserved2[3712];

    /* Select one of the following declarations depending on the DMA mode chosen */
//    struct EDMA_TCD_STD_tag TCD[64];    /* Standard Format   */
    struct EDMA_TCD_alt1_tag TCD[64]; 	/* CITER/BITER Link  */
    /* struct EDMA_TCD_alt2_tag TCD[64]; *//* Minor Loop Offset */
};
/**************************************************************************/
/*                   Module: DMACHMUX                                     */
/**************************************************************************/
struct DMACHMUX_tag {
    union {
        vuint8_t R;
        struct {
            vuint8_t ENBL:1;
            vuint8_t TRIG:1;
            vuint8_t SOURCE:6;
        } B;
    } CHCONFIG[8];
};
/**************************************************************************/
/*                   Module: DSPI                                         */
/**************************************************************************/
struct DSPI_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t MSTR:1;
            vuint32_t CONT_SCKE:1;
            vuint32_t DCONF:2;
            vuint32_t FRZ:1;
            vuint32_t MTFE:1;
            vuint32_t PCSSE:1;
            vuint32_t ROOE:1;
            vuint32_t PCSIS:8;
            vuint32_t DOZE:1;
            vuint32_t MDIS:1;
            vuint32_t DIS_TXF:1;
            vuint32_t DIS_RXF:1;
            vuint32_t CLR_TXF:1;
            vuint32_t CLR_RXF:1;
            vuint32_t SMPL_PT:2;
            vuint32_t:4;
            vuint32_t XSPI:1;
            vuint32_t FCPCS:1;
            vuint32_t PES:1;
            vuint32_t HALT:1;
        } B;
    } MCR;

    uint8_t DSPI_reserved1[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t SPI_TCNT:16;
              vuint32_t:16;
        } B;
    } TCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t DBR:1;    /* Master Mode */
            vuint32_t FMSZ:4;
            vuint32_t CPOL:1;
            vuint32_t CPHA:1;
            vuint32_t LSBFE:1;
            vuint32_t PCSSCK:2;
            vuint32_t PASC:2;
            vuint32_t PDT:2;
            vuint32_t PBR:2;
            vuint32_t CSSCK:4;
            vuint32_t ASC:4;
            vuint32_t DT:4;
            vuint32_t BR:4;
            // vuint32_t FMSZ:5; /* Slave Mode */
            // vuint32_t CPOL:1;
            // vuint32_t CPHA:1;
            // vuint32_t PE:1;
            // vuint32_t PP:1;
            // vuint32_t FMSZ5:1; 
            // vuint32_t:22;
        } B;
    } CTAR[8];

    union {
        vuint32_t R;
        struct {
            vuint32_t TCF:1;
            vuint32_t TXRXS:1;
            vuint32_t SPITCF:1;
            vuint32_t EOQF:1;
            vuint32_t TFUF:1;
            vuint32_t DSITCF:1;
            vuint32_t TFFF:1;
            vuint32_t BSYF:1;
            vuint32_t CMDTCF:1;
            vuint32_t DPEF:1;
            vuint32_t SPEF:1;
            vuint32_t DDIF:1;
            vuint32_t RFOF:1;
            vuint32_t TFIWF:1;
            vuint32_t RFDF:1;
            vuint32_t CMDFFF:1;
            vuint32_t TXCTR:4;
            vuint32_t TXNXTPTR:4;
            vuint32_t RXCTR:4;
            vuint32_t POPNXTPTR:4;
        } B;
    } SR;

    union {
        vuint32_t R;
        struct {
            vuint32_t TCF_RE:1;
            vuint32_t CMDFFF_RE:1;
            vuint32_t SPITCF_RE:1;
            vuint32_t EOQF_RE:1;
            vuint32_t TFUF_RE:1;
            vuint32_t DSITCF_RE:1;
            vuint32_t TFFF_RE:1;
            vuint32_t TFFF_DIRS:1;
            vuint32_t CMDTCF_RE:1;
            vuint32_t DPEF_RE:1;
            vuint32_t SPEF_RE:1;
            vuint32_t DDIF_RE:1;
            vuint32_t RFOF_RE:1;
            vuint32_t TFIWF_RE:1;
            vuint32_t RFDF_RE:1;
            vuint32_t RFDF_DIRS:1;
            vuint32_t CMDFFF_DIRS:1;
            vuint32_t DDIF_DIRS:1;
            vuint32_t:14;
        } B;
    } RSER;

    union {
        vuint32_t R;
        struct {
            vuint32_t CONT:1;   /* Master Mode */
            vuint32_t CTAS:3;
            vuint32_t EOQ:1;
            vuint32_t CTCNT:1;
            vuint32_t PE_MASC:1;
            vuint32_t PP_MCSC:1;
            vuint32_t PCS:8;
            vuint32_t TXDATA:16;
            // vuint32_t TXDATA:32; /* Slave Mode */
        } B;
    } PUSHR;

    union {
        vuint32_t R;
        struct {
            vuint32_t RXDATA:32;
        } B;
    } POPR;

    union {
        vuint32_t R;
        struct {
            vuint32_t TXCMD_TXDATA:16;
            vuint32_t TXDATA:16;
        } B;
    } TXFR[4];

    uint8_t DSPI_reserved2[48];

    union {
        vuint32_t R;
        struct {
            vuint32_t RXDATA:32;
        } B;
    } RXFR[4];

    uint8_t DSPI_reserved3[48];

    union {
        vuint32_t R;
        struct {
            vuint32_t :1;
            vuint32_t FMSZ4:1;
            vuint32_t :6;
            vuint32_t FMSZ5:1;
            vuint32_t :1;
            vuint32_t ITSB:1;
            vuint32_t TSBC:1;
            vuint32_t TXSS:1;
            vuint32_t TPOL:1;
            vuint32_t TRRE:1;
            vuint32_t CID:1;
            vuint32_t DCONT:1;
            vuint32_t DSICTAS:3;
            vuint32_t DMS:1;
            vuint32_t PES:1;
            vuint32_t PE:1;
            vuint32_t PP:1;
            vuint32_t DPCSx:8;
        } B;
    } DSICR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t SER_DATA:32;
        } B;
    } SDR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t ASER_DATA:32;
        } B;
    } ASDR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t COMP_DATA:32;
        } B;
    } COMPR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t DESER_DATA:32;
        } B;
    } DDR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t:2;
            vuint32_t TSBCNT:6;
            vuint32_t:5;
            vuint32_t DSI64E:1;          
            vuint32_t DSE1:1;
            vuint32_t DSE0:1;
            vuint32_t TRGPRD:8;
            vuint32_t DPCS1_x:8;
        } B;
    } DSICR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t SS:32;
        } B;
    } SSR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t IPS7:4;
            vuint32_t IPS6:4;
            vuint32_t IPS5:4;
            vuint32_t IPS4:4;
            vuint32_t IPS3:4;
            vuint32_t IPS2:4;
            vuint32_t IPS1:4;
            vuint32_t IPS0:4;
        } B;
    } PISR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t IPS15:4;
            vuint32_t IPS14:4;
            vuint32_t IPS13:4;
            vuint32_t IPS12:4;
            vuint32_t IPS11:4;
            vuint32_t IPS10:4;
            vuint32_t IPS9:4;
            vuint32_t IPS8:4;
        } B;
    } PISR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t IPS23:4;
            vuint32_t IPS22:4;
            vuint32_t IPS21:4;
            vuint32_t IPS20:4;
            vuint32_t IPS19:4;
            vuint32_t IPS18:4;
            vuint32_t IPS17:4;
            vuint32_t IPS16:4;
        } B;
    } PISR2;

    union {
        vuint32_t R;
        struct {
            vuint32_t IPS31:4;
            vuint32_t IPS30:4;
            vuint32_t IPS29:4;
            vuint32_t IPS28:4;
            vuint32_t IPS27:4;
            vuint32_t IPS26:4;
            vuint32_t IPS25:4;
            vuint32_t IPS24:4;
        } B;
    } PISR3;

    union {
        vuint32_t R;
        struct {
            vuint32_t MASK:32;
        } B;
    } DIMR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t DP:32;
        } B;
    } DPIR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t SER_DATA:32;
        } B;
    } SDR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t ASER_DATA:32;
        } B;
    } ASDR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t COMP_DATA:32;
        } B;
    } COMPR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t DESER_DATA:32;
        } B;
    } DDR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t SS:32;
        } B;
    } SSR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t IPS39:4;
            vuint32_t IPS38:4;
            vuint32_t IPS37:4;
            vuint32_t IPS36:4;
            vuint32_t IPS35:4;
            vuint32_t IPS34:4;
            vuint32_t IPS33:4;
            vuint32_t IPS32:4;
        } B;
    } PISR4;

    union {
        vuint32_t R;
        struct {
            vuint32_t IPS47:4;
            vuint32_t IPS46:4;
            vuint32_t IPS45:4;
            vuint32_t IPS44:4;
            vuint32_t IPS43:4;
            vuint32_t IPS42:4;
            vuint32_t IPS41:4;
            vuint32_t IPS40:4;
        } B;
    } PISR5;

    union {
        vuint32_t R;
        struct {
            vuint32_t IPS55:4;
            vuint32_t IPS54:4;
            vuint32_t IPS53:4;
            vuint32_t IPS52:4;
            vuint32_t IPS51:4;
            vuint32_t IPS50:4;
            vuint32_t IPS49:4;
            vuint32_t IPS48:4;
        } B;
    } PISR6;

    union {
        vuint32_t R;
        struct {
            vuint32_t IPS63:4;
            vuint32_t IPS62:4;
            vuint32_t IPS61:4;
            vuint32_t IPS60:4;
            vuint32_t IPS59:4;
            vuint32_t IPS58:4;
            vuint32_t IPS57:4;
            vuint32_t IPS56:4;
        } B;
    } PISR7;

    union {
        vuint32_t R;
        struct {
            vuint32_t MASK:32;
        } B;
    } DIMR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t DP:32;
        } B;
    } DPIR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t:15;
            vuint32_t FMSZE:1;
              vuint32_t:5;
            vuint32_t DTCP:11;
        } B;
    } CTARE[8];

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t CMDCTR:4;
            vuint32_t CMDNXTPTR:4;
        } B;
    } SREX;
};
/**************************************************************************/
/*                   Module: DTS                                          */
/**************************************************************************/
struct DTS_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:30;
            vuint32_t DTS_EN_B:1;
            vuint32_t DTS_EN:1;
        } B;
    } ENABLE;

    union {
        vuint32_t R;
        struct {
            vuint32_t AD:32;
        } B;
    } STARTUP;

    union {
        vuint32_t R;
        struct {
            vuint32_t ST:32;
        } B;
    } SEMAPHORE;

    union {
        vuint32_t R;
        struct {
            vuint32_t ST_B:32;
        } B;
    } SEMAPHORE_B;
};


/**************************************************************************/
/*                              Module: EIM                               */
/**************************************************************************/
struct EIM_tag {

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t GEIEN:1;
        } B;
    } EIMCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t EICH0EN:1;
            vuint32_t EICH1EN:1;
            vuint32_t EICH2EN:1;
            vuint32_t EICH3EN:1;
            vuint32_t EICH4EN:1;
            vuint32_t EICH5EN:1;
            vuint32_t:26;
        } B;
    } EICHEN;
  
    uint8_t EIM_reserved1[248];

    struct{

        union{
            vuint32_t R;
            struct {
                vuint32_t CHKBIT_MASK:8;
                vuint32_t:24;
            } B;
        }Word0;

        union{
            vuint32_t R;
            struct {
                  vuint32_t UDATA_MASK:32;
            } B;
        }Word1;
        union{
            vuint32_t R;
            struct {
                vuint32_t LDATA_MASK:32;
            } B;
        }Word2;

        uint8_t EIM_reserved[244];

    } EICHD[6];

};
/**************************************************************************/
/*                              Module: ERM                               */
/**************************************************************************/
struct ERM_tag {

    union {
        vuint32_t R;
        struct {
            vuint32_t HBERR:1;
            vuint32_t BABR:1;
            vuint32_t BABT:1;
            vuint32_t GRA:1;
            vuint32_t TXF:1;
            vuint32_t TXB:1;
            vuint32_t:19;
        } B;
    } ERM_CR;
    
    uint8_t ERM_reserved1[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t HBERR:1;
            vuint32_t BABR:1;
            vuint32_t BABT:1;
            vuint32_t GRA:1;
            vuint32_t TXF:1;
            vuint32_t TXB:1;
            vuint32_t:19;
        } B;
    } ERM_SR;

    uint8_t ERM_reserved2[236];

    struct {
        union {
              vuint32_t R;
              struct {
                  vuint32_t EAR:32;
              } B;
        } ERM_EAR;

        union {
              vuint32_t R;
              struct {
                  vuint32_t SYNDROME:8;
                  vuint32_t:24;
              } B;
        } ERM_SYN;

        uint8_t ERM_reserved3[8];

   }CH[8];


};
/**************************************************************************/
/*                              Module: FEC                               */
/**************************************************************************/
struct FEC_tag {
    uint8_t FEC_reserved1[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t HBERR:1;
            vuint32_t BABR:1;
            vuint32_t BABT:1;
            vuint32_t GRA:1;
            vuint32_t TXF:1;
            vuint32_t TXB:1;
            vuint32_t RXF:1;
            vuint32_t RXB:1;
            vuint32_t MII:1;
            vuint32_t EBERR:1;
            vuint32_t LC:1;
            vuint32_t RL:1;
            vuint32_t UN:1;
              vuint32_t:19;
        } B;
    } EIR;

    union {
        vuint32_t R;
        struct {
            vuint32_t HBERR:1;
            vuint32_t BABR:1;
            vuint32_t BABT:1;
            vuint32_t GRA:1;
            vuint32_t TXF:1;
            vuint32_t TXB:1;
            vuint32_t RXF:1;
            vuint32_t RXB:1;
            vuint32_t MII:1;
            vuint32_t EBERR:1;
            vuint32_t LC:1;
            vuint32_t RL:1;
            vuint32_t UN:1;
              vuint32_t:19;
        } B;
    } EIMR;

    uint8_t FEC_reserved2[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:7;
            vuint32_t RDAR:1;
              vuint32_t:24;
        } B;
    } RDAR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:7;
            vuint32_t TDAR:1;
              vuint32_t:24;
        } B;
    } TDAR;

    uint8_t FEC_reserved3[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t:30;
            vuint32_t ETHER_EN:1;
            vuint32_t RESET:1;
        } B;
    } ECR;

    uint8_t FEC_reserved4[24];

    union {
        vuint32_t R;
        struct {
            vuint32_t ST:2;
            vuint32_t OP:2;
            vuint32_t PA:5;
            vuint32_t RA:5;
            vuint32_t TA:2;
            vuint32_t DATA:16;
        } B;
    } MMFR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t DIS_PRE:1;
            vuint32_t MII_SPEED:6;
              vuint32_t:1;
        } B;
    } MSCR;

    uint8_t FEC_reserved5[28];

    union {
        vuint32_t R;
        struct {
            vuint32_t MIB_DIS:1;
            vuint32_t MIB_IDLE:1;
              vuint32_t:30;
        } B;
    } MIBC;

    uint8_t FEC_reserved6[28];

    union {
        vuint32_t R;
        struct {
            vuint32_t:5;
            vuint32_t MAX_FL:11;
              vuint32_t:10;
            vuint32_t FCE:1;
            vuint32_t BC_REJ:1;
            vuint32_t PROM:1;
            vuint32_t MII_MODE:1;
            vuint32_t DRT:1;
            vuint32_t LOOP:1;
        } B;
    } RCR;

    uint8_t FEC_reserved7[60];

    union {
        vuint32_t R;
        struct {
            vuint32_t:27;
            vuint32_t RFC_PAUSE:1;
            vuint32_t TFC_PAUSE:1;
            vuint32_t FDEN:1;
            vuint32_t HBC:1;
            vuint32_t GTS:1;
        } B;
    } TCR;

    uint8_t FEC_reserved8[28];

    union {
        vuint32_t R;
        struct {
            vuint32_t PADDR1:32;
        } B;
    } PALR;

    union {
        vuint32_t R;
        struct {
            vuint32_t PADDR2:16;
            vuint32_t TYPE:16;
        } B;
    } PAUR;

    union {
        vuint32_t R;
        struct {
            vuint32_t OPCODE:16;
            vuint32_t PAUSE_DUR:16;
        } B;
    } OPD;

    uint8_t FEC_reserved9[40];

    union {
        vuint32_t R;
        struct {
            vuint32_t IADDR1:32;
        } B;
    } IAUR;

    union {
        vuint32_t R;
        struct {
            vuint32_t IADDR2:32;
        } B;
    } IALR;

    union {
        vuint32_t R;
        struct {
            vuint32_t GADDR1:32;
        } B;
    } GAUR;

    union {
        vuint32_t R;
        struct {
            vuint32_t GADDR2:32;
        } B;
    } GALR;

    uint8_t FEC_reserved10[28];

    union {
        vuint32_t R;
        struct {
            vuint32_t:30;
            vuint32_t TFWR:2;
        } B;
    } TFWR;

    uint8_t FEC_reserved11[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:22;
            vuint32_t R_BOUND:8;
              vuint32_t:2;
        } B;
    } FRBR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:22;
            vuint32_t R_FSTART:8;
              vuint32_t:2;
        } B;
    } FRSR;

    uint8_t FEC_reserved12[44];

    union {
        vuint32_t R;
        struct {
            vuint32_t R_DES_START:30;
              vuint32_t:2;
        } B;
    } ERDSR;

    union {
        vuint32_t R;
        struct {
            vuint32_t X_DES_START:30;
              vuint32_t:2;
        } B;
    } ETDSR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:21;
            vuint32_t R_BUF_SIZE:7;
              vuint32_t:4;
        } B;
    } EMRBR;

    uint8_t FEC_reserved13[116];

    union {
        vuint32_t R;
    } RMON_T_DROP;              /* Count of frames not counted correctly */

    union {
        vuint32_t R;
    } RMON_T_PACKETS;           /* RMON Tx packet count */

    union {
        vuint32_t R;
    } RMON_T_BC_PKT;            /* RMON Tx Broadcast Packets */

    union {
        vuint32_t R;
    } RMON_T_MC_PKT;            /* RMON Tx Multicast Packets */

    union {
        vuint32_t R;
    } RMON_T_CRC_ALIGN;         /* RMON Tx Packets w CRC/Align error */

    union {
        vuint32_t R;
    } RMON_T_UNDERSIZE;         /* RMON Tx Packets < 64 bytes, good crc */

    union {
        vuint32_t R;
    } RMON_T_OVERSIZE;          /* RMON Tx Packets > MAX_FL bytes, good crc */

    union {
        vuint32_t R;
    } RMON_T_FRAG;              /* RMON Tx Packets < 64 bytes, bad crc */

    union {
        vuint32_t R;
    } RMON_T_JAB;               /* RMON Tx Packets > MAX_FL bytes, bad crc */

    union {
        vuint32_t R;
    } RMON_T_COL;               /* RMON Tx collision count */

    union {
        vuint32_t R;
    } RMON_T_P64;               /* RMON Tx 64 byte packets */

    union {
        vuint32_t R;
    } RMON_T_P65TO127;          /* RMON Tx 65 to 127 byte packets */

    union {
        vuint32_t R;
    } RMON_T_P128TO255;         /* RMON Tx 128 to 255 byte packets */

    union {
        vuint32_t R;
    } RMON_T_P256TO511;         /* RMON Tx 256 to 511 byte packets */

    union {
        vuint32_t R;
    } RMON_T_P512TO1023;        /* RMON Tx 512 to 1023 byte packets */

    union {
        vuint32_t R;
    } RMON_T_P1024TO2047;       /* RMON Tx 1024 to 2047 byte packets */

    union {
        vuint32_t R;
    } RMON_T_P_GTE2048;         /* RMON Tx packets w > 2048 bytes */

    union {
        vuint32_t R;
    } RMON_T_OCTETS;            /* RMON Tx Octets */

    union {
        vuint32_t R;
    } IEEE_T_DROP;              /* Count of frames not counted correctly */

    union {
        vuint32_t R;
    } IEEE_T_FRAME_OK;          /* Frames Transmitted OK */

    union {
        vuint32_t R;
    } IEEE_T_1COL;              /* Frames Transmitted with Single Collision */

    union {
        vuint32_t R;
    } IEEE_T_MCOL;              /* Frames Transmitted with Multiple Collisions */

    union {
        vuint32_t R;
    } IEEE_T_DEF;               /* Frames Transmitted after Deferral Delay */

    union {
        vuint32_t R;
    } IEEE_T_LCOL;              /* Frames Transmitted with Late Collision */

    union {
        vuint32_t R;
    } IEEE_T_EXCOL;             /* Frames Transmitted with Excessive Collisions */

    union {
        vuint32_t R;
    } IEEE_T_MACERR;            /* Frames Transmitted with Tx FIFO Underrun */

    union {
        vuint32_t R;
    } IEEE_T_CSERR;             /* Frames Transmitted with Carrier Sense Error */

    union {
        vuint32_t R;
    } IEEE_T_SQE;               /* Frames Transmitted with SQE Error */

    union {
        vuint32_t R;
    } IEEE_T_FDXFC;             /* Flow Control Pause frames transmitted */

    union {
        vuint32_t R;
    } IEEE_T_OCTETS_OK;         /* Octet count for Frames Transmitted w/o Error */

    uint8_t FEC_reserved14[8];

    union {
        vuint32_t R;
    } RMON_R_DROP;              /*  Count of frames not counted correctly  */

    union {
        vuint32_t R;
    } RMON_R_PACKETS;           /* RMON Rx packet count */

    union {
        vuint32_t R;
    } RMON_R_BC_PKT;            /* RMON Rx Broadcast Packets */

    union {
        vuint32_t R;
    } RMON_R_MC_PKT;            /* RMON Rx Multicast Packets */

    union {
        vuint32_t R;
    } RMON_R_CRC_ALIGN;         /* RMON Rx Packets w CRC/Align error */

    union {
        vuint32_t R;
    } RMON_R_UNDERSIZE;         /* RMON Rx Packets < 64 bytes, good crc */

    union {
        vuint32_t R;
    } RMON_R_OVERSIZE;          /* RMON Rx Packets > MAX_FL bytes, good crc */

    union {
        vuint32_t R;
    } RMON_R_FRAG;              /* RMON Rx Packets < 64 bytes, bad crc */

    union {
        vuint32_t R;
    } RMON_R_JAB;               /* RMON Rx Packets > MAX_FL bytes, bad crc */

    uint8_t FEC_reserved15[4];

    union {
        vuint32_t R;
    } RMON_R_P64;               /* RMON Rx 64 byte packets */

    union {
        vuint32_t R;
    } RMON_R_P65TO127;          /* RMON Rx 65 to 127 byte packets */

    union {
        vuint32_t R;
    } RMON_R_P128TO255;         /* RMON Rx 128 to 255 byte packets */

    union {
        vuint32_t R;
    } RMON_R_P256TO511;         /* RMON Rx 256 to 511 byte packets */

    union {
        vuint32_t R;
    } RMON_R_P512TO1023;        /* RMON Rx 512 to 1023 byte packets */

    union {
        vuint32_t R;
    } RMON_R_P1024TO2047;       /* RMON Rx 1024 to 2047 byte packets */

    union {
        vuint32_t R;
    } RMON_R_P_GTE2048;         /* RMON Rx packets w > 2048 bytes */

    union {
        vuint32_t R;
    } RMON_R_OCTETS;            /* RMON Rx Octets */

    union {
        vuint32_t R;
    } IEEE_R_DROP;              /* Count of frames not counted correctly */

    union {
        vuint32_t R;
    } IEEE_R_FRAME_OK;          /* Frames Received OK */

    union {
        vuint32_t R;
    } IEEE_R_CRC;               /* Frames Received with CRC Error */

    union {
        vuint32_t R;
    } IEEE_R_ALIGN;             /* Frames Received with Alignment Error */

    union {
        vuint32_t R;
    } IEEE_R_MACERR;            /* Receive Fifo Overflow count */

    union {
        vuint32_t R;
    } IEEE_R_FDXFC;             /* Flow Control Pause frames received */

    union {
        vuint32_t R;
    } IEEE_R_OCTETS_OK;         /* Octet count for Frames Rcvd w/o Error */
};
/**************************************************************************/
/*                   Module: FLASH                                        */
/**************************************************************************/
struct FLASH_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t EER:1;
            vuint32_t RWE:1;
            vuint32_t SBC:1;
            vuint32_t:1;
            vuint32_t PEAS:1;
            vuint32_t DONE:1;
            vuint32_t PEG:1;
            vuint32_t PECIE:1;
            vuint32_t FERS:1;
            vuint32_t:2;
            vuint32_t PGM:1;
            vuint32_t PSUS:1;
            vuint32_t ERS:1;
            vuint32_t ESUS:1;
            vuint32_t EHV:1;
        } B;
    } MCR;
    
    uint8_t FLASH_reserved1[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t :1;
            vuint32_t n8Kh:2;
            vuint32_t n256K:5;
            vuint32_t n64Kh:3;
            vuint32_t n32Kh:2;
            vuint32_t n16Kh:3;
            vuint32_t n64Km:3;
            vuint32_t n32Km:2;
            vuint32_t n16Km:3;
            vuint32_t n64Kl:3;
            vuint32_t n32Kl:2;
            vuint32_t n16Kl:3;
        } B;
    } MCRE;

    uint8_t FLASH_reserved2[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t TSLOCK:1;
            vuint32_t:1;
            vuint32_t LOWLOCK:14;
            vuint32_t MIDLOCK:16;
        } B;
    } LOCK0;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t HIGHLOCK:16;
        } B;
    } LOCK1;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t A256KLOCK:31;
        } B;
    } LOCK2;


    uint8_t FLASH_reserved3[28];

    union {
        vuint32_t R;
        struct {
              vuint32_t:2;
            vuint32_t LOWSEL:14;
            vuint32_t MIDSEL:16;
        } B;
    } SEL0;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t HIGHSEL:16;
        } B;
    } SEL1;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t A256KSEL:31;
        } B;
    } SEL2;


    uint8_t FLASH_reserved4[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t SAD:1;
            vuint32_t:7;
            vuint32_t ADDR:21;
              vuint32_t:3;
        } B;
    } ADR;

    union {
        vuint32_t R;
        struct {
            vuint32_t UTE:1;
            vuint32_t SBCE:1;
            vuint32_t:18;
              vuint32_t:2;
            vuint32_t NAIBP:1;
            vuint32_t AIBPE:1;
            vuint32_t:1;
            vuint32_t AISUS:1;
            vuint32_t MRE:1;
            vuint32_t MRV:1;
            vuint32_t:1;
            vuint32_t AIS:1;
            vuint32_t AIE:1;
            vuint32_t AID:1;
        } B;
    } UT0;
    
    union {
        vuint32_t R;
        struct {
            vuint32_t MISR:32;
        } B;
    } UM0;
    
    union {
        vuint32_t R;
        struct {
            vuint32_t MISR:32;
        } B;
    } UM1;

    union {
        vuint32_t R;
        struct {
            vuint32_t MISR:32;
        } B;
    } UM2;

    union {
        vuint32_t R;
        struct {
            vuint32_t MISR:32;
        } B;
    } UM3;

    uint8_t FLASH_reserved5[16];

    union {
        vuint32_t R;
        struct {
            vuint32_t MISR:32;
        } B;
    } UM8;

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t MISR:1;
        } B;
    } UM9;

    union {
        vuint32_t R;
        struct {
              vuint32_t:2;
            vuint32_t LOWOPP:14;
            vuint32_t MIDOPP:16;
        } B;
    } OPP0;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t HIGHOPP:16;
        } B;
    } OPP1;

    union {
        vuint32_t R;
        struct {
            vuint32_t A256KOPP:32;
        } B;
    } OPP2;

    uint8_t FLASH_reserved6[1];

    union {
        vuint32_t R;
        struct {
            vuint32_t A256KOPP:32;
        } B;
    } TDMPC;


};

/**************************************************************************/
/*                   Module: GTMINT                                       */
/**************************************************************************/
struct GTMINT_tag {
    /*    ST Apps: fixed to 48 32-bit word instead of 48 8-bit word    */
    uint32_t GTMINT_reserved0[48];

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t MDIS:1;
            vuint32_t:13;
            vuint32_t AEISREN:1;
            vuint32_t:1;
            vuint32_t STPS:1;
            vuint32_t:14;
        } B;
    } MCR;

    uint8_t GTMINT_reserved1[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:22;
            vuint32_t INTCLR_PTR:10;
        } B;
    } CLR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t AEISRST:1;
        } B;
    } AEICR;
};

/**************************************************************************/
/*                   Module: INTC                                         */
/**************************************************************************/
struct INTC_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:19;
            vuint32_t HVEN3:1;
              vuint32_t:3;
            vuint32_t HVEN2:1;
              vuint32_t:3;
            vuint32_t HVEN1:1;
            vuint32_t:3;
            vuint32_t HVEN0:1;
        } B;
    } BCR;

    uint8_t INTC_reserved1[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t:26;
            vuint32_t PRI:6;
        } B;
    } CPR[1];

    vuint32_t R100[3];

    union {
        vuint32_t R;
        struct {
            vuint32_t VTBA:20;
            vuint32_t INTVEC:10;
            vuint32_t:2;
        } B;
    } IACKR[1];

    vuint32_t R200[3];

    union {
        vuint32_t R;
        struct {
            vuint32_t EOI:32;
        } B;
    } EOIR[1];

    vuint32_t R300[3];

    union {
        vuint8_t R;
        struct {
            vuint8_t:6;
            vuint8_t SET:1;
            vuint8_t CLR:1;
        } B;
    } SSCIR[32];

    union {
        vuint16_t R;
        struct {
            vuint16_t PRC_SEL:4;
            vuint16_t:3;
            vuint16_t SWT:1;
            vuint16_t:2;
            vuint16_t PRI:6;
        } B;
    } PSR[1024];
};
/**************************************************************************/
/*                   Module: JDC                                          */
/**************************************************************************/
struct JDC_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:15;
            vuint32_t JIN_IEN:1;
              vuint32_t:15;
            vuint32_t JOUT_IEN:1;
        } B;
    } MCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:13;
            vuint32_t JIN_RDY:1;
              vuint32_t:1;
            vuint32_t JIN_INT:1;
              vuint32_t:13;
            vuint32_t JOUT_RDY:1;
              vuint32_t:1;
            vuint32_t JOUT_INT:1;
        } B;
    } MSR;

    union {
        vuint32_t R;
        struct {
            vuint32_t JOUT_IPSData:32;
        } B;
    } JOUT_IPS;

    union {
        vuint32_t R;
        struct {
            vuint32_t JIN_IPSData:32;
        } B;
    } JIN_IPS;
};
//**************************************************************************/
/*                   Module: JTAGM                                        */
/**************************************************************************/
struct JTAGM_tag {
    union {
        vuint32_t R;
        struct {
			vuint32_t SWRESET:1;
			vuint32_t evto0_sense:2;
			vuint32_t evto1_sense:2;
			vuint32_t evto_IE:1;
			vuint32_t evti0_assert:1;
			vuint32_t evti1_assert:1;
			vuint32_t:8;
			vuint32_t:2;
			vuint32_t inter_jtag_frame_timer:6;
			vuint32_t:1;
			vuint32_t SIE:1;
			vuint32_t IIE:1;
			vuint32_t TCKSEL:3;
			vuint32_t jtagm_JCOMP:1;
                        vuint32_t DTM:1;

        } B;
    } MCR;

    union {
        vuint32_t R;
        struct {
	    vuint32_t:2;					/* SW mode */
   	    vuint32_t:6; // All 0s
            vuint32_t dci_status:8;			
            vuint32_t evto0_edge:1;
            vuint32_t evto1_edge:1;
            vuint32_t SPU_INT_CLR:1;
            vuint32_t SPU_INT:1;
            vuint32_t:1;
            vuint32_t Nexus_err:1;
            vuint32_t Idle:1;
            vuint32_t NR:1;
            vuint32_t evto0_clr:1;
            vuint32_t evto1_clr:1;
            vuint32_t:6;                              
        } B;
    } SR;

    union {
        vuint32_t R;
        struct {
            vuint32_t TMS_HIGH:32;
        } B;
    } DOR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t TMS_LOW:28;
            vuint32_t:4;
        } B;
    } DOR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t TDI_HIGH:32;
        } B;
    } DOR2;

    union {
        vuint32_t R;
        struct {
            vuint32_t TDI_LOW:28;
            vuint32_t:3;
            vuint32_t Send:1;
        } B;
    } DOR3;

    uint8_t JTAGM_rerserved1[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t TDO_LOW:32;
        } B;
    } DIR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t TDO_HIGH:28;
            vuint32_t:4;
        } B;
    } DIR1;
}; // end of module JTAGM
/**************************************************************************/
/*                   Module: LINFlexD                                     */
/**************************************************************************/
struct LINFlexD_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t CCD:1;
            vuint32_t CFD:1;
            vuint32_t LASE:1;
            vuint32_t AUTOWU:1;
            vuint32_t MBL:4;
            vuint32_t BF:1;
            vuint32_t:1;
            vuint32_t LBKM:1;
            vuint32_t MME:1;
            vuint32_t SSBL:1;
            vuint32_t RBLM:1;
            vuint32_t SLEEP:1;
            vuint32_t INIT:1;
        } B;
    } LINCR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t SZIE:1;
            vuint32_t OCIE:1;
            vuint32_t BEIE:1;
            vuint32_t CEIE:1;
            vuint32_t HEIE:1;
            vuint32_t:2;
            vuint32_t FEIE:1;
            vuint32_t BOIE:1;
            vuint32_t LSIE:1;
            vuint32_t WUIE:1;
            vuint32_t DBFIE:1;
            vuint32_t DBEIE_TOIE:1;
            vuint32_t DRIE:1;
            vuint32_t DTIE:1;
            vuint32_t HRIE:1;
        } B;
    } LINIER;

    union {
        vuint32_t R;
        struct {
            vuint32_t:12;
            vuint32_t AUTOSYNC_COMP:1;
            vuint32_t RDC:3;
            vuint32_t LINS:4;
            vuint32_t:2;
            vuint32_t RMB:1;
            vuint32_t DRBNE:1;
            vuint32_t RXbusy:1;
            vuint32_t RDI:1;
            vuint32_t WUF:1;
            vuint32_t DBFF:1;
            vuint32_t DBEF:1;
            vuint32_t DRF:1;
            vuint32_t DTF:1;
            vuint32_t HRF:1;
        } B;
    } LINSR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t SZF:1;
            vuint32_t OCF:1;
            vuint32_t BEF:1;
            vuint32_t CEF:1;
            vuint32_t SFEF:1;
            vuint32_t SDEF:1;
            vuint32_t IDPEF:1;
            vuint32_t FEF:1;
            vuint32_t BOF:1;
            vuint32_t:6;
            vuint32_t NF:1;
        } B;
    } LINESR;

    union {
        vuint32_t R;
        struct {
            vuint32_t MIS:1;
            vuint32_t CSP:3;
            vuint32_t ODR:4;
            vuint32_t ROSE:1;
            vuint32_t NEF:3;
            vuint32_t DTU:1;
            vuint32_t SBUR:2;
            vuint32_t WLS:1;
            vuint32_t TDFL_TFC:3;
            vuint32_t RDFL_RFC:3;
            vuint32_t RFBM:1;
            vuint32_t TFBM:1;
            vuint32_t WL1:1;
            vuint32_t PC1:1;
            vuint32_t RxEn:1;
            vuint32_t TxEn:1;
            vuint32_t PC0:1;
            vuint32_t PCE:1;
            vuint32_t WL0:1;
            vuint32_t UART:1;
        } B;
    } UARTCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t SZF:1;
            vuint32_t OCF:1;
            vuint32_t PE:4;
            vuint32_t RMB:1;
            vuint32_t FEF:1;
            vuint32_t BOF:1;
            vuint32_t RDI:1;
            vuint32_t WUF:1;
            vuint32_t RFNE:1;
            vuint32_t TO:1;
            vuint32_t DRF_RFE:1;
            vuint32_t DTF_TFF:1;
            vuint32_t NF:1;
        } B;
    } UARTSR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:21;
            vuint32_t MODE:1;
            vuint32_t IOT:1;
            vuint32_t TOCE:1;
            vuint32_t CNT:8;
        } B;
    } LINTCSR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t OC2:8;
            vuint32_t OC1:8;
        } B;
    } LINOCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:20;
            vuint32_t RTO:4;
            vuint32_t:1;
            vuint32_t HTO:7;
        } B;
    } LINTOCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:28;
            vuint32_t FBR:4;
        } B;
    } LINFBRR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:12;
            vuint32_t IBR:20;
        } B;
    } LINIBRR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t CF:8;
        } B;
    } LINCFR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t TBDE:1;
            vuint32_t IOBE:1;
            vuint32_t IOPE:1;
            vuint32_t WURQ:1;
            vuint32_t DDRQ:1;
            vuint32_t DTRQ:1;
            vuint32_t ABRQ:1;
            vuint32_t HTRQ:1;
            vuint32_t:8;
        } B;
    } LINCR2;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t DFL:6;
            vuint32_t DIR:1;
            vuint32_t CCS:1;
            vuint32_t:2;
            vuint32_t ID:6;
        } B;
    } BIDR;

    union {
        vuint32_t R;
        struct {
            vuint32_t DATA3:8;
            vuint32_t DATA2:8;
            vuint32_t DATA1:8;
            vuint32_t DATA0:8;
        } B;
    } BDRL;

    union {
        vuint32_t R;
        struct {
            vuint32_t DATA7:8;
            vuint32_t DATA6:8;
            vuint32_t DATA5:8;
            vuint32_t DATA4:8;
        } B;
    } BDRM;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t FACT:16;
        } B;
    } IFER;

    union {
        vuint32_t R;
        struct {
            vuint32_t:27;
            vuint32_t IFMI:5;
        } B;
    } IFMI;

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t IFM:8;
        } B;
    } IFMR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t DFL:6;
            vuint32_t DIR:1;
            vuint32_t CCS:1;
            vuint32_t:2;
            vuint32_t ID:6;
        } B;
    } IFCR[16];

    union {
        vuint32_t R;
        struct {
            vuint32_t:26;
            vuint32_t TDFBM:1;
            vuint32_t RDFBM:1;
            vuint32_t TDLIS:1;
            vuint32_t RDLIS:1;
            vuint32_t STOP:1;
            vuint32_t SR:1;
        } B;
    } GCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:20;
            vuint32_t PTO:12;
        } B;
    } UARTPTO;

    union {
        vuint32_t R;
        struct {
            vuint32_t:20;
            vuint32_t CTO:12;
        } B;
    } UARTCTO;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t DTE:16;
        } B;
    } DMATXE;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t DTE:16;
        } B;
    } DMARXE;
};
/**************************************************************************/
/*                   Module: LFAST                                        */
/**************************************************************************/
struct LFAST_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t MSEN:1;
              vuint32_t:6;
            vuint32_t IPGDBG:1;
              vuint32_t:7;
            vuint32_t LSSEL:1;
            vuint32_t DRFEN:1;
            vuint32_t RXEN:1;
            vuint32_t TXEN:1;
              vuint32_t:8;
            vuint32_t TXARBD:1;
            vuint32_t CTSEN:1;
              vuint32_t:1;
            vuint32_t DRFRST:1;
            vuint32_t DATAEN:1;
        } B;
    } MCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:15;
            vuint32_t DRMD:1;
              vuint32_t:7;
            vuint32_t RDR:1;
              vuint32_t:7;
            vuint32_t TDR:1;
        } B;
    } SCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t SMPSEL:8;
              vuint32_t:20;
            vuint32_t CORRTH:3;
            vuint32_t :1;
            //vuint32_t PHSSEL:1;
        } B;
    } COCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:6;
            vuint32_t CLKTST:1;
            vuint32_t LPON:1;
              vuint32_t:5;
            vuint32_t LPMOD:3;
            vuint32_t LPFRMTH:16;
        } B;
    } TMCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:15;
            vuint32_t LPCNTEN:1;
            vuint32_t LPFMCNT:16;
        } B;
    } ALCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:12;
            vuint32_t DRCNT:4;
              vuint32_t:16;
        } B;
    } RCDCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t HSCNT:8;
              vuint32_t:4;
            vuint32_t LSCNT:4;
            vuint32_t HWKCNT:8;
              vuint32_t:4;
            vuint32_t LWKCNT:4;
        } B;
    } SLCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:14;
            vuint32_t ICLCSEQ:1;
            vuint32_t SNDICLC:1;
              vuint32_t:8;
            vuint32_t ICLCPLD:8;
        } B;
    } ICR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:15;
            vuint32_t PNGREQ:1;
            vuint32_t PNGAUTO:1;
              vuint32_t:7;
            vuint32_t PNGPYLD:8;
        } B;
    } PICR;

    uint8_t LFAST_reserved1[8];

    union {
        vuint32_t R;
        struct {
            vuint32_t:10;
            vuint32_t RCTSMX:6;
              vuint32_t:10;
            vuint32_t RCTSMN:6;
        } B;
    } RFCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:14;
            vuint32_t TXIIE:1;
            vuint32_t TXOVIE:1;
              vuint32_t:11;
            vuint32_t TXPNGIE:1;
              vuint32_t:1;
            vuint32_t TXUNSIE:1;
            vuint32_t TXICLCIE:1;
            vuint32_t TXDTIE:1;
        } B;
    } TIER;

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t RXUOIE:1;
            vuint32_t RXMNIE:1;
            vuint32_t RXMXIE:1;
            vuint32_t RXUFIE:1;
            vuint32_t RXOFIE:1;
            vuint32_t RXSZIE:1;
            vuint32_t RXICIE:1;
            vuint32_t RXLCEIE:1;
              vuint32_t:12;
            vuint32_t RXCTSIE:1;
            vuint32_t RXDIE:1;
            vuint32_t RXUNSIE:1;
              vuint32_t:1;
        } B;
    } RIER;

    union {
        vuint32_t R;
        struct {
            vuint32_t:18;
            vuint32_t ICPFIE:1;
            vuint32_t ICPSIE:1;
            vuint32_t ICPRIE:1;
            vuint32_t ICTOIE:1;
            vuint32_t ICLPIE:1;
            vuint32_t ICCTIE:1;
            vuint32_t ICTDIE:1;
            vuint32_t ICTEIE:1;
            vuint32_t ICRFIE:1;
            vuint32_t ICRSIE:1;
            vuint32_t ICTFIE:1;
            vuint32_t ICTSIE:1;
            vuint32_t ICPOFIE:1;
            vuint32_t ICPONIE:1;
        } B;
    } RIIER;

    vuint8_t LFAST_reserved[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t SWWKLD:1;
            vuint32_t SWSLPLD:1;
            vuint32_t SWWKLR:1;
            vuint32_t SWSLPLR:1;
            vuint32_t SWOFFLD:1;
            vuint32_t SWONLD:1;
            vuint32_t SWOFFLR:1;
            vuint32_t SWONLR:1;
            vuint32_t LVRXOFF:1;
            vuint32_t LVTXOE:1;
            vuint32_t TXCMUX:1;
            vuint32_t LVRFEN:1;
            vuint32_t LVLPEN:1;
              vuint32_t:5;
            vuint32_t LVRXOP:3;
            vuint32_t LVTXOP:1;
            vuint32_t LVCKSS:1;
            vuint32_t LVCKP:1;
        } B;
    } LCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:15;
            vuint32_t USNDRQ:1;
              vuint32_t:9;
            vuint32_t UNSHDR:7;
        } B;
    } UNSTCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNTXD:32;
        } B;
    } UNSTDR8;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNTXD:32;
        } B;
    } UNSTDR7;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNTXD:32;
        } B;
    } UNSTDR6;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNTXD:32;
        } B;
    } UNSTDR5;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNTXD:32;
        } B;
    } UNSTDR4;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNTXD:32;
        } B;
    } UNSTDR3;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNTXD:32;
        } B;
    } UNSTDR2;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNTXD:32;
        } B;
    } UNSTDR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNTXD:32;
        } B;
    } UNSTDR0;

    uint8_t LFAST_reserved2[20];

    union {
        vuint32_t R;
        struct {
            vuint32_t DUALMD:1;
            vuint32_t:12;
            vuint32_t LRMD:1;
            vuint32_t LDSM:1;
            vuint32_t DRSM:1;
            vuint32_t:11;
            vuint32_t LPTXDN:1;
            vuint32_t LPFPDV:1;
            vuint32_t LPCPDV:1;
            vuint32_t LPCHDV:1;
            vuint32_t LPCSDV:1;
        } B;
    } GSR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t RXPNGD:8;
        } B;
    } PISR;

    uint8_t LFAST_reserved3[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t:2;
            vuint32_t RXDCNT:6;
            vuint32_t:5;
            vuint32_t RXFCNT:3;
            vuint32_t:2;
            vuint32_t TXDCNT:6;
            vuint32_t:5;
            vuint32_t TXFCNT:3;
        } B;
    } DFSR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:14;
            vuint32_t TXIEF:1;
            vuint32_t TXOVF:1;
            vuint32_t:11;
            vuint32_t TXPNGF:1;
            vuint32_t:1;
            vuint32_t TXUNSF:1;
            vuint32_t TXICLCF:1;
            vuint32_t TXDTF:1;
        } B;
    } TISR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t RXUOF:1;
            vuint32_t RXMNF:1;
            vuint32_t RXMXF:1;
            vuint32_t RXUFF:1;
            vuint32_t RXOFF:1;
            vuint32_t RXSZF:1;
            vuint32_t RXICF:1;
            vuint32_t RXLCEF:1;
            vuint32_t:12;
            vuint32_t RXCTSF:1;
            vuint32_t RXDF:1;
            vuint32_t RXUNSF:1;
              vuint32_t:1;
        } B;
    } RISR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:18;
            vuint32_t ICPFF:1;
            vuint32_t ICPSF:1;
            vuint32_t ICPRF:1;
            vuint32_t ICTOF:1;
            vuint32_t ICLPF:1;
            vuint32_t ICCTF:1;
            vuint32_t ICTDF:1;
            vuint32_t ICTEF:1;
            vuint32_t ICRFF:1;
            vuint32_t ICRSF:1;
            vuint32_t ICTFF:1;
            vuint32_t ICTSF:1;
            vuint32_t ICPOFF:1;
            vuint32_t ICPONF:1;
        } B;
    } RIISR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:28;
            vuint32_t LDSLPS:1;
            vuint32_t LRSLPS:1;
            vuint32_t LDPDS:1;
            vuint32_t LRPDS:1;
        } B;
    } PLLLSR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:23;
            vuint32_t URXDV:1;
            vuint32_t:5;
            vuint32_t URPCNT:3;
        } B;
    } UNSRSR;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNRXD:32;
        } B;
    } UNSRDR8;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNRXD:32;
        } B;
    } UNSRDR7;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNRXD:32;
        } B;
    } UNSRDR6;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNRXD:32;
        } B;
    } UNSRDR5;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNRXD:32;
        } B;
    } UNSRDR4;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNRXD:32;
        } B;
    } UNSRDR3;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNRXD:32;
        } B;
    } UNSRDR2;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNRXD:32;
        } B;
    } UNSRDR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t UNRXD:32;
        } B;
    } UNSRDR0;
};
/**************************************************************************/
/*                   Module: MCAN                                         */
/**************************************************************************/
struct MCAN_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t REL:4;
            vuint32_t STEP:4;
            vuint32_t SUBSTEP:4;
            vuint32_t YEAR:4;
            vuint32_t MON:8;
            vuint32_t DAY:8;
        } B;
    } CREL;

    union {
        vuint32_t R;
        struct {
            vuint32_t ETV:32;
        } B;
    } ENDN;

    uint8_t MCAN_reserved1[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t TDCO:4;
            vuint32_t TDC:1;
            vuint32_t :1;
            vuint32_t FBRP:10;
            vuint32_t :4;
            vuint32_t FTSEG:4;
            vuint32_t :1;
            vuint32_t FTSEG2:3;
            vuint32_t :2;
            vuint32_t FSJW:2;

        } B;
    } FBTP;

    union {
        vuint32_t R;
        struct {
            vuint32_t:19;
            vuint32_t TDCV:5;
            vuint32_t RX:1;
            vuint32_t TX:2;
            vuint32_t LBCK:1;
              vuint32_t:4;
        } B;
    } TEST;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t WDV:8;
            vuint32_t WDC:8;
        } B;
    } RWD;

    union {
        vuint32_t R;
        struct {
            vuint32_t:18;
            vuint32_t FACT:1;
            vuint32_t LACT:1;
            vuint32_t CMR:2;
            vuint32_t CME:2;
            vuint32_t TEST:1;
            vuint32_t DAR:1;
            vuint32_t MON:1;
            vuint32_t CSR:1;
            vuint32_t CSA:1;
            vuint32_t ASM:1;
            vuint32_t CCE:1;
            vuint32_t INIT:1;
        } B;
    } CCCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:6;
            vuint32_t BRP:10;
              vuint32_t:2;
            vuint32_t TSEG1:6;
            vuint32_t TSEG2:4;
            vuint32_t SJW:4;
        } B;
    } BTP;

    union {
        vuint32_t R;
        struct {
            vuint32_t:12;
            vuint32_t TCP:4;
              vuint32_t:14;
            vuint32_t TSS:2;
        } B;
    } TSCC;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t TSC:16;
        } B;
    } TSCV;

    union {
        vuint32_t R;
        struct {
            vuint32_t TOP:16;
              vuint32_t:13;
            vuint32_t TOS:2;
            vuint32_t ETOC:1;
        } B;
    } TOCC;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t TSC:16;
        } B;
    } TOCV;

    uint8_t MCAN_reserved2[16];

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t CEL:8;
              vuint32_t RP:1;
            vuint32_t REC:7;
            vuint32_t TEC:8;
        } B;
    } ECR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:18;
            vuint32_t REDL:1;
            vuint32_t RBRS:1;
            vuint32_t RESI:1;
            vuint32_t FLEC:3;
            vuint32_t BO:1;
            vuint32_t EW:1;
            vuint32_t EP:1;
            vuint32_t ACT:2;
            vuint32_t LEC:3;
        } B;
    } PSR;

    uint8_t MCAN_reserved3[8];

    union {
        vuint32_t R;
        struct {
            vuint32_t STE:1;
            vuint32_t FOE:1;
            vuint32_t ACKE:1;
            vuint32_t BE:1;
            vuint32_t CRCE:1;
            vuint32_t WDI:1;
            vuint32_t BO:1;
            vuint32_t EW:1;
            vuint32_t EP:1;
            vuint32_t ELO:1;
            vuint32_t BEU:1;
            vuint32_t BEC:1;
            vuint32_t DRX:1;
            vuint32_t TOO:1;
            vuint32_t UMD:1;
            vuint32_t TSW:1;
            vuint32_t TEFL:1;
            vuint32_t TEFF:1;
            vuint32_t TEFW:1;
            vuint32_t TEFN:1;
            vuint32_t TFE:1;
            vuint32_t TCF:1;
            vuint32_t TC:1;
            vuint32_t HPM:1;
            vuint32_t RF1L:1;
            vuint32_t RF1F:1;
            vuint32_t RF1W:1;
            vuint32_t RF1N:1;
            vuint32_t RF0L:1;
            vuint32_t RF0F:1;
            vuint32_t RF0W:1;
            vuint32_t RF0N:1;
        } B;
    } IR;

    union {
        vuint32_t R;
        struct {
            vuint32_t STEE:1;
            vuint32_t FOEE:1;
            vuint32_t ACKEE:1;
            vuint32_t BEE:1;
            vuint32_t CRCEE:1;
            vuint32_t WDIE:1;
            vuint32_t BOE:1;
            vuint32_t EWE:1;
            vuint32_t EPE:1;
            vuint32_t ELOE:1;
            vuint32_t BEUE:1;
            vuint32_t BECE:1;
            vuint32_t DRXE:1;
            vuint32_t TOOE:1;
            vuint32_t UMDE:1;
            vuint32_t TSWE:1;
            vuint32_t TEFLE:1;
            vuint32_t TEFFE:1;
            vuint32_t TEFWE:1;
            vuint32_t TEFNE:1;
            vuint32_t TFEE:1;
            vuint32_t TCFE:1;
            vuint32_t TCE:1;
            vuint32_t HPME:1;
            vuint32_t RF1LE:1;
            vuint32_t RF1FE:1;
            vuint32_t RF1WE:1;
            vuint32_t RF1NE:1;
            vuint32_t RF0LE:1;
            vuint32_t RF0FE:1;
            vuint32_t RF0WE:1;
            vuint32_t RF0NE:1;
        } B;
    } IE;

    union {
        vuint32_t R;
        struct {
            vuint32_t STEL:1;
            vuint32_t FOEL:1;
            vuint32_t ACKEL:1;
            vuint32_t BEL:1;
            vuint32_t CRCEL:1;
            vuint32_t WDIL:1;
            vuint32_t BOL:1;
            vuint32_t EWL:1;
            vuint32_t EPL:1;
            vuint32_t ELOL:1;
            vuint32_t BEUL:1;
            vuint32_t BECL:1;
            vuint32_t DRXL:1;
            vuint32_t TOOL:1;
            vuint32_t UMDL:1;
            vuint32_t TSWL:1;
            vuint32_t TEFLL:1;
            vuint32_t TEFFL:1;
            vuint32_t TEFWL:1;
            vuint32_t TEFNL:1;
            vuint32_t TFEL:1;
            vuint32_t TCFL:1;
            vuint32_t TCL:1;
            vuint32_t HPML:1;
            vuint32_t RF1LL:1;
            vuint32_t RF1FL:1;
            vuint32_t RF1WL:1;
            vuint32_t RF1NL:1;
            vuint32_t RF0LL:1;
            vuint32_t RF0FL:1;
            vuint32_t RF0WL:1;
            vuint32_t RF0NL:1;
        } B;
    } ILS;

    union {
        vuint32_t R;
        struct {
            vuint32_t:30;
            vuint32_t EINT1:1;
            vuint32_t EINT0:1;
        } B;
    } ILE;

    uint8_t MCAN_reserved4[32];

    union {
        vuint32_t R;
        struct {
            vuint32_t:26;
            vuint32_t ANFS:2;
            vuint32_t ANFE:2;
            vuint32_t RRFS:1;
            vuint32_t RRFE:1;
        } B;
    } GFC;

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t LSS:8;
            vuint32_t FLSSA:14;
              vuint32_t:2;
        } B;
    } SIDFC;

    union {
        vuint32_t R;
        struct {
            vuint32_t:9;
            vuint32_t LSE:7;
            vuint32_t FLESA:14;
              vuint32_t:2;
        } B;
    } XIDFC;

    uint8_t MCAN_reserved5[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:3;
            vuint32_t EIDM:29;
        } B;
    } XIDAM;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t FLST:1;
            vuint32_t FIDX:7;
            vuint32_t MSI:2;
            vuint32_t BIDX:6;
        } B;
    } HPMS;

    union {
        vuint32_t R;
        struct {
            vuint32_t ND:32;
        } B;
    } NDAT1;


    union {
        vuint32_t R;
        struct {
            vuint32_t ND:32;
        } B;
    } NDAT2;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t F0WM:7;
              vuint32_t:1;
            vuint32_t F0S:7;
            vuint32_t F0SA:14;
              vuint32_t:2;
        } B;
    } RXF0C;

    union {
        vuint32_t R;
        struct {
            vuint32_t:6;
            vuint32_t RF0L:1;
            vuint32_t F0F:1;
              vuint32_t:10;
            vuint32_t F0GI:6;
              vuint32_t:1;
            vuint32_t F0FL:7;
        } B;
    } RXF0S;

    union {
        vuint32_t R;
        struct {
            vuint32_t:26;
            vuint32_t F0AI:6;
        } B;
    } RXF0A;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t RBSA:14;
            vuint32_t :2;
        } B;
    } RXBC;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t F1WM:7;
              vuint32_t:1;
            vuint32_t F1S:7;
            vuint32_t F1SA:14;
              vuint32_t:2;
        } B;
    } RXF1C;

    union {
        vuint32_t R;
        struct {
            vuint32_t DMS:2;
            vuint32_t:4;
            vuint32_t RF1L:1;
            vuint32_t F1F:1;
            vuint32_t:2;
            vuint32_t F1PI:6;
            vuint32_t:2;
            vuint32_t F1GI:6;
              vuint32_t:1;
            vuint32_t F1FL:7;
        } B;
    } RXF1S;

    union {
        vuint32_t R;
        struct {
            vuint32_t:26;
            vuint32_t F1AI:6;
        } B;
    } RXF1A;

    uint8_t MCAN_reserved8[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t TQFM:1;
            vuint32_t TQFS:6;
              vuint32_t:2;
            vuint32_t NDTB:6;
            vuint32_t TBSA:14;
              vuint32_t:2;
        } B;
    } TXBC;

    union {
        vuint32_t R;
        struct {
            vuint32_t:10;
            vuint32_t TFQF:1;
            vuint32_t TFQPI:5;
            vuint32_t:3;
            vuint32_t TFGI:5;
            vuint32_t:2;
            vuint32_t TFFL:6;
        } B;
    } TXFQS;

    uint8_t MCAN_reserved9[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t TRP:32;
        } B;
    } TXBRP;

    union {
        vuint32_t R;
        struct {
            vuint32_t AR:32;
        } B;
    } TXBAR;

    union {
        vuint32_t R;
        struct {
            vuint32_t CR:32;
        } B;
    } TXBCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t TO:32;
        } B;
    } TXBTO;

    union {
        vuint32_t R;
        struct {
            vuint32_t CF:32;
        } B;
    } TXBCF;

    union {
        vuint32_t R;
        struct {
            vuint32_t TIE:32;
        } B;
    } TXBTIE;

    union {
        vuint32_t R;
        struct {
            vuint32_t CFIE:32;
        } B;
    } TXBCIE;

    uint8_t MCAN_reserved10[8];

    union {
        vuint32_t R;
        struct {
            vuint32_t:2;
            vuint32_t EFWM:6;
              vuint32_t:2;
            vuint32_t EFS:6;
            vuint32_t EFSA:14;
              vuint32_t:2;
        } B;
    } TXEFC;

    union {
        vuint32_t R;
        struct {
            vuint32_t:6;
            vuint32_t TEFL:1;
            vuint32_t EFF:1;
            vuint32_t:3;
            vuint32_t EFPI:5;
            vuint32_t:3;
            vuint32_t EFGI:5;
            vuint32_t:2;
            vuint32_t EFFL:6;
        } B;
    } TXEFS;

    union {
        vuint32_t R;
        struct {
            vuint32_t:27;
            vuint32_t EFAI:5;
        } B;
    } TXEFA;
};
/**************************************************************************/
/*                   Module: CCCU                                         */
/**************************************************************************/
struct CCCU_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t REL:4;
            vuint32_t STEP:4;
            vuint32_t SUBSTEP:4;
            vuint32_t YEAR:4;
            vuint32_t MON:8;
            vuint32_t DAY:8;
        } B;
    } CREL;

    union {
        vuint32_t R;
        struct {
            vuint32_t SWR:1;
            vuint32_t unused_0:11;
            vuint32_t CDIV:4;
            vuint32_t OCPM:8;
            vuint32_t CFL:1;
            vuint32_t BCC:1;
            vuint32_t unused_1:1;
            vuint32_t TQBT:4;
        } B;
    } CCFG;

    union {
        vuint32_t R;
        struct {
            vuint32_t CALS:2;
            vuint32_t unused_0:1;
            vuint32_t TQC:11;
            vuint32_t OCPC:18;
        } B;
    } CSTAT;

    union {
        vuint32_t R;
        struct {
            vuint32_t WDV:16;
            vuint32_t WDC:16;
        } B;
    } CWD;

    union {
        vuint32_t R;
        struct {
            vuint32_t unused_0:30;
            vuint32_t CSC:1;
            vuint32_t CWE:1;
        } B;
    } CUIR;

    union {
        vuint32_t R;
        struct {
            vuint32_t unused_0:30;
            vuint32_t CSCE:1;
            vuint32_t CWEE:1;
        } B;
    } CUIE;
};
/**************************************************************************/
/*                   Module: MC_CGM                                       */
/**************************************************************************/
struct MC_CGM_tag {	
    union {
        vuint8_t R;
        struct {
            vuint8_t SDUR:8;
        } B;
    }PCS_SDUR;

    uint8_t MC_CGM_reserved1[3];

	union {
		vuint32_t R;
		struct{
			vuint32_t INIT:16;
			vuint32_t :8;
			vuint32_t RATE:8;
		}B;
	}PCS_DIVC1;

	union {
		vuint32_t R;
		struct{
			vuint32_t :12;
			vuint32_t DIVS:20;
		}B;
	}PCS_DIVS1;

	union {
		vuint32_t R;
		struct{
			vuint32_t :12;
			vuint32_t DIVE:20;
		}B;
	}PCS_DIVE1;

		union {
		vuint32_t R;
		struct{
			vuint32_t INIT:16;
			vuint32_t :8;
			vuint32_t RATE:8;
		}B;
	}PCS_DIVC2;

	union {
		vuint32_t R;
		struct{
			vuint32_t :12;
			vuint32_t DIVS:20;
		}B;
	}PCS_DIVS2;

	union {
		vuint32_t R;
		struct{
			vuint32_t :12;
			vuint32_t DIVE:20;
		}B;
	}PCS_DIVE2;

	
	union {
		vuint32_t R;
		struct{
			vuint32_t INIT:16;
			vuint32_t :8;
			vuint32_t RATE:8;
		}B;
	}PCS_DIVC3;

	union {
		vuint32_t R;
		struct{
			vuint32_t :12;
			vuint32_t DIVS:20;
		}B;
	}PCS_DIVS3;

	union {
		vuint32_t R;
		struct{
			vuint32_t :12;
			vuint32_t DIVE:20;
		}B;
	}PCS_DIVE3;

	
    uint8_t MC_CGM_reserved3[188];

    union {
        vuint32_t R;
        struct {
            vuint32_t :4;
            vuint32_t SELSTAT:4;
            vuint32_t :4;
            vuint32_t SWTRG:3;
            vuint32_t SWIP:1;
            vuint32_t :16;
        } B;
    }SC_SS;

    union {
        vuint32_t R;
        struct{
            vuint32_t DE:1;
            vuint32_t :9;
            vuint32_t DIV:6;
            vuint32_t :16;
        } B;
    }SC_DC[2];

    uint8_t MC_CGM_reserved4[16];

    union {
        vuint32_t R;
        struct {
            vuint32_t :4;
            vuint32_t SELCTL:4;
            vuint32_t :24;
        } B;
    }AC0_SC;

    union {
        vuint32_t R;
        struct {
            vuint32_t :4;
            vuint32_t SELSTAT:4;
            vuint32_t :24;
        } B;
    }AC0_SS;

    union {
        vuint32_t R;
        struct{
            vuint32_t DE:1;
            vuint32_t :11;
            vuint32_t DIV:4;
            vuint32_t :16;
        } B;
    }AC0_DC0;

    union {
        vuint32_t R;
        struct{
            vuint32_t DE:1;
            vuint32_t :8;
            vuint32_t DIV:7;
            vuint32_t :16;
        } B;
    }AC0_DC1;

    union {
        vuint32_t R;
        struct{
            vuint32_t DE:1;
            vuint32_t :8;
            vuint32_t DIV:7;
            vuint32_t :16;
        } B;
    }AC0_DC2;

   

    uint8_t MC_CGM_reserved5[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t :4;
            vuint32_t SELCTL:4;
            vuint32_t :24;
        } B;
    }AC1_SC;

    union {
        vuint32_t R;
        struct {
            vuint32_t :4;
            vuint32_t SELSTAT:4;
            vuint32_t :24;
        } B;
    }AC1_SS;

    union {
        vuint32_t R;
        struct {
            vuint32_t DE:1;
            vuint32_t :8;
            vuint32_t DIV:7;
            vuint32_t :16;
        } B;
    }AC1_DC0;

    uint8_t MC_CGM_reserved6[28];


    union {
        vuint32_t R;
        struct {
            vuint32_t DE:1;
            vuint32_t :8;
            vuint32_t DIV:7;
            vuint32_t :16;
        } B;
    }AC2_DC0;

    uint8_t MC_CGM_reserved7[20];

    union {
        vuint32_t R;
        struct {
            vuint32_t :4;
            vuint32_t SELCTL:4;
            vuint32_t :24;
        } B;
    }AC3_SC;

    union {
        vuint32_t R;
        struct {
            vuint32_t :4;
            vuint32_t SELSTAT:4;
            vuint32_t :24;
        } B;
    }AC3_SS;

    uint8_t MC_CGM_reserved8[120];

    union {
        vuint32_t R;
        struct {
            vuint32_t :4;
            vuint32_t SELCTL:4;
            vuint32_t :24;
        } B;
    }AC7_SC;

    union {
        vuint32_t R;
        struct {
            vuint32_t :4;
            vuint32_t SELSTAT:4;
            vuint32_t :24;
        } B;
    }AC7_SS;

    union {
        vuint32_t R;
        struct {
            vuint32_t DE:1;
            vuint32_t :6;
            vuint32_t DIV:9;
            vuint32_t :16;
        } B;
    }AC7_DC0;

    uint8_t MC_CGM_reserved12[20];

    union {
        vuint32_t R;
        struct {
            vuint32_t :4;
            vuint32_t SELCTL:4;
            vuint32_t :24;
        } B;
    }AC8_SC;

    union {
        vuint32_t R;
        struct {
            vuint32_t :4;
            vuint32_t SELSTAT:4;
            vuint32_t :24;
        } B;
    }AC8_SS;

    union {
        vuint32_t R;
        struct {
            vuint32_t DE:1;
            vuint32_t :9;
            vuint32_t DIV:6;
            vuint32_t :16;
        } B;
    }AC8_DC0;

    uint8_t MC_CGM_reserved13[52];

    union {
        vuint32_t R;
        struct {
            vuint32_t :4;
            vuint32_t SELCTL:4;
            vuint32_t :24;
        } B;
    }AC10_SC;

    union {
        vuint32_t R;
        struct {
            vuint32_t :4;
            vuint32_t SELSTAT:4;
            vuint32_t :24;
        } B;
    }AC10_SS;

    union {
        vuint32_t R;
        struct {
            vuint32_t DE:1;
            vuint32_t :11;
            vuint32_t DIV:4;
            vuint32_t :16;
        } B;
    }AC10_DC0;

    uint8_t MC_CGM_reserved15[20];

    union {
        vuint32_t R;
        struct {
            vuint32_t :4;
            vuint32_t SELCTL:4;
            vuint32_t :24;
        } B;
    }AC11_SC;

    union {
        vuint32_t R;
        struct {
            vuint32_t :4;
            vuint32_t SELSTAT:4;
            vuint32_t :24;
        } B;
    }AC11_SS;

    union {
        vuint32_t R;
        struct {
            vuint32_t DE:1;
            vuint32_t :11;
            vuint32_t DIV:4;
            vuint32_t :14;
            vuint32_t DIV_FMT:2;
        } B;
    }AC11_DC0;

    union {
        vuint32_t R;
        struct {
            vuint32_t DE:1;
            vuint32_t :11;
            vuint32_t DIV:4;
            vuint32_t :16;
        } B;
    }AC11_DC1;
};

/**************************************************************************/
/*                   Module: MC_ME                                        */
/**************************************************************************/
struct MC_ME_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t S_CURRENT_MODE:4;
            vuint32_t S_MTRANS:1;
            vuint32_t:3;
            vuint32_t S_PDO:1;
            vuint32_t:2;
            vuint32_t S_MVR:1;
            vuint32_t:2;
            vuint32_t S_FLA:2;
            vuint32_t:9;
            vuint32_t S_PLL0:1;
            vuint32_t S_XOSC:1;
            vuint32_t S_IRC:1;
            vuint32_t S_SYSCLK:4;
        } B;
    } GS;

    union {
        vuint32_t R;
        struct {
            vuint32_t TARGET_MODE:4;
            vuint32_t:12;
            vuint32_t KEY:16;
        } B;
    } MCTL;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t RESET_DEST:1;
            vuint32_t:4;
            vuint32_t STOP0:1;
            vuint32_t:1;
            vuint32_t HALT0:1;
            vuint32_t RUN3:1;
            vuint32_t RUN2:1;
            vuint32_t RUN1:1;
            vuint32_t RUN0:1;
            vuint32_t DRUN:1;
            vuint32_t SAFE:1;
            vuint32_t TEST:1;
            vuint32_t RESET_FUNC:1;
        } B;
    } ME;

    union {
        vuint32_t R;
        struct {
            vuint32_t:26;
            vuint32_t I_ICONF_CC:1;
            vuint32_t I_ICONF_CU:1;
            vuint32_t I_ICONF:1;
            vuint32_t I_IMODE:1;
            vuint32_t I_SAFE:1;
            vuint32_t I_MTC:1;
        } B;
    } IS;

    union {
        vuint32_t R;
        struct {
            vuint32_t:26;
            vuint32_t M_ICONF_CC:1;
            vuint32_t M_ICONF_CU:1;
            vuint32_t M_ICONF:1;
            vuint32_t M_IMODE:1;
            vuint32_t M_SAFE:1;
            vuint32_t M_MTC:1;
        } B;
    } IM;

    union {
        vuint32_t R;
        struct {
            vuint32_t:27;
            vuint32_t S_MTI:1;
            vuint32_t S_MRI:1;
            vuint32_t S_DMA:1;
            vuint32_t S_NMA:1;
            vuint32_t S_SEA:1;
        } B;
    } IMTS;

    union {
        vuint32_t R;
        struct {
            vuint32_t PREVIOUS_MODE:4;
            vuint32_t:4;
            vuint32_t MPH_BUSY:1;
            vuint32_t:2;
            vuint32_t PMC_PROG:1;
            vuint32_t DBG_MODE:1;
            vuint32_t CCKL_PROG:1;
            vuint32_t PCS_PROG:1;
            vuint32_t SMR:1;
            vuint32_t:1;
            vuint32_t VREG_CSRC_SC:1;
            vuint32_t CSRC_CSRC_SC:1;
            vuint32_t IRC_SC:1;
            vuint32_t SCSRC_SC:1;
            vuint32_t SYSCLK_SW:1;
            vuint32_t:1;
            vuint32_t FLASH_SC:1;
            vuint32_t CDP_PRPH_224_255:1;
            vuint32_t:4;
            vuint32_t CDP_PRPH_64_95:1;
            vuint32_t CDP_PRPH_32_63:1;
            vuint32_t CDP_PRPH_0_31:1;
        } B;
    } DMTS;

    uint8_t MC_ME_reserved1[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t PWRLVL:3;
            vuint32_t:4;
            vuint32_t PDO:1;
            vuint32_t:2;
            vuint32_t MVRON:1;
            vuint32_t:2;
            vuint32_t FLAON:2;
            vuint32_t:9;
            vuint32_t PLL0ON:1;
            vuint32_t XOSCON:1;
            vuint32_t IRCON:1;
            vuint32_t SYSCLK:4;
        } B;
    } RESET_MC;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t PWRLVL:3;
            vuint32_t:4;
            vuint32_t PDO:1;
            vuint32_t:2;
            vuint32_t MVRON:1;
            vuint32_t:2;
            vuint32_t FLAON:2;
            vuint32_t:9;
            vuint32_t PLL0ON:1;
            vuint32_t XOSCON:1;
            vuint32_t IRCON:1;
            vuint32_t SYSCLK:4;
        } B;
    } TEST_MC;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t PWRLVL:3;
            vuint32_t:4;
            vuint32_t PDO:1;
            vuint32_t:2;
            vuint32_t MVRON:1;
            vuint32_t:2;
            vuint32_t FLAON:2;
            vuint32_t:9;
            vuint32_t PLL0ON:1;
            vuint32_t XOSCON:1;
            vuint32_t IRCON:1;
            vuint32_t SYSCLK:4;
        } B;
    } SAFE_MC;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t PWRLVL:3;
            vuint32_t:4;
            vuint32_t PDO:1;
            vuint32_t:2;
            vuint32_t MVRON:1;
            vuint32_t:2;
            vuint32_t FLAON:2;
            vuint32_t:9;
            vuint32_t PLL0ON:1;
            vuint32_t XOSCON:1;
            vuint32_t IRCON:1;
            vuint32_t SYSCLK:4;
        } B;
    } DRUN_MC;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t PWRLVL:3;
            vuint32_t:4;
            vuint32_t PDO:1;
            vuint32_t:2;
            vuint32_t MVRON:1;
            vuint32_t:2;
            vuint32_t FLAON:2;
            vuint32_t:9;
            vuint32_t PLL0ON:1;
            vuint32_t XOSCON:1;
            vuint32_t IRCON:1;
            vuint32_t SYSCLK:4;
        } B;
    } RUN_MC[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t PWRLVL:3;
            vuint32_t:4;
            vuint32_t PDO:1;
            vuint32_t:2;
            vuint32_t MVRON:1;
            vuint32_t:2;
            vuint32_t FLAON:2;
            vuint32_t:9;
            vuint32_t PLL0ON:1;
            vuint32_t XOSCON:1;
            vuint32_t IRCON:1;
            vuint32_t SYSCLK:4;
        } B;
    } HALT_MC;

    uint8_t MC_ME_reserved2[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t PWRLVL:3;
            vuint32_t:4;
            vuint32_t PDO:1;
            vuint32_t:2;
            vuint32_t MVRON:1;
            vuint32_t:2;
            vuint32_t FLAON:2;
            vuint32_t:9;
            vuint32_t PLL0ON:1;
            vuint32_t XOSCON:1;
            vuint32_t IRCON:1;
            vuint32_t SYSCLK:4;
        } B;
    } STOP_MC;

    uint8_t MC_ME_reserved3[20];

    union {
        vuint32_t R;
        struct {
            vuint32_t S_PIT_RTI_1:1;
            vuint32_t S_PIT_RTI_0:1;
            vuint32_t S_DECIFILTER:1;
            vuint32_t:17;
            vuint32_t S_SIPI_0:1;
            vuint32_t:1;
            vuint32_t S_LFAST_0:1;
              vuint32_t:9;
        } B;
    } PS0;

    union {
        vuint32_t R;
        struct {
            vuint32_t:3;
            vuint32_t S_ADCSD_A0:1;
            vuint32_t S_ADCSD_A1:1;
            vuint32_t:22;
            vuint32_t S_DMA_CH_MUX0:1;
            vuint32_t:4;
        } B;
    } PS1;

    union {
        vuint32_t R;
        struct {
            vuint32_t:3;
            vuint32_t S_LINFlexD_A0:1;
            vuint32_t S_LINFlexD_A1:1;
            vuint32_t:5;
	    vuint32_t S_LINFlexD_A2:1;
	    vuint32_t:10;
            vuint32_t S_CAN_RAM_CTRL0:1;
            vuint32_t S_CCCU:1;
            vuint32_t:2;
            vuint32_t S_MCAN_1:1;
            vuint32_t S_MCAN_2:1;
            vuint32_t:5;
        } B;
    } PS2;

    union {
        vuint32_t R;
        struct {
            vuint32_t S_ADCSAR_A0:1;
	    vuint32_t:3;
            vuint32_t S_ADCSAR_A1:1;
            vuint32_t:10;
            vuint32_t S_ADCSARB:1;
            vuint32_t:7;
            vuint32_t S_SENT_A0:1;
            vuint32_t:4;
            vuint32_t S_DSPI_A0:1;
            vuint32_t:1;
            vuint32_t S_DSPI_A1:1;
            vuint32_t:1;
        } B;
    } PS3;

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
	    vuint32_t S_GTMINT:1;
        } B;
    } PS4;

    vuint8_t MC_ME_reserved[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t RUN3:1;
            vuint32_t RUN2:1;
            vuint32_t RUN1:1;
            vuint32_t RUN0:1;
            vuint32_t DRUN:1;
            vuint32_t SAFE:1;
            vuint32_t TEST:1;
            vuint32_t RESET:1;
        } B;
    } RUN_PC[8];

    union {
        vuint32_t R;
        struct {
            vuint32_t:21;
            vuint32_t STOP0:1;
            vuint32_t:1;
            vuint32_t HALT0:1;
            vuint32_t:8;
        } B;
    } LP_PC[8];

    union {
        vuint8_t R;
        struct {
            vuint8_t:1;
            vuint8_t DBG_F:1;
            vuint8_t LP_CFG:3;
            vuint8_t RUN_CFG:3;
        } B;
    } PCTL[256];

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t S_CORE0:1;
        } B;
    } CS;

    union {
        vuint16_t R;
        struct {
            vuint16_t:5;
            vuint16_t STOP0:1;
            vuint16_t:1;
            vuint16_t HALT0:1;
            vuint16_t RUN3:1;
            vuint16_t RUN2:1;
            vuint16_t RUN1:1;
            vuint16_t RUN0:1;
            vuint16_t DRUN:1;
            vuint16_t SAFE:1;
            vuint16_t TEST:1;
            vuint16_t RESET:1;
        } B;
    } CCTL[1];

    uint8_t MC_ME_reserved28[26];

    union {
        vuint32_t R;
        struct {
            vuint32_t ADDR:30;
            vuint32_t:1;
	    vuint32_t RMC:1;
	    
        } B;
    } CADDR[1];
};
/**************************************************************************/
/*                   Module: MC_RGM                                        */
/**************************************************************************/
struct MC_RGM_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:7;
            vuint32_t F_VOR_DEST:1;
            vuint32_t F_TSR_DEST:1;
            vuint32_t:8;
	    vuint32_t F_SSCM_DEST:1;
	    vuint32_t:3;
            vuint32_t F_JTAG_DEST:1;
	    vuint32_t:1;
	    vuint32_t F_EDR:1;
            vuint32_t:4;
            vuint32_t F_SOFT_DEST:1;
            vuint32_t:1;
            vuint32_t F_PORST:1;
            vuint32_t F_POR:1;
        } B;
    } DES;

    uint8_t MC_RGM_reserved1[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t D_TSR_DEST:1;
            vuint32_t:21;
            vuint32_t D_PORST:1;
            vuint32_t :1;
        } B;
    } DERD;

    uint8_t MC_RGM_reserved2[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t AR_TSR_DEST:1;
              vuint32_t:21;
            vuint32_t AR_PORST:1;
              vuint32_t:1;
        } B;
    } DEAR;

    uint8_t MC_RGM_reserved3[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t:7;
            vuint32_t BE_VOR_DEST:1;
            vuint32_t BE_TSR_DEST:1;
            vuint32_t:8;
	    vuint32_t BE_SSCM_DEST:1;
            vuint32_t:3;
            vuint32_t BE_JTAG_DEST:1;
            vuint32_t:1;
            vuint32_t BE_EDR:1;
            vuint32_t:4;
            vuint32_t BE_SOF_DEST:1;
            vuint32_t:1;
            vuint32_t BE_PORST:1;
            vuint32_t BE_POR:1;
        } B;
    } DBRE;

    uint8_t MC_RGM_reserved4[716];

    union {
        vuint32_t R;
        struct {
            vuint32_t:6;
	    vuint32_t F_FLASH:1;
            vuint32_t F_VOR_FUNC:1;
            vuint32_t F_TSR_FUNC:1;
            vuint32_t:6;
            vuint32_t F_PLL0:1;
            vuint32_t:2;
	    vuint32_t F_CMU_FHL0:1;
	    vuint32_t F_CMU_OLR:1;
	    vuint32_t F_CORE:1;  
            vuint32_t F_JTAG_FUNC:1;
            vuint32_t F_CWD:1;
	    vuint32_t F_SWT:1;
            vuint32_t:4;
            vuint32_t F_SOFT_FUNC:1;
            vuint32_t :1;
            vuint32_t F_ESR1:1;
            vuint32_t F_ESR0:1;
        } B;
    } FES;

    uint8_t MC_RGM_reserved5[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t:6;
	    vuint32_t D_FLASH:1;
            vuint32_t D_VOR_FUNC:1;
            vuint32_t D_TSR_FUNC:1;
            vuint32_t:6;
            vuint32_t D_PLL0:1;
            vuint32_t:2;
            vuint32_t D_CMU_FHL0:1;
            vuint32_t D_CMU_OLR:1;
            vuint32_t D_CORE:1;
	    vuint32_t:1;
            vuint32_t D_CWD:1;
	    vuint32_t D_SWT:1;
            vuint32_t:6;
            vuint32_t D_ESR1:1;
            vuint32_t :1;
        } B;
    } FERD;

    uint8_t MC_RGM_reserved6[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t:6;
	    vuint32_t AR_FLASH:1;
            vuint32_t AR_VOR_FUNC:1;
            vuint32_t AR_TSR_FUNC:1;
            vuint32_t:6;
	    vuint32_t AR_PLL0:1;
            vuint32_t:2;
            vuint32_t AR_CMU_FHL0:1;
	    vuint32_t AR_CMU_OLR:1;
	    vuint32_t AR_CORE:1;
            vuint32_t:1;
	    vuint32_t AR_CWD:1;
	    vuint32_t AR_SWT:1;	    
            vuint32_t:6;
            vuint32_t AR_ESR1:1;
            vuint32_t :1;
        } B;
    } FEAR;

    uint8_t MC_RGM_reserved7[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t:6;
	    vuint32_t BE_FLASH:1;
            vuint32_t BE_VOR_FUNC:1;
            vuint32_t BE_TSR_FUNC:1;
            vuint32_t:6;
	    vuint32_t BE_PLL0:1;
            vuint32_t:2;
            vuint32_t BE_CMU_FHL0:1;
	    vuint32_t BE_CMU_OLR:1;
	    vuint32_t BE_CORE:1;
            vuint32_t BE_JTAG_FUNC:1;
	    vuint32_t BE_CWD:1;
	    vuint32_t BE_SWT:1;	    
            vuint32_t:4;
	    vuint32_t BE_SOFT_FUNC:1;
	    vuint32_t :1;
            vuint32_t BE_ESR1:1;
            vuint32_t BE_ESR0:1;
        } B;
    } FBRE;

    uint8_t MC_RGM_reserved8[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t:6;
	    vuint32_t SS_FLASH:1;
            vuint32_t SS_VOR_FUNC:1;
            vuint32_t SS_TSR_FUNC:1;
            vuint32_t:6;
	    vuint32_t SS_PLL0:1;
            vuint32_t:2;
            vuint32_t SS_CMU_FHL0:1;
	    vuint32_t SS_CMU_OLR:1;
	    vuint32_t SS_CORE:1;
            vuint32_t SS_JTAG_FUNC:1;
	    vuint32_t SS_CWD:1;
	    vuint32_t SS_SWT:1;	    
            vuint32_t:4;
	    vuint32_t SS_SOFT_FUNC:1;
	    vuint32_t :1;
            vuint32_t SS_ESR1:1;
            vuint32_t SS_ESR0:1;
        } B;
    } FESS;

    uint8_t MC_RGM_reserved9[704];

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t FRET:4;
	    vuint32_t:24;
        } B;
    } FRET;

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t DRET:4;
	    vuint32_t:24;
        } B;
    } DRET;

    union {
        vuint32_t R;
        struct {
	    vuint32_t :6;
            vuint32_t ERIS:1;
            vuint32_t EROEC:1;
	    vuint32_t:24;
        } B;
    } EROEC;

    union {
        vuint32_t R;
        struct {
            vuint32_t PIT_RTC_1_RST:1;
            vuint32_t PIT_RTC_0_RST:1;
	    vuint32_t DECIFILTER_RST:1;
            vuint32_t:13;
	    vuint32_t SIUL_RST:1;
	    vuint32_t:3;
	    vuint32_t SIPI_0_RST:1;
	    vuint32_t:1;
            vuint32_t LFAST_0_RST:1;
            vuint32_t:9;
        } B;
    } PRST0;

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t ADCSD_2_RST:1;
            vuint32_t:22;
            vuint32_t DMAMUX_0_RST:1;
              vuint32_t:4;
        } B;
    } PRST1;

    union {
        vuint32_t R;
        struct {
            vuint32_t:3;
            vuint32_t LINFLEXD_0_RST:1;
            vuint32_t LINFLEXD_1_RST:1;
	    vuint32_t:5;
            vuint32_t LINFLEX_14_RST:1;
            vuint32_t:10;
            vuint32_t CAN_RAM_CTRL_RST:1;
            vuint32_t CCCU_RST:1;
            vuint32_t:2;
            vuint32_t MCAN_1_RST:1;
            vuint32_t MCAN_2_RST:1;
            vuint32_t:5;
        } B;
    } PRST2;

    union {
        vuint32_t R;
        struct {
            vuint32_t ADCSAR_0_RST:1;
	    vuint32_t:3;
            vuint32_t ADCSAR_4_RST:1;
            vuint32_t:10;
            vuint32_t ADCSAR_b_RST:1;
            vuint32_t:7;
            vuint32_t SENT_0_RST:1;
            vuint32_t:4;
            vuint32_t DSPI_0_RST:1;
            vuint32_t :1;
            vuint32_t DSPI_4_RST:1;
            vuint32_t:1;
        } B;
    } PRST3;

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
	    vuint32_t GTMINT_RST:1;
        } B;
    } PRST4;    
};

/**************************************************************************/
/*                   Module: MC_PCU                                       */
/**************************************************************************/
struct MC_PCU_tag {

    uint8_t MC_PCU_reserved[64];

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t PD0:1;
        } B;
    } PSTAT;
};
/**************************************************************************/
/*                              Module: PASS                              */
/**************************************************************************/
struct PASS_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t CNS:1;
            vuint32_t JUN:1;
              vuint32_t:27;
            vuint32_t LIFE:3;
        } B;
    } LCSTAT;

    uint8_t PASS_reserved1[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:30;
            vuint32_t GRP:2;
        } B;
    } CHSEL;

    uint8_t PASS_reserved2[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:28;
            vuint32_t CMST:4;
        } B;
    } CSTAT;

    uint8_t PASS_reserved3[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t PW32:32;
        } B;
    } CIN[8];

    uint8_t PASS_reserved4[192];

    struct {
        union {
            vuint32_t R;
            struct {
                vuint32_t TSLOCK:1;
                vuint32_t:1;
                vuint32_t LOWLOCK:14;
                vuint32_t MIDLOCK:16;
            } B;
        } LOCK0_PG;

        union {
            vuint32_t R;
            struct {
                vuint32_t:16;
                vuint32_t HIGHLOCK:16;
            } B;
        } LOCK1_PG;

        union {
            vuint32_t R;
            struct {
                vuint32_t L256LCK_L:32;
            } B;
        } LOCK2_PG;

        union {
            vuint32_t R;
            struct {
                vuint32_t PGL:1;
                vuint32_t DBL:1;
	        vuint32_t MO:1;
                vuint32_t:1;
                vuint32_t MSTR:4;
		vuint32_t:3;
                vuint32_t RP4:1;
                vuint32_t RP3:1;
                vuint32_t RP2:1;
                vuint32_t RP1:1;
                vuint32_t RP0:1;
                vuint32_t L256LCK_U:16;
            } B;
        } LOCK3_PG;
    } TIMER[4];
};
/**************************************************************************/
/*                   Module: PBRIDGE                                      */
/**************************************************************************/
struct PBRIDGE_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t MPROTa:4;
            vuint32_t MPROTb:4;
            vuint32_t MPROTc:4;
            vuint32_t MPROTd:4;
            vuint32_t MPROTe:4;
            vuint32_t MPROTf:4;
            vuint32_t MPROTg:4;
            vuint32_t MPROTh:4;
        } B;
    } MPRA;

    uint8_t PBRIDGE_reserved1[252];

    union {
        vuint32_t R;
        struct {
            vuint32_t PACRa:4;
            vuint32_t PACRb:4;
            vuint32_t PACRc:4;
            vuint32_t PACRd:4;
            vuint32_t PACRe:4;
            vuint32_t PACRf:4;
            vuint32_t PACRg:4;
            vuint32_t PACRh:4;
        } B;
    } PACRA;

    union {
        vuint32_t R;
        struct {
            vuint32_t PACRa:4;
            vuint32_t PACRb:4;
            vuint32_t PACRc:4;
            vuint32_t PACRd:4;
            vuint32_t PACRe:4;
            vuint32_t PACRf:4;
            vuint32_t PACRg:4;
            vuint32_t PACRh:4;
        } B;
    } PACRB;

    union {
        vuint32_t R;
        struct {
            vuint32_t PACRa:4;
            vuint32_t PACRb:4;
            vuint32_t PACRc:4;
            vuint32_t PACRd:4;
            vuint32_t PACRe:4;
            vuint32_t PACRf:4;
            vuint32_t PACRg:4;
            vuint32_t PACRh:4;
        } B;
    } PACRC;

    union {
        vuint32_t R;
        struct {
            vuint32_t PACRa:4;
            vuint32_t PACRb:4;
            vuint32_t PACRc:4;
            vuint32_t PACRd:4;
            vuint32_t PACRe:4;
            vuint32_t PACRf:4;
            vuint32_t PACRg:4;
            vuint32_t PACRh:4;
        } B;
    } PACRD;

    uint8_t PBRIDGE_reserved10[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t PACRa:4;
            vuint32_t PACRb:4;
            vuint32_t PACRc:4;
            vuint32_t PACRd:4;
            vuint32_t PACRe:4;
            vuint32_t PACRf:4;
            vuint32_t PACRg:4;
            vuint32_t PACRh:4;
        } B;
    } PACRF;

    union {
        vuint32_t R;
        struct {
            vuint32_t PACRa:4;
            vuint32_t PACRb:4;
            vuint32_t PACRc:4;
            vuint32_t PACRd:4;
            vuint32_t PACRe:4;
            vuint32_t PACRf:4;
            vuint32_t PACRg:4;
            vuint32_t PACRh:4;
        } B;
    } PACRG;

    union {
        vuint32_t R;
        struct {
            vuint32_t PACRa:4;
            vuint32_t PACRb:4;
            vuint32_t PACRc:4;
            vuint32_t PACRd:4;
            vuint32_t PACRe:4;
            vuint32_t PACRf:4;
            vuint32_t PACRg:4;
            vuint32_t PACRh:4;
        } B;
    } PACRH;
};
/**************************************************************************/
/*                   Module: PFLASH                                       */
/**************************************************************************/
struct PFLASH_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t P0_M15PFE:1;
            vuint32_t P0_M14PFE:1;
            vuint32_t P0_M13PFE:1;
            vuint32_t P0_M12PFE:1;
            vuint32_t P0_M11PFE:1;
            vuint32_t P0_M10PFE:1;
            vuint32_t P0_M9PFE:1;
            vuint32_t P0_M8PFE:1;
            vuint32_t P0_M7PFE:1;
            vuint32_t P0_M6PFE:1;
            vuint32_t P0_M5PFE:1;
            vuint32_t P0_M4PFE:1;
            vuint32_t P0_M3PFE:1;
            vuint32_t P0_M2PFE:1;
            vuint32_t P0_M1PFE:1;
            vuint32_t P0_M0PFE:1;
            vuint32_t:3;
            vuint32_t RWSC:5;
            vuint32_t:1;
            vuint32_t P0_DPFEN:1;
            vuint32_t:1;
            vuint32_t P0_IPFEN:1;
            vuint32_t:1;
            vuint32_t P0_PFLIM:2;
            vuint32_t P0_BFEN:1;
        } B;
    } PFCR1;

    uint8_t PFLASH_reserved10[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t P0_WCFG:2;
            vuint32_t:12;
            vuint32_t BAF_DIS:1;
            vuint32_t:16;
        } B;
    } PFCR3;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0AP:2;
            vuint32_t M1AP:2;
            vuint32_t M2AP:2;
            vuint32_t M3AP:2;
            vuint32_t M4AP:2;
            vuint32_t M5AP:2;
            vuint32_t M6AP:2;
            vuint32_t M7AP:2;
            vuint32_t M8AP:2;
            vuint32_t M9AP:2;
            vuint32_t M10AP:2;
            vuint32_t M11AP:2;
            vuint32_t M12AP:2;
            vuint32_t M13AP:2;
            vuint32_t M14AP:2;
            vuint32_t M15AP:2;
        } B;
    } PFAPR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:23;
            vuint32_t SAFE_CAL:1;
              vuint32_t:3;
            vuint32_t IRMEN:1;
              vuint32_t:3;
            vuint32_t GRMEN:1;
        } B;
    } PFCRCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t CRD0EN:1;
            vuint32_t CRD1EN:1;
            vuint32_t CRD2EN:1;
            vuint32_t CRD3EN:1;
            vuint32_t CRD4EN:1;
            vuint32_t CRD5EN:1;
            vuint32_t CRD6EN:1;
            vuint32_t CRD7EN:1;
            vuint32_t CRD8EN:1;
            vuint32_t CRD9EN:1;
            vuint32_t CRD10EN:1;
            vuint32_t CRD11EN:1;
            vuint32_t CRD12EN:1;
            vuint32_t CRD13EN:1;
            vuint32_t CRD14EN:1;
            vuint32_t CRD15EN:1;
            vuint32_t CRD16EN:1;
            vuint32_t CRD17EN:1;
            vuint32_t CRD18EN:1;
            vuint32_t CRD19EN:1;
            vuint32_t CRD20EN:1;
            vuint32_t CRD21EN:1;
            vuint32_t CRD22EN:1;
            vuint32_t CRD23EN:1;
            vuint32_t CRD24EN:1;
            vuint32_t CRD25EN:1;
            vuint32_t CRD26EN:1;
            vuint32_t CRD27EN:1;
            vuint32_t CRD28EN:1;
            vuint32_t CRD29EN:1;
            vuint32_t CRD30EN:1;
            vuint32_t CRD31EN:1;
        } B;
    } PFCRDE;

    uint8_t PFLASH_reserved1[232];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD0_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD0_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD0_Word2;

    uint8_t PFLASH_reserved2[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD1_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD1_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD1_Word2;

    uint8_t PFLASH_reserved3[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD2_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD2_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD2_Word2;

    uint8_t PFLASH_reserved4[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD3_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD3_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD3_Word2;

    uint8_t PFLASH_reserved5[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD4_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD4_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD4_Word2;

    uint8_t PFLASH_reserved6[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD5_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD5_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD5_Word2;

    uint8_t PFLASH_reserved7[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD6_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD6_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD6_Word2;

    uint8_t PFLASH_reserved8[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD7_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD7_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD7_Word2;

    uint8_t PFLASH_reserved9[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD8_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD8_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD8_Word2;

    uint8_t PFLASH_reserved20[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD9_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD9_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD9_Word2;

    uint8_t PFLASH_reserved11[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD10_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD10_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD10_Word2;

    uint8_t PFLASH_reserved12[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD11_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD11_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD11_Word2;

    uint8_t PFLASH_reserved13[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD12_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD12_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD12_Word2;

    uint8_t PFLASH_reserved14[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD13_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD13_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD13_Word2;

    uint8_t PFLASH_reserved15[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD14_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD14_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD14_Word2;

    uint8_t PFLASH_reserved16[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD15_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD15_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD15_Word2;

    uint8_t PFLASH_reserved17[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD16_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD16_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD16_Word2;

    uint8_t PFLASH_reserved18[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD17_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD17_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD17_Word2;

    uint8_t PFLASH_reserved19[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD18_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD18_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD18_Word2;

    uint8_t PFLASH_reserved30[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD19_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD19_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD19_Word2;

    uint8_t PFLASH_reserved21[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD20_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD20_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD20_Word2;

    uint8_t PFLASH_reserved22[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD21_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD21_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD21_Word2;

    uint8_t PFLASH_reserved23[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD22_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD22_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD22_Word2;

    uint8_t PFLASH_reserved24[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD23_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD23_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD23_Word2;

    uint8_t PFLASH_reserved25[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD24_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD24_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD24_Word2;

    uint8_t PFLASH_reserved26[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD25_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD25_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD25_Word2;

    uint8_t PFLASH_reserved27[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD26_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD26_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD26_Word2;

    uint8_t PFLASH_reserved28[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD27_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD27_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD27_Word2;

    uint8_t PFLASH_reserved29[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD28_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD28_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD28_Word2;

    uint8_t PFLASH_reserved40[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD29_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD29_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD29_Word2;

    uint8_t PFLASH_reserved31[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD30_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD30_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD30_Word2;

    uint8_t PFLASH_reserved32[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t LSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD31_Word0;

    union {
        vuint32_t R;
        struct {
            vuint32_t PSTARTADDR:28;
              vuint32_t:4;
        } B;
    } PFCRD31_Word1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0EN:1;
	    vuint32_t M1EN:1;
	    vuint32_t M2EN:1;
	    vuint32_t M3EN:1;
            vuint32_t M4EN:1;
	    vuint32_t M5EN:1;
	    vuint32_t M6EN:1;
	    vuint32_t M7EN:1;
	    vuint32_t M8EN:1;
	    vuint32_t M9EN:1;
	    vuint32_t M10EN:1;
	    vuint32_t M11EN:1;
            vuint32_t M12EN:1;
	    vuint32_t M13EN:1;
	    vuint32_t M14EN:1;
	    vuint32_t M15EN:1;	
	    vuint32_t:11;
            vuint32_t CRDSize:5;
        } B;
    } PFCRD31_Word2;
};
/**************************************************************************/
/*                   Module: PIT                                          */
/**************************************************************************/
struct PIT_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:30;
            vuint32_t MDIS:1;
            vuint32_t FRZ:1;
        } B;
    } MCR;

    uint8_t PIT_reserved1[220];

    union {
        vuint32_t R;
        struct {
            vuint32_t LTH:32;
        } B;
    } LTMR64H;

    union {
        vuint32_t R;
        struct {
            vuint32_t LTL:32;
        } B;
    } LTMR64L;

    uint8_t PIT_reserved2[24];

    struct {
        union {
            vuint32_t R;
            struct {
                vuint32_t TSV:32;
            } B;
        } LDVAL;

        union {
            vuint32_t R;
            struct {
                vuint32_t TVL:32;
            } B;
        } CVAL;

        union {
            vuint32_t R;
            struct {
                vuint32_t:29;
                vuint32_t CHN:1;
                vuint32_t TIE:1;
                vuint32_t TEN:1;
            } B;
        } TCTRL;

        union {
            vuint32_t R;
            struct {
                vuint32_t:31;
                vuint32_t TIF:1;
            } B;
        } TFLG;
    } TIMER[8];
};
/**************************************************************************/
/*                   Module: PLLDIG                                       */
/**************************************************************************/
struct PLLDIG_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:22;
            vuint32_t CLKCFG:2;
            vuint32_t EXPDIE:1;
              vuint32_t:3;
            vuint32_t LOLIE:1;
            vuint32_t LOLRE:1;
              vuint32_t:2;
        } B;
    } PLL0CR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t EXTPDF:1;
              vuint32_t:3;
            vuint32_t LOLF:1;
            vuint32_t LOCK:1;
              vuint32_t:2;
        } B;
    } PLL0SR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t RFDPHI1:4;
              vuint32_t:5;
            vuint32_t RFDPHI:6;
              vuint32_t:1;
            vuint32_t PREDIV:3;
              vuint32_t:5;
            vuint32_t MFD:7;
        } B;
    } PLL0DV;
   
};
/**************************************************************************/
/*                             Module: PMCDIG                             */
/**************************************************************************/
struct PMCDIG_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:17;
            vuint32_t VD14:1;
	    vuint32_t:3;
            vuint32_t VD10:1;
            vuint32_t VD9:1;
            vuint32_t:5;
            vuint32_t VD3:1;
            vuint32_t:2;
	    vuint32_t VD2:1;
        } B;
    } GR_S;

    union {
        vuint32_t R;
        struct {
            vuint32_t:9;
	    vuint32_t VD14_A:1;
            vuint32_t VD14_IM:1;
	    vuint32_t:5;
            vuint32_t VD10_F:1;
	    vuint32_t VD10_C:1;
	    vuint32_t:1;
            vuint32_t VD10_IF:1;
            vuint32_t VD10_IJ:1;
	    vuint32_t:3;
            vuint32_t VD9_C:1;
	    vuint32_t:3;
            vuint32_t VD3_C:1;
	    vuint32_t:2;
            vuint32_t VD2_C:1;
	    
        } B;
    } GR_P;

    union {
        vuint32_t R;
        struct {
            vuint32_t IE_EN:1;
            vuint32_t:8;
	    vuint32_t VD14IE_A:1;
	    vuint32_t VD14IE_IM:1;
	    vuint32_t:5;
            vuint32_t VD10IE_F:1;
	    vuint32_t VD10IE_C:1;
	    vuint32_t:1;
	    vuint32_t VD10IE_IF:1;
	    vuint32_t VD10IE_IJ:1;
	    vuint32_t:3;
            vuint32_t VD9IE_C:1;
 	    vuint32_t:3;
            vuint32_t VD3IE_C:1;
	    vuint32_t:2;
            vuint32_t VD2IE_C:1;
        } B;
    } IE_P;

    uint8_t PMCDIG_reserved1[36];

    union {
        vuint32_t R;
        struct {
            vuint32_t:28;
            vuint32_t LVD3_C:1;
            vuint32_t:3;
        } B;
    } EPR_VD3;

    union {
        vuint32_t R;
        struct {
           vuint32_t:28;
           vuint32_t LVD3_C:1;
           vuint32_t:3;
        } B;
    } REE_VD3;

    union {
        vuint32_t R;
        struct {
           vuint32_t:28;
           vuint32_t LVD3_C:1;
           vuint32_t:3;
        } B;
    } RES_VD3;

    uint8_t PMCDIG_reserved3[84];

    union {
        vuint32_t R;
        struct {
           vuint32_t:28;
           vuint32_t LVD9_C:1;
           vuint32_t:3;
        } B;
    } EPR_VD9;

    uint8_t PMCDIG_reserved10[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t LVD10_A:1;
              vuint32_t:15;
        } B;
    } EPR_VD10;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t LVD10_A:1;
              vuint32_t:15;
        } B;
    } REE_VD10;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t LVD10_A:1;
              vuint32_t:15;
        } B;
    } RES_VD10;


    uint8_t PMCDIG_reserved5[52];

    union {
        vuint32_t R;
        struct {
            vuint32_t:9;
            vuint32_t LVD14_A:1;
            vuint32_t LVD14_IM:1;
            vuint32_t:21;
        } B;
    } EPR_VD14;

    union {
        vuint32_t R;
        struct {
            vuint32_t:9;
            vuint32_t LVD14_A:1;
            vuint32_t LVD14_IM:1;
            vuint32_t:21;
        } B;
    } REE_VD14;

    union {
        vuint32_t R;
        struct {
            vuint32_t:9;
            vuint32_t LVD14_A:1;
            vuint32_t LVD14_IM:1;
            vuint32_t:21;
        } B;
    } RES_VD14;

    uint8_t PMCDIG_reserved6[24];

    union {
        vuint32_t R;
        struct {
            vuint32_t:21;
            vuint32_t VSIO_IF:1;
            vuint32_t VSIO_IJ:1;
	    vuint32_t VSIO_IM:1;
            vuint32_t:8;
        } B;
    } VSIO;
	
    uint8_t PMCDIG_reserved20[312];

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t MREG_ENB:1;
        } B;
    } MREG_CTRL;
	
    uint8_t PMCDIG_reserved21[188];
    
    union {
        vuint32_t R;
        struct {
            vuint32_t:29;
            vuint32_t TEMP_2:1;
            vuint32_t TEMP_1:1;
            vuint32_t TEMP_0:1;
        } B;
    } EPR_TD;

    union {
        vuint32_t R;
        struct {
            vuint32_t:29;
            vuint32_t TEMP_2:1;
            vuint32_t TEMP_1:1;
            vuint32_t TEMP_0:1;
        } B;
    } REE_TD;

    union {
        vuint32_t R;
        struct {
            vuint32_t:29;
            vuint32_t TEMP_2:1;
            vuint32_t TEMP_1:1;
            vuint32_t TEMP_0:1;
        } B;
    } RES_TD;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
	    vuint32_t TS3IE:1;
            vuint32_t TS2IE:1;
            vuint32_t TS0IE:1;
	    vuint32_t:1;
            vuint32_t TRIM_ADJ_OVER:4;
	    vuint32_t:2;
            vuint32_t TRIM_ADJ_UNDER:4;
            vuint32_t DOUT_EN:1;
            vuint32_t AOUT_EN:1;
        } B;
    } CTL_TD;

};
/**************************************************************************/
/*                    Module: RCOSC Digital Interface                     */
/**************************************************************************/
struct RCOSC_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:11;
            vuint32_t USER_TRIM:5;
            vuint32_t:16;
        } B;
    } CTL;

    union {
        vuint32_t R;
        struct {
            vuint32_t:2;
	    vuint32_t FT_CODE:6;
            vuint32_t:2;
	    vuint32_t TX_CODE:6;
            vuint32_t:4;
            vuint32_t REG_EN:1;
            vuint32_t TSENS_EN:1;
              vuint32_t:2;
            vuint32_t RCTRIM:8;
        } B;
    } NT;

    union {
        vuint32_t R;
        struct {
            vuint32_t:2;
            vuint32_t COLD_TRIM:10;
              vuint32_t:2;
            vuint32_t HOT_TRIM:10;
              vuint32_t:2;
            vuint32_t TSENS_TRIM:6;
        } B;
    } TT;
};
/**************************************************************************/
/*                   Module: SARADC                                       */
/**************************************************************************/
struct SARADC_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t OWREN:1;
            vuint32_t WLSIDE:1;
            vuint32_t MODE:1;
            vuint32_t :1;
            vuint32_t NSTART:1;
            vuint32_t NTRGEN:1;
            vuint32_t NEDGESEL:2;
            vuint32_t JSTART:1;
            vuint32_t JTRGEN:1;
            vuint32_t JEDGESEL:2;
            vuint32_t JTRGSEQ:1;
            vuint32_t:1;
            vuint32_t:1;
            vuint32_t:1;
            vuint32_t:4;
            vuint32_t JTRGSEL:4;
            vuint32_t ABORTCHAIN:1;
            vuint32_t ABORT:1;
            vuint32_t:1;
            vuint32_t FRZ:1;
            vuint32_t:3;
            vuint32_t PWDN:1;
        } B;
    } MCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t NSTART:1;
              vuint32_t:3;
            vuint32_t JSTART:1;
              vuint32_t:4;
            vuint32_t JABORT:1;
              vuint32_t:1;
              vuint32_t:1;
            vuint32_t CHADDR:8;
              vuint32_t:5;
            vuint32_t ADCSTATUS:3;
        } B;
    } MSR;

    uint8_t SARADC_reserved1[8];

    union {
        vuint32_t R;
        struct {
            vuint32_t:27;
            vuint32_t:1;
            vuint32_t JEOC:1;
            vuint32_t JECH:1;
            vuint32_t NEOC:1;
            vuint32_t NECH:1;
        } B;
    } ISR;

    union {
        vuint32_t R;
        struct {
            vuint32_t EOC_CH:32;
        } B;
    } ICIPR[3];

    union {
        vuint32_t R;
        struct {
            vuint32_t:27;
            vuint32_t:1;
            vuint32_t MSKJEOC:1;
            vuint32_t MSKJECH:1;
            vuint32_t MSKNEOC:1;
            vuint32_t MSKNECH:1;
        } B;
    } IMR;

    union {
        vuint32_t R;
        struct {
            vuint32_t IM_CH:32;
        } B;
    } ICIMR[3];

    union {
        vuint32_t R;
        struct {
            vuint32_t WDG15H:1;
            vuint32_t WDG15L:1;
            vuint32_t WDG14H:1;
            vuint32_t WDG14L:1;
            vuint32_t WDG13H:1;
            vuint32_t WDG13L:1;
            vuint32_t WDG12H:1;
            vuint32_t WDG12L:1;
            vuint32_t WDG11H:1;
            vuint32_t WDG11L:1;
            vuint32_t WDG10H:1;
            vuint32_t WDG10L:1;
            vuint32_t WDG9H:1;
            vuint32_t WDG9L:1;
            vuint32_t WDG8H:1;
            vuint32_t WDG8L:1;
            vuint32_t WDG7H:1;
            vuint32_t WDG7L:1;
            vuint32_t WDG6H:1;
            vuint32_t WDG6L:1;
            vuint32_t WDG5H:1;
            vuint32_t WDG5L:1;
            vuint32_t WDG4H:1;
            vuint32_t WDG4L:1;
            vuint32_t WDG3H:1;
            vuint32_t WDG3L:1;
            vuint32_t WDG2H:1;
            vuint32_t WDG2L:1;
            vuint32_t WDG1H:1;
            vuint32_t WDG1L:1;
            vuint32_t WDG0H:1;
            vuint32_t WDG0L:1;
        } B;
    } WTISR;

    union {
        vuint32_t R;
        struct {
            vuint32_t MSKWDG15H:1;
            vuint32_t MSKWDG15L:1;
            vuint32_t MSKWDG14H:1;
            vuint32_t MSKWDG14L:1;
            vuint32_t MSKWDG13H:1;
            vuint32_t MSKWDG13L:1;
            vuint32_t MSKWDG12H:1;
            vuint32_t MSKWDG12L:1;
            vuint32_t MSKWDG11H:1;
            vuint32_t MSKWDG11L:1;
            vuint32_t MSKWDG10H:1;
            vuint32_t MSKWDG10L:1;
            vuint32_t MSKWDG9H:1;
            vuint32_t MSKWDG9L:1;
            vuint32_t MSKWDG8H:1;
            vuint32_t MSKWDG8L:1;
            vuint32_t MSKWDG7H:1;
            vuint32_t MSKWDG7L:1;
            vuint32_t MSKWDG6H:1;
            vuint32_t MSKWDG6L:1;
            vuint32_t MSKWDG5H:1;
            vuint32_t MSKWDG5L:1;
            vuint32_t MSKWDG4H:1;
            vuint32_t MSKWDG4L:1;
            vuint32_t MSKWDG3H:1;
            vuint32_t MSKWDG3L:1;
            vuint32_t MSKWDG2H:1;
            vuint32_t MSKWDG2L:1;
            vuint32_t MSKWDG1H:1;
            vuint32_t MSKWDG1L:1;
            vuint32_t MSKWDG0H:1;
            vuint32_t MSKWDG0L:1;
        } B;
    } WTIMR;

    uint8_t SARADC_reserved2[8];

    union {
        vuint32_t R;
        struct {
            vuint32_t:30;
            vuint32_t DCLR:1;
            vuint32_t DMAEN:1;
        } B;
    } DMAE;

    union {
        vuint32_t R;
        struct {
            vuint32_t DS_CH:32;
        } B;
    } ICDSR[3];

    uint8_t SARADC_reserved3[16];

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t THRH:12;
              vuint32_t:4;
            vuint32_t THRL:12;
        } B;
    } WTHRHLR[4];

    uint8_t SARADC_reserved4[36];

    union {
        vuint32_t R;
        struct {
            vuint32_t CRES:1; 
            vuint32_t:19;
            vuint32_t PRECHG:4;
            vuint32_t INPSAMP:8;
        } B;
    } CTR[4];
    union {
        vuint32_t R;
        struct {
            vuint32_t NCE_CH:32;
        } B;
    } ICNCMR[3];

    uint8_t SARADC_reserved5[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t JCE_CH:32;
        } B;
    } ICJCMR[3];

    uint8_t SARADC_reserved6[8];

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t PDED:8;
        } B;
    } PDEDR;

    uint8_t SARADC_reserved7[52];

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ICDR[96];

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t THRH:12;
              vuint32_t:4;
            vuint32_t THRL:12;
        } B;
    } WTHRHLR4;

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t THRH:12;
              vuint32_t:4;
            vuint32_t THRL:12;
        } B;
    } WTHRHLR5;

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t THRH:12;
              vuint32_t:4;
            vuint32_t THRL:12;
        } B;
    } WTHRHLR6;

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t THRH:12;
              vuint32_t:4;
            vuint32_t THRL:12;
        } B;
    } WTHRHLR7;

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t THRH:12;
              vuint32_t:4;
            vuint32_t THRL:12;
        } B;
    } WTHRHLR8;

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t THRH:12;
              vuint32_t:4;
            vuint32_t THRL:12;
        } B;
    } WTHRHLR9;

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t THRH:12;
              vuint32_t:4;
            vuint32_t THRL:12;
        } B;
    } WTHRHLR10;

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t THRH:12;
              vuint32_t:4;
            vuint32_t THRL:12;
        } B;
    } WTHRHLR11;

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t THRH:12;
              vuint32_t:4;
            vuint32_t THRL:12;
        } B;
    } WTHRHLR12;

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t THRH:12;
              vuint32_t:4;
            vuint32_t THRL:12;
        } B;
    } WTHRHLR13;

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t THRH:12;
              vuint32_t:4;
            vuint32_t THRL:12;
        } B;
    } WTHRHLR14;

    union {
        vuint32_t R;
        struct {
            vuint32_t:4;
            vuint32_t THRH:12;
              vuint32_t:4;
            vuint32_t THRL:12;
        } B;
    } WTHRHLR15;

    union {
        vuint32_t R;
        struct {
            vuint32_t WSEL_CH7:4;
            vuint32_t WSEL_CH6:4;
            vuint32_t WSEL_CH5:4;
            vuint32_t WSEL_CH4:4;
            vuint32_t WSEL_CH3:4;
            vuint32_t WSEL_CH2:4;
            vuint32_t WSEL_CH1:4;
            vuint32_t WSEL_CH0:4;
        } B;
    } ICWSELR[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t WEN_CH:32;
        } B;
    } ICWENR[3];

    uint8_t SARADC_reserved8[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t AWOR_CH:32;
        } B;
    } ICAWORR[3];

    uint8_t SARADC_reserved9[260];

    union {
        vuint32_t R;
        struct {
            vuint32_t EOC_CH:32;
        } B;
    } TCIPR;

    union {
        vuint32_t R;
        struct {
            vuint32_t IM_CH:32;
        } B;
    } TCIMR;

    union {
        vuint32_t R;
        struct {
            vuint32_t DS_CH:32;
        } B;
    } TCDSR;

    union {
        vuint32_t R;
        struct {
            vuint32_t NCE_CH:32;
        } B;
    } TCNCMR;

    union {
        vuint32_t R;
        struct {
            vuint32_t JCE_CH:32;
        } B;
    } TCJCMR;

    union {
        vuint32_t R;
        struct {
            vuint32_t WSEL_CH7:4;
            vuint32_t WSEL_CH6:4;
            vuint32_t WSEL_CH5:4;
            vuint32_t WSEL_CH4:4;
            vuint32_t WSEL_CH3:4;
            vuint32_t WSEL_CH2:4;
            vuint32_t WSEL_CH1:4;
            vuint32_t WSEL_CH0:4;
        } B;
    } TCWSELR[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t WEN_CH:32;
        } B;
    } TCWENR;

    union {
        vuint32_t R;
        struct {
            vuint32_t AWOR_CH:32;
        } B;
    } TCAWORR;

    uint8_t SARADC_reserved10[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t ESIC_TCH3:1;
            vuint32_t ICSEL_TCH3:7;
            vuint32_t ESIC_TCH2:1;
            vuint32_t ICSEL_TCH2:7;
            vuint32_t ESIC_TCH1:1;
            vuint32_t ICSEL_TCH1:7;
            vuint32_t ESIC_TCH0:1;
            vuint32_t ICSEL_TCH0:7;
        } B;
    } TCCAPR[8];

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } TCDR[32];

    uint8_t SARADC_0_reserved11[48];

    union {
        vuint32_t R;
        struct {
            vuint32_t:20;
            vuint32_t DSD:12;
        } B;
    } ECDSD;

    uint8_t SARADC_reserved12[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t EOC_CH:32;
        } B;
    } ECIPR[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t IM_CH:32;
        } B;
    } ECIMR[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t DS_CH:32;
        } B;
    } ECDSR[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t NCE_CH:32;
        } B;
    } ECNCMR[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t JCE_CH:32;
        } B;
    } ECJCMR[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t WSEL_CH7:4;
            vuint32_t WSEL_CH6:4;
            vuint32_t WSEL_CH5:4;
            vuint32_t WSEL_CH4:4;
            vuint32_t WSEL_CH3:4;
            vuint32_t WSEL_CH2:4;
            vuint32_t WSEL_CH1:4;
            vuint32_t WSEL_CH0:4;
        } B;
    } ECWSELR[16];

    union {
        vuint32_t R;
        struct {
            vuint32_t WEN_CH:32;
        } B;
    } ECWENR[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t AWOR_CH:32;
        } B;
    } ECAWORR[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t ICSEL_ECH152_159:7;
              vuint32_t:1;
            vuint32_t ICSEL_ECH144_151:7;
              vuint32_t:1;
            vuint32_t ICSEL_ECH136_143:7;
              vuint32_t:1;
            vuint32_t ICSEL_ECH128_135:7;
        } B;
    } ECMICR[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR128;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR129;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR130;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR131;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR132;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR133;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR134;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR135;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR136;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR137;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR138;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR139;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR140;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR141;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR142;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR143;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR144;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR145;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR146;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR147;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR148;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR149;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR150;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR151;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR152;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR153;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR154;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR155;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR156;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR157;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR158;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR159;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR160;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR161;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR162;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR163;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR164;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR165;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR166;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR167;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR168;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR169;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR170;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR171;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR172;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR173;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR174;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR175;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR176;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR177;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR178;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR179;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR180;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR181;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR182;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR183;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR184;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR185;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR186;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR187;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR188;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR189;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR190;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR191;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR192;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR193;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR194;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR195;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR196;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR197;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR198;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR199;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR200;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR201;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR202;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR203;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR204;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR205;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR206;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR207;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR208;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR209;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR210;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR211;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR212;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR213;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR214;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR215;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR216;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR217;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR218;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR219;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR220;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR221;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR222;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR223;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR224;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR225;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR226;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR227;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR228;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR229;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR230;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR231;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR232;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR233;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR234;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR235;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR236;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR237;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR238;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR239;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR240;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR241;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR242;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR243;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR244;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR245;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR246;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR247;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR248;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR249;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR250;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR251;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR252;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR253;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR254;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t REFSEL:1;
              vuint32_t:2;
            vuint32_t PCE:1;
              vuint32_t:1;
            vuint32_t CTSEL:2;
              vuint32_t:4;
            vuint32_t VALID:1;
            vuint32_t OVERW:1;
            vuint32_t RESULT:2;
              vuint32_t:4;
            vuint32_t CDATA:12;
        } B;
    } ECDR255;
};

/**************************************************************************/
/*                   Module: SDADC                                        */
/**************************************************************************/
struct SDADC_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:3;
            vuint32_t PDR:5;
            vuint32_t:1;
            vuint32_t PGAN:3;
            vuint32_t ODF:1;
            vuint32_t ODA:1;
            vuint32_t EMSEL:1;
            vuint32_t HPFEN:1;
            vuint32_t WDGEN:1; 
            vuint32_t TRIGEDSEL:2;
            vuint32_t TRIGEN:1;
            vuint32_t TRIGSEL:4; // Added for K2 cut2
            vuint32_t FRZ:1;
            vuint32_t:2;
            vuint32_t VCOMSEL:1;
            vuint32_t WRMODE:1; // Added on K2 cut2
            vuint32_t GECEN:1;
            vuint32_t MODE:1;
            vuint32_t EN:1;
        } B;
    } MCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:8;
            vuint32_t BIASEN:8;
	    vuint32_t:5;
	    vuint32_t ANCHSEL_WRAP:3;
            vuint32_t:5;
            vuint32_t ANCHSEL:3;
        } B;
    } CSR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t RESET_KEY:16;
        } B;
    } RKR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:13;
	    vuint32_t ANCHSEL_CNT:3; 
	    vuint32_t:7;
            vuint32_t DFEF:1;
            vuint32_t:3;
	    vuint32_t WTHH:1; 
            vuint32_t WTHL:1; 
            vuint32_t CDVF:1;
            vuint32_t DFORF:1;
            vuint32_t DFFF:1;
        } B;
    } SFR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:14;
	    vuint32_t WTHDIRS:1; // Added on K2 cut2
            vuint32_t DFFDIRS:1;
            vuint32_t GDIGE:1;
            vuint32_t:11;
	    vuint32_t WTHDIRE:1;  // Added on K2 cut2
            vuint32_t CDVEE:1;
            vuint32_t DFORIE:1;
            vuint32_t DFFDIRE:1;
        } B;
    } RSER;

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t OSD:8;
        } B;
    } OSDR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:11;
	    vuint32_t FRST:1;
	    vuint32_t:4;
            vuint32_t FTHLD:4;
            vuint32_t:4;
	    vuint32_t FOWEN:1;
            vuint32_t FSIZE:2;
            vuint32_t FE:1;
        } B;
    } FCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t ST_KEY:16;
        } B;
    } STKR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t CDATA:16; /* ODA=0 */
        } B;
    } CDR;

    union {
        vuint32_t R;
        struct {
            vuint32_t THRH:16; /* Upper threshold value */
            vuint32_t THRL:16; /* Lower threshold value */
        } B;
    } WTHHLR;

};

/**************************************************************************/
/*                   Module: SIPI                                         */
/**************************************************************************/
struct SIPI_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:15;
            vuint32_t TC:1;
              vuint32_t:8;
            vuint32_t WL:2;
            vuint32_t CHEN:1;
            vuint32_t ST:1;
            vuint32_t IDT:1;
            vuint32_t RRT:1;
            vuint32_t WRT:1;
            vuint32_t DEN:1;
        } B;
    } CCR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t RAR:1;
            vuint32_t TID:3;
            vuint32_t ACKR:1;
            vuint32_t CB:1;
              vuint32_t:2;
        } B;
    } CSR0;

    uint8_t SIPI_reserved1[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:26;
            vuint32_t WAIE:1;
            vuint32_t RAIE:1;
            vuint32_t TCIE:1;
            vuint32_t TOIE:1;
            vuint32_t TIDIE:1;
            vuint32_t ACKIE:1;
        } B;
    } CIR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t TOR:8;
        } B;
    } CTOR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t CRCI:16;
            vuint32_t CRCT:16;
        } B;
    } CCRC0;

    union {
        vuint32_t R;
        struct {
            vuint32_t CAR:32;
        } B;
    } CAR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t CDR:32;
        } B;
    } CDR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t:15;
            vuint32_t TC:1;
              vuint32_t:8;
            vuint32_t WL:2;
            vuint32_t CHEN:1;
            vuint32_t ST:1;
            vuint32_t IDT:1;
            vuint32_t RRT:1;
            vuint32_t WRT:1;
            vuint32_t DEN:1;
        } B;
    } CCR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t RAR:1;
            vuint32_t TID:3;
            vuint32_t ACKR:1;
            vuint32_t CB:1;
              vuint32_t:2;
        } B;
    } CSR1;

    uint8_t SIPI_reserved2[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:26;
            vuint32_t WAIE:1;
            vuint32_t RAIE:1;
            vuint32_t TCIE:1;
            vuint32_t TOIE:1;
            vuint32_t TIDIE:1;
            vuint32_t ACKIE:1;
        } B;
    } CIR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t TOR:8;
        } B;
    } CTOR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t CRCI:16;
            vuint32_t CRCT:16;
        } B;
    } CCRC1;

    union {
        vuint32_t R;
        struct {
            vuint32_t CAR:32;
        } B;
    } CAR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t CDR:32;
        } B;
    } CDR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t:15;
            vuint32_t TC:1;
              vuint32_t:8;
            vuint32_t WL:2;
            vuint32_t CHEN:1;
            vuint32_t ST:1;
            vuint32_t IDT:1;
            vuint32_t RRT:1;
            vuint32_t WRT:1;
            vuint32_t DEN:1;
        } B;
    } CCR2;

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t RAR:1;
            vuint32_t TID:3;
            vuint32_t ACKR:1;
            vuint32_t CB:1;
              vuint32_t:2;
        } B;
    } CSR2;

    uint8_t SIPI_reserved3[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:26;
            vuint32_t WAIE:1;
            vuint32_t RAIE:1;
            vuint32_t TCIE:1;
            vuint32_t TOIE:1;
            vuint32_t TIDIE:1;
            vuint32_t ACKIE:1;
        } B;
    } CIR2;

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t TOR:8;
        } B;
    } CTOR2;

    union {
        vuint32_t R;
        struct {
            vuint32_t CRCI:16;
            vuint32_t CRCT:16;
        } B;
    } CCRC2;

    union {
        vuint32_t R;
        struct {
            vuint32_t CAR:32;
        } B;
    } CAR2;

    union {
        vuint32_t R;
        struct {
            vuint32_t CDR2:32;
        } B;
    } CDR2[8];

    union {
        vuint32_t R;
        struct {
            vuint32_t:15;
            vuint32_t TC:1;
              vuint32_t:8;
            vuint32_t WL:2;
            vuint32_t CHEN:1;
            vuint32_t ST:1;
            vuint32_t IDT:1;
            vuint32_t RRT:1;
            vuint32_t WRT:1;
            vuint32_t DEN:1;
        } B;
    } CCR3;

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t RAR:1;
            vuint32_t TID:3;
            vuint32_t ACKR:1;
            vuint32_t CB:1;
              vuint32_t:2;
        } B;
    } CSR3;

    uint8_t SIPI_reserved4[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:26;
            vuint32_t WAIE:1;
            vuint32_t RAIE:1;
            vuint32_t TCIE:1;
            vuint32_t TOIE:1;
            vuint32_t TIDIE:1;
            vuint32_t ACKIE:1;
        } B;
    } CIR3;

    union {
        vuint32_t R;
        struct {
            vuint32_t:24;
            vuint32_t TOR:8;
        } B;
    } CTOR3;

    union {
        vuint32_t R;
        struct {
            vuint32_t CRCI:16;
            vuint32_t CRCT:16;
        } B;
    } CCRC3;

    union {
        vuint32_t R;
        struct {
            vuint32_t CAR:32;
        } B;
    } CAR3;

    union {
        vuint32_t R;
        struct {
            vuint32_t CDR2:32;
        } B;
    } CDR3;

    union {
        vuint32_t R;
        struct {
            vuint32_t FRZ:1;
            vuint32_t DOZE:1;
            vuint32_t HALT:1;
            vuint32_t:2;
            vuint32_t PRSCLR:11;
            vuint32_t AID:2;
            vuint32_t:3;
            vuint32_t CRCIE:1;
            vuint32_t MCRIE:1;
            vuint32_t:4;
	    vuint32_t CHNSB:1;
            vuint32_t TEN:1;
            vuint32_t INIT:1;
            vuint32_t MOEN:1;
            vuint32_t SR:1;
        } B;
    } MCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t FRZACK:1;
            vuint32_t LPMACK:1;
              vuint32_t:19;
            vuint32_t GCRCE:1;
            vuint32_t MCR:1;
              vuint32_t:1;
            vuint32_t TE:4;
            vuint32_t STATE:4;
        } B;
    } SR;

    union {
        vuint32_t R;
        struct {
            vuint32_t MXCNT:30;
              vuint32_t:2;
        } B;
    } MAXCR;

    union {
        vuint32_t R;
        struct {
            vuint32_t ADRLD:30;
              vuint32_t:2;
        } B;
    } ARR;

    union {
        vuint32_t R;
        struct {
            vuint32_t ADCNT:30;
              vuint32_t:2;
        } B;
    } ACR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:5;
            vuint32_t TOE3:1;
            vuint32_t TIDE3:1;
            vuint32_t ACKE3:1;
              vuint32_t:5;
            vuint32_t TOE2:1;
            vuint32_t TIDE2:1;
            vuint32_t ACKE2:1;
              vuint32_t:5;
            vuint32_t TOE1:1;
            vuint32_t TIDE1:1;
            vuint32_t ACKE1:1;
              vuint32_t:5;
            vuint32_t TOE0:1;
            vuint32_t TIDE0:1;
            vuint32_t ACKE0:1;
        } B;
    } ERR;
};
/**************************************************************************/
/*                   Module: SIUL2                                        */
/**************************************************************************/
struct SIUL2_tag {
    uint8_t SIUL2_reserved0[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t PARTNUM:16;
            vuint32_t :1;
            vuint32_t PKG:5;
              vuint32_t:2;
            vuint32_t MAJOR_MASK:4;
            vuint32_t MINOR_MASK:4;
        } B;
    } MIDR1;

    union {
        vuint32_t R;
        struct {
            vuint32_t SF:1;
            vuint32_t FLASH_SIZE_1:4;
            vuint32_t FLASH_SIZE_2:4;
              vuint32_t:7;
            vuint32_t FAMILYNUM:8;
              vuint32_t:8;
        } B;
    } MIDR2;

    uint8_t SIUL2_reserved1[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:21;
            vuint32_t EIF10:1;
            vuint32_t:4;
            vuint32_t EIF5:1;
            vuint32_t:1;
            vuint32_t EIF3:1;
	    vuint32_t EIF2:1;
	    vuint32_t EIF1:1;
	    vuint32_t EIF0:1;
        } B;
    } DISR0;

    uint8_t SIUL2_PD_reserved2[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:21;
            vuint32_t EIRE10:1;
            vuint32_t:4;
            vuint32_t EIRE5:1;
            vuint32_t:1;
            vuint32_t EIRE3:1;
	    vuint32_t EIRE2:1;
	    vuint32_t EIRE1:1;
	    vuint32_t EIRE0:1;
        } B;
    } DIRER0;

    uint8_t SIUL2_reserved3[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:21;
            vuint32_t DIRS10:1;
            vuint32_t:4;
            vuint32_t DIRS5:1;
            vuint32_t:1;
            vuint32_t DIRS3:1;
	    vuint32_t DIRS2:1;
	    vuint32_t DIRS1:1;
	    vuint32_t DIRS0:1;
        } B;
    } DIRSR0;

    uint8_t SIUL2_reserved4[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:21;
            vuint32_t IREE10:1;
            vuint32_t:4;
            vuint32_t IREE5:1;
            vuint32_t:1;
            vuint32_t IREE3:1;
	    vuint32_t IREE2:1;
	    vuint32_t IREE1:1;
	    vuint32_t IREE0:1;
        } B;
    } IREER0;

    uint8_t SIUL2_reserved5[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:21;
            vuint32_t IFEE10:1;
            vuint32_t:4;
            vuint32_t IFEE5:1;
            vuint32_t:1;
            vuint32_t IFEE3:1;
	    vuint32_t IFEE2:1;
	    vuint32_t IFEE1:1;
	    vuint32_t IFEE0:1;
        } B;
    } IFEER0;

    uint8_t SIUL2_reserved6[4];

    union {
        vuint32_t R;
        struct {
           vuint32_t:21;
            vuint32_t IFER10:1;
            vuint32_t:4;
            vuint32_t IFER5:1;
            vuint32_t:1;
            vuint32_t IFER3:1;
	    vuint32_t IFER2:1;
	    vuint32_t IFER1:1;
	    vuint32_t IFER0:1;
        } B;
    } IFER0;

    uint8_t SIUL2_reserved7[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:28;
            vuint32_t MAXCNTx:4;
        } B;
    } IFMCR[32];

    union {
        vuint32_t R;
        struct {
            vuint32_t:28;
            vuint32_t IFCP:4;
        } B;
    } IFCPR;

    uint8_t SIUL2_reserved10[380];

    /*  I/O Pin Multiplexed Signal Configuration Registers */ 
    union {
        vuint32_t R;
        struct {
            vuint32_t:2;
            vuint32_t OERC:2;
            vuint32_t:1;
            vuint32_t ODC:3;
            vuint32_t SMC:1;
            vuint32_t APC:1;
            vuint32_t ILS:2;
            vuint32_t IBE:1;
            vuint32_t HYS:1;
            vuint32_t WPDE:1;
            vuint32_t WPUE:1;
            vuint32_t INV:1;
            vuint32_t:7;
            vuint32_t SSS:8;
        } B;
    } MSCR_IO[512];

    /* Multiplexed Signal Configuration Registers for Multiplexed Input Selection */
    union {
        vuint32_t R;
        struct {
            vuint32_t reserved_0:16;
            vuint32_t INV:1;
            vuint32_t reserved_1:7;
            vuint32_t SSS:8;
        } B;
    } MSCR_MUX[512];

    uint8_t SIUL2_reserved9[192];

    union {
        vuint8_t R;
        struct {
            vuint8_t:7;
            vuint8_t PDO:1;
        } B;
    } GPDO[512];

    union {
        vuint8_t R;
        struct {
            vuint8_t:7;
            vuint8_t PDI:1;
        } B;
    } GPDI[512];

    union {
        vuint16_t R;
        struct {
            vuint16_t PPDO:16;
        } B;
    } PGPDO[32];

    union {
        vuint16_t R;
        struct {
            vuint16_t PPDI:16;
        } B;
    } PGPDI[32];

    union {
        vuint32_t R;
        struct {
            vuint32_t MASK:16;
            vuint32_t MPPDO:16;
        } B;
    } MPGPDO[32];
};
/**************************************************************************/
/*                   Module: SMPU                                         */
/**************************************************************************/
struct SMPU_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t MERR:16;
              vuint32_t:1;
              vuint32_t:11;
            vuint32_t HRL:3;
            vuint32_t GVLD:1;
        } B;
    } CESR0;

    union {
        vuint32_t R;
        struct {
            vuint32_t MEOVR:16;
              vuint32_t:1;
              vuint32_t:11;
            vuint32_t NRGD:4;
        } B;
    } CESR1;

    uint8_t SMPU_reserved1[248];

    struct {
        union {
            vuint32_t R;
            struct {
                vuint32_t EADDR:32;
            } B;
        } EAR;

        union {
            vuint32_t R;
            struct {
                vuint32_t EACD:24;
                  vuint32_t:1;
                vuint32_t EATTR:2;
                vuint32_t ERW:1;
                vuint32_t EMN:4;
            } B;
        } EDR;
    } Channel[16];

    uint8_t SMPU_reserved2[640];

    union {
        vuint32_t R;
        struct {
            vuint32_t SRTADDR:32;
        } B;
    } RGD0_WORD0;

    union {
        vuint32_t R;
        struct {
            vuint32_t ENDADDR:32;
        } B;
    } RGD0_WORD1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0P:2;    /* FMT0 */
            vuint32_t M1P:2;
            vuint32_t M2P:2;
            vuint32_t M3P:2;
            vuint32_t M4P:2;
            vuint32_t M5P:2;
            vuint32_t M6P:2;
            vuint32_t M7P:2;
            vuint32_t M8P:2;
            vuint32_t M9P:2;
            vuint32_t M10P:2;
            vuint32_t M11P:2;
            vuint32_t M12P:2;
            vuint32_t M13P:2;
            vuint32_t M14P:2;
            vuint32_t M15P:2;
            // vuint32_t M0S:2;  /* FMT1 */
            // vuint32_t M1S:2;
            // vuint32_t M2S:2;
            // vuint32_t M3S:2;
            // vuint32_t M4S:2;
            // vuint32_t M5S:2;
            // vuint32_t M6S:2;
            // vuint32_t M7S:2;
            // vuint32_t M8S:2;
            // vuint32_t M9S:2;
            // vuint32_t M10S:2;
            // vuint32_t M11S:2;
            // vuint32_t M12S:2;
            // vuint32_t M13S:2;
            // vuint32_t M14S:2;
            // vuint32_t M15S:2;
        } B;
    } RGD0_WORD2;

    union {
        vuint32_t R;
        struct {
            vuint32_t ACCSET1:6;
            vuint32_t ACCSET2:6;
            vuint32_t ACCSET3:6;
              vuint32_t:9;
            vuint32_t FMT:1;
            vuint32_t RO:1;
              vuint32_t:1;
            vuint32_t CI:1;
            vuint32_t VLD:1;
        } B;
    } RGD0_WORD3;

    union {
        vuint32_t R;
        struct {
            vuint32_t SRTADDR:32;
        } B;
    } RGD1_WORD0;

    union {
        vuint32_t R;
        struct {
            vuint32_t ENDADDR:32;
        } B;
    } RGD1_WORD1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0P:2;    /* FMT0 */
            vuint32_t M1P:2;
            vuint32_t M2P:2;
            vuint32_t M3P:2;
            vuint32_t M4P:2;
            vuint32_t M5P:2;
            vuint32_t M6P:2;
            vuint32_t M7P:2;
            vuint32_t M8P:2;
            vuint32_t M9P:2;
            vuint32_t M10P:2;
            vuint32_t M11P:2;
            vuint32_t M12P:2;
            vuint32_t M13P:2;
            vuint32_t M14P:2;
            vuint32_t M15P:2;
            // vuint32_t M0S:2;  /* FMT1 */
            // vuint32_t M1S:2;
            // vuint32_t M2S:2;
            // vuint32_t M3S:2;
            // vuint32_t M4S:2;
            // vuint32_t M5S:2;
            // vuint32_t M6S:2;
            // vuint32_t M7S:2;
            // vuint32_t M8S:2;
            // vuint32_t M9S:2;
            // vuint32_t M10S:2;
            // vuint32_t M11S:2;
            // vuint32_t M12S:2;
            // vuint32_t M13S:2;
            // vuint32_t M14S:2;
            // vuint32_t M15S:2;
        } B;
    } RGD1_WORD2;

    union {
        vuint32_t R;
        struct {
            vuint32_t ACCSET1:6;
            vuint32_t ACCSET2:6;
            vuint32_t ACCSET3:6;
              vuint32_t:9;
            vuint32_t FMT:1;
            vuint32_t RO:1;
              vuint32_t:1;
            vuint32_t CI:1;
            vuint32_t VLD:1;
        } B;
    } RGD1_WORD3;

    union {
        vuint32_t R;
        struct {
            vuint32_t SRTADDR:32;
        } B;
    } RGD2_WORD0;

    union {
        vuint32_t R;
        struct {
            vuint32_t ENDADDR:32;
        } B;
    } RGD2_WORD1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0P:2;    /* FMT0 */
            vuint32_t M1P:2;
            vuint32_t M2P:2;
            vuint32_t M3P:2;
            vuint32_t M4P:2;
            vuint32_t M5P:2;
            vuint32_t M6P:2;
            vuint32_t M7P:2;
            vuint32_t M8P:2;
            vuint32_t M9P:2;
            vuint32_t M10P:2;
            vuint32_t M11P:2;
            vuint32_t M12P:2;
            vuint32_t M13P:2;
            vuint32_t M14P:2;
            vuint32_t M15P:2;
            // vuint32_t M0S:2;  /* FMT1 */
            // vuint32_t M1S:2;
            // vuint32_t M2S:2;
            // vuint32_t M3S:2;
            // vuint32_t M4S:2;
            // vuint32_t M5S:2;
            // vuint32_t M6S:2;
            // vuint32_t M7S:2;
            // vuint32_t M8S:2;
            // vuint32_t M9S:2;
            // vuint32_t M10S:2;
            // vuint32_t M11S:2;
            // vuint32_t M12S:2;
            // vuint32_t M13S:2;
            // vuint32_t M14S:2;
            // vuint32_t M15S:2;
        } B;
    } RGD2_WORD2;

    union {
        vuint32_t R;
        struct {
            vuint32_t ACCSET1:6;
            vuint32_t ACCSET2:6;
            vuint32_t ACCSET3:6;
              vuint32_t:9;
            vuint32_t FMT:1;
            vuint32_t RO:1;
              vuint32_t:1;
            vuint32_t CI:1;
            vuint32_t VLD:1;
        } B;
    } RGD2_WORD3;

    union {
        vuint32_t R;
        struct {
            vuint32_t SRTADDR:32;
        } B;
    } RGD3_WORD0;

    union {
        vuint32_t R;
        struct {
            vuint32_t ENDADDR:32;
        } B;
    } RGD3_WORD1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0P:2;    /* FMT0 */
            vuint32_t M1P:2;
            vuint32_t M2P:2;
            vuint32_t M3P:2;
            vuint32_t M4P:2;
            vuint32_t M5P:2;
            vuint32_t M6P:2;
            vuint32_t M7P:2;
            vuint32_t M8P:2;
            vuint32_t M9P:2;
            vuint32_t M10P:2;
            vuint32_t M11P:2;
            vuint32_t M12P:2;
            vuint32_t M13P:2;
            vuint32_t M14P:2;
            vuint32_t M15P:2;
            // vuint32_t M0S:2;  /* FMT1 */
            // vuint32_t M1S:2;
            // vuint32_t M2S:2;
            // vuint32_t M3S:2;
            // vuint32_t M4S:2;
            // vuint32_t M5S:2;
            // vuint32_t M6S:2;
            // vuint32_t M7S:2;
            // vuint32_t M8S:2;
            // vuint32_t M9S:2;
            // vuint32_t M10S:2;
            // vuint32_t M11S:2;
            // vuint32_t M12S:2;
            // vuint32_t M13S:2;
            // vuint32_t M14S:2;
            // vuint32_t M15S:2;
        } B;
    } RGD3_WORD2;

    union {
        vuint32_t R;
        struct {
            vuint32_t ACCSET1:6;
            vuint32_t ACCSET2:6;
            vuint32_t ACCSET3:6;
              vuint32_t:9;
            vuint32_t FMT:1;
            vuint32_t RO:1;
              vuint32_t:1;
            vuint32_t CI:1;
            vuint32_t VLD:1;
        } B;
    } RGD3_WORD3;

    union {
        vuint32_t R;
        struct {
            vuint32_t SRTADDR:32;
        } B;
    } RGD4_WORD0;

    union {
        vuint32_t R;
        struct {
            vuint32_t ENDADDR:32;
        } B;
    } RGD4_WORD1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0P:2;    /* FMT0 */
            vuint32_t M1P:2;
            vuint32_t M2P:2;
            vuint32_t M3P:2;
            vuint32_t M4P:2;
            vuint32_t M5P:2;
            vuint32_t M6P:2;
            vuint32_t M7P:2;
            vuint32_t M8P:2;
            vuint32_t M9P:2;
            vuint32_t M10P:2;
            vuint32_t M11P:2;
            vuint32_t M12P:2;
            vuint32_t M13P:2;
            vuint32_t M14P:2;
            vuint32_t M15P:2;
            // vuint32_t M0S:2;  /* FMT1 */
            // vuint32_t M1S:2;
            // vuint32_t M2S:2;
            // vuint32_t M3S:2;
            // vuint32_t M4S:2;
            // vuint32_t M5S:2;
            // vuint32_t M6S:2;
            // vuint32_t M7S:2;
            // vuint32_t M8S:2;
            // vuint32_t M9S:2;
            // vuint32_t M10S:2;
            // vuint32_t M11S:2;
            // vuint32_t M12S:2;
            // vuint32_t M13S:2;
            // vuint32_t M14S:2;
            // vuint32_t M15S:2;
        } B;
    } RGD4_WORD2;

    union {
        vuint32_t R;
        struct {
            vuint32_t ACCSET1:6;
            vuint32_t ACCSET2:6;
            vuint32_t ACCSET3:6;
              vuint32_t:9;
            vuint32_t FMT:1;
            vuint32_t RO:1;
              vuint32_t:1;
            vuint32_t CI:1;
            vuint32_t VLD:1;
        } B;
    } RGD4_WORD3;

    union {
        vuint32_t R;
        struct {
            vuint32_t SRTADDR:32;
        } B;
    } RGD5_WORD0;

    union {
        vuint32_t R;
        struct {
            vuint32_t ENDADDR:32;
        } B;
    } RGD5_WORD1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0P:2;    /* FMT0 */
            vuint32_t M1P:2;
            vuint32_t M2P:2;
            vuint32_t M3P:2;
            vuint32_t M4P:2;
            vuint32_t M5P:2;
            vuint32_t M6P:2;
            vuint32_t M7P:2;
            vuint32_t M8P:2;
            vuint32_t M9P:2;
            vuint32_t M10P:2;
            vuint32_t M11P:2;
            vuint32_t M12P:2;
            vuint32_t M13P:2;
            vuint32_t M14P:2;
            vuint32_t M15P:2;
            // vuint32_t M0S:2;  /* FMT1 */
            // vuint32_t M1S:2;
            // vuint32_t M2S:2;
            // vuint32_t M3S:2;
            // vuint32_t M4S:2;
            // vuint32_t M5S:2;
            // vuint32_t M6S:2;
            // vuint32_t M7S:2;
            // vuint32_t M8S:2;
            // vuint32_t M9S:2;
            // vuint32_t M10S:2;
            // vuint32_t M11S:2;
            // vuint32_t M12S:2;
            // vuint32_t M13S:2;
            // vuint32_t M14S:2;
            // vuint32_t M15S:2;
        } B;
    } RGD5_WORD2;

    union {
        vuint32_t R;
        struct {
            vuint32_t ACCSET1:6;
            vuint32_t ACCSET2:6;
            vuint32_t ACCSET3:6;
              vuint32_t:9;
            vuint32_t FMT:1;
            vuint32_t RO:1;
              vuint32_t:1;
            vuint32_t CI:1;
            vuint32_t VLD:1;
        } B;
    } RGD5_WORD3;

    union {
        vuint32_t R;
        struct {
            vuint32_t SRTADDR:32;
        } B;
    } RGD6_WORD0;

    union {
        vuint32_t R;
        struct {
            vuint32_t ENDADDR:32;
        } B;
    } RGD6_WORD1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0P:2;    /* FMT0 */
            vuint32_t M1P:2;
            vuint32_t M2P:2;
            vuint32_t M3P:2;
            vuint32_t M4P:2;
            vuint32_t M5P:2;
            vuint32_t M6P:2;
            vuint32_t M7P:2;
            vuint32_t M8P:2;
            vuint32_t M9P:2;
            vuint32_t M10P:2;
            vuint32_t M11P:2;
            vuint32_t M12P:2;
            vuint32_t M13P:2;
            vuint32_t M14P:2;
            vuint32_t M15P:2;
            // vuint32_t M0S:2;  /* FMT1 */
            // vuint32_t M1S:2;
            // vuint32_t M2S:2;
            // vuint32_t M3S:2;
            // vuint32_t M4S:2;
            // vuint32_t M5S:2;
            // vuint32_t M6S:2;
            // vuint32_t M7S:2;
            // vuint32_t M8S:2;
            // vuint32_t M9S:2;
            // vuint32_t M10S:2;
            // vuint32_t M11S:2;
            // vuint32_t M12S:2;
            // vuint32_t M13S:2;
            // vuint32_t M14S:2;
            // vuint32_t M15S:2;
        } B;
    } RGD6_WORD2;

    union {
        vuint32_t R;
        struct {
            vuint32_t ACCSET1:6;
            vuint32_t ACCSET2:6;
            vuint32_t ACCSET3:6;
              vuint32_t:9;
            vuint32_t FMT:1;
            vuint32_t RO:1;
              vuint32_t:1;
            vuint32_t CI:1;
            vuint32_t VLD:1;
        } B;
    } RGD6_WORD3;

    union {
        vuint32_t R;
        struct {
            vuint32_t SRTADDR:32;
        } B;
    } RGD7_WORD0;

    union {
        vuint32_t R;
        struct {
            vuint32_t ENDADDR:32;
        } B;
    } RGD7_WORD1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0P:2;    /* FMT0 */
            vuint32_t M1P:2;
            vuint32_t M2P:2;
            vuint32_t M3P:2;
            vuint32_t M4P:2;
            vuint32_t M5P:2;
            vuint32_t M6P:2;
            vuint32_t M7P:2;
            vuint32_t M8P:2;
            vuint32_t M9P:2;
            vuint32_t M10P:2;
            vuint32_t M11P:2;
            vuint32_t M12P:2;
            vuint32_t M13P:2;
            vuint32_t M14P:2;
            vuint32_t M15P:2;
            // vuint32_t M0S:2;  /* FMT1 */
            // vuint32_t M1S:2;
            // vuint32_t M2S:2;
            // vuint32_t M3S:2;
            // vuint32_t M4S:2;
            // vuint32_t M5S:2;
            // vuint32_t M6S:2;
            // vuint32_t M7S:2;
            // vuint32_t M8S:2;
            // vuint32_t M9S:2;
            // vuint32_t M10S:2;
            // vuint32_t M11S:2;
            // vuint32_t M12S:2;
            // vuint32_t M13S:2;
            // vuint32_t M14S:2;
            // vuint32_t M15S:2;
        } B;
    } RGD7_WORD2;

    union {
        vuint32_t R;
        struct {
            vuint32_t ACCSET1:6;
            vuint32_t ACCSET2:6;
            vuint32_t ACCSET3:6;
              vuint32_t:9;
            vuint32_t FMT:1;
            vuint32_t RO:1;
              vuint32_t:1;
            vuint32_t CI:1;
            vuint32_t VLD:1;
        } B;
    } RGD7_WORD3;

    union {
        vuint32_t R;
        struct {
            vuint32_t SRTADDR:32;
        } B;
    } RGD8_WORD0;

    union {
        vuint32_t R;
        struct {
            vuint32_t ENDADDR:32;
        } B;
    } RGD8_WORD1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0P:2;    /* FMT0 */
            vuint32_t M1P:2;
            vuint32_t M2P:2;
            vuint32_t M3P:2;
            vuint32_t M4P:2;
            vuint32_t M5P:2;
            vuint32_t M6P:2;
            vuint32_t M7P:2;
            vuint32_t M8P:2;
            vuint32_t M9P:2;
            vuint32_t M10P:2;
            vuint32_t M11P:2;
            vuint32_t M12P:2;
            vuint32_t M13P:2;
            vuint32_t M14P:2;
            vuint32_t M15P:2;
            // vuint32_t M0S:2;  /* FMT1 */
            // vuint32_t M1S:2;
            // vuint32_t M2S:2;
            // vuint32_t M3S:2;
            // vuint32_t M4S:2;
            // vuint32_t M5S:2;
            // vuint32_t M6S:2;
            // vuint32_t M7S:2;
            // vuint32_t M8S:2;
            // vuint32_t M9S:2;
            // vuint32_t M10S:2;
            // vuint32_t M11S:2;
            // vuint32_t M12S:2;
            // vuint32_t M13S:2;
            // vuint32_t M14S:2;
            // vuint32_t M15S:2;
        } B;
    } RGD8_WORD2;

    union {
        vuint32_t R;
        struct {
            vuint32_t ACCSET1:6;
            vuint32_t ACCSET2:6;
            vuint32_t ACCSET3:6;
              vuint32_t:9;
            vuint32_t FMT:1;
            vuint32_t RO:1;
              vuint32_t:1;
            vuint32_t CI:1;
            vuint32_t VLD:1;
        } B;
    } RGD8_WORD3;

    union {
        vuint32_t R;
        struct {
            vuint32_t SRTADDR:32;
        } B;
    } RGD9_WORD0;

    union {
        vuint32_t R;
        struct {
            vuint32_t ENDADDR:32;
        } B;
    } RGD9_WORD1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0P:2;    /* FMT0 */
            vuint32_t M1P:2;
            vuint32_t M2P:2;
            vuint32_t M3P:2;
            vuint32_t M4P:2;
            vuint32_t M5P:2;
            vuint32_t M6P:2;
            vuint32_t M7P:2;
            vuint32_t M8P:2;
            vuint32_t M9P:2;
            vuint32_t M10P:2;
            vuint32_t M11P:2;
            vuint32_t M12P:2;
            vuint32_t M13P:2;
            vuint32_t M14P:2;
            vuint32_t M15P:2;
            // vuint32_t M0S:2;  /* FMT1 */
            // vuint32_t M1S:2;
            // vuint32_t M2S:2;
            // vuint32_t M3S:2;
            // vuint32_t M4S:2;
            // vuint32_t M5S:2;
            // vuint32_t M6S:2;
            // vuint32_t M7S:2;
            // vuint32_t M8S:2;
            // vuint32_t M9S:2;
            // vuint32_t M10S:2;
            // vuint32_t M11S:2;
            // vuint32_t M12S:2;
            // vuint32_t M13S:2;
            // vuint32_t M14S:2;
            // vuint32_t M15S:2;
        } B;
    } RGD9_WORD2;

    union {
        vuint32_t R;
        struct {
            vuint32_t ACCSET1:6;
            vuint32_t ACCSET2:6;
            vuint32_t ACCSET3:6;
              vuint32_t:9;
            vuint32_t FMT:1;
            vuint32_t RO:1;
              vuint32_t:1;
            vuint32_t CI:1;
            vuint32_t VLD:1;
        } B;
    } RGD9_WORD3;

    union {
        vuint32_t R;
        struct {
            vuint32_t SRTADDR:32;
        } B;
    } RGD10_WORD0;

    union {
        vuint32_t R;
        struct {
            vuint32_t ENDADDR:32;
        } B;
    } RGD10_WORD1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0P:2;    /* FMT0 */
            vuint32_t M1P:2;
            vuint32_t M2P:2;
            vuint32_t M3P:2;
            vuint32_t M4P:2;
            vuint32_t M5P:2;
            vuint32_t M6P:2;
            vuint32_t M7P:2;
            vuint32_t M8P:2;
            vuint32_t M9P:2;
            vuint32_t M10P:2;
            vuint32_t M11P:2;
            vuint32_t M12P:2;
            vuint32_t M13P:2;
            vuint32_t M14P:2;
            vuint32_t M15P:2;
            // vuint32_t M0S:2;  /* FMT1 */
            // vuint32_t M1S:2;
            // vuint32_t M2S:2;
            // vuint32_t M3S:2;
            // vuint32_t M4S:2;
            // vuint32_t M5S:2;
            // vuint32_t M6S:2;
            // vuint32_t M7S:2;
            // vuint32_t M8S:2;
            // vuint32_t M9S:2;
            // vuint32_t M10S:2;
            // vuint32_t M11S:2;
            // vuint32_t M12S:2;
            // vuint32_t M13S:2;
            // vuint32_t M14S:2;
            // vuint32_t M15S:2;
        } B;
    } RGD10_WORD2;

    union {
        vuint32_t R;
        struct {
            vuint32_t ACCSET1:6;
            vuint32_t ACCSET2:6;
            vuint32_t ACCSET3:6;
              vuint32_t:9;
            vuint32_t FMT:1;
            vuint32_t RO:1;
              vuint32_t:1;
            vuint32_t CI:1;
            vuint32_t VLD:1;
        } B;
    } RGD10_WORD3;

    union {
        vuint32_t R;
        struct {
            vuint32_t SRTADDR:32;
        } B;
    } RGD11_WORD0;

    union {
        vuint32_t R;
        struct {
            vuint32_t ENDADDR:32;
        } B;
    } RGD11_WORD1;

    union {
        vuint32_t R;
        struct {
            vuint32_t M0P:2;    /* FMT0 */
            vuint32_t M1P:2;
            vuint32_t M2P:2;
            vuint32_t M3P:2;
            vuint32_t M4P:2;
            vuint32_t M5P:2;
            vuint32_t M6P:2;
            vuint32_t M7P:2;
            vuint32_t M8P:2;
            vuint32_t M9P:2;
            vuint32_t M10P:2;
            vuint32_t M11P:2;
            vuint32_t M12P:2;
            vuint32_t M13P:2;
            vuint32_t M14P:2;
            vuint32_t M15P:2;
            // vuint32_t M0S:2;  /* FMT1 */
            // vuint32_t M1S:2;
            // vuint32_t M2S:2;
            // vuint32_t M3S:2;
            // vuint32_t M4S:2;
            // vuint32_t M5S:2;
            // vuint32_t M6S:2;
            // vuint32_t M7S:2;
            // vuint32_t M8S:2;
            // vuint32_t M9S:2;
            // vuint32_t M10S:2;
            // vuint32_t M11S:2;
            // vuint32_t M12S:2;
            // vuint32_t M13S:2;
            // vuint32_t M14S:2;
            // vuint32_t M15S:2;
        } B;
    } RGD11_WORD2;

    union {
        vuint32_t R;
        struct {
            vuint32_t ACCSET1:6;
            vuint32_t ACCSET2:6;
            vuint32_t ACCSET3:6;
              vuint32_t:9;
            vuint32_t FMT:1;
            vuint32_t RO:1;
              vuint32_t:1;
            vuint32_t CI:1;
            vuint32_t VLD:1;
        } B;
    } RGD11_WORD3;

};
/**************************************************************************/
/*                   Module: SRX                                          */
/**************************************************************************/
struct SRX_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t TSPRSC:8;
              vuint32_t:14;
            vuint32_t FMDUIE:1;
            vuint32_t SMDUIE:1;
              vuint32_t:3;
            vuint32_t FAST_CLR:1;
              vuint32_t:1;
            vuint32_t DBG_FRZ:1;
              vuint32_t:1;
            vuint32_t SENT_EN:1;
        } B;
    } GBL_CTRL;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t EN_CHn:16;
        } B;
    } CHNL_EN;

    union {
        vuint32_t R;
        struct {
            vuint32_t:22;
            vuint32_t FDMU:1;
            vuint32_t SMDU:1;
              vuint32_t:8;
        } B;
    } GBL_STATUS;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t F_RDYn:16;
        } B;
    } FMSG_RDY;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t S_RDYn:16;
        } B;
    } SMSG_RDY;

    uint8_t SRX_reserved1[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t NIBBCH0:3;
              vuint32_t:1;
            vuint32_t NIBBCH1:3;
              vuint32_t:1;
            vuint32_t NIBBCH2:3;
              vuint32_t:1;
            vuint32_t NIBBCH3:3;
              vuint32_t:1;
            vuint32_t NICCH4:3;
              vuint32_t:1;
            vuint32_t NIBBCH5:3;
              vuint32_t:1;
            vuint32_t NIBBCH6:3;
              vuint32_t:1;
            vuint32_t NIBBCH7:3;
        } B;
    } DATA_CTRL1;

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t NIBBCH8:3;
              vuint32_t:1;
            vuint32_t NIBBCH9:3;
              vuint32_t:1;
            vuint32_t NIBBCH10:3;
              vuint32_t:1;
            vuint32_t NIBBCH11:3;
              vuint32_t:1;
            vuint32_t NIBBCH12:3;
              vuint32_t:1;
            vuint32_t NIBBCH13:3;
              vuint32_t:1;
            vuint32_t NIBBCH14:3;
              vuint32_t:1;
            vuint32_t NIBBCH15:3;
        } B;
    } DATA_CTRL2;

    uint8_t SRX_reserved2[8];

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t FDMA_ENn:16;
        } B;
    } FDMA_CTRL;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t SDMA_ENn:16;
        } B;
    } SDMA_CTRL;

    uint8_t SRX_reserved3[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t FRDY_IEn:16;
        } B;
    } FRDY_IE;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t SRDY_IEn:16;
        } B;
    } SRDY_IE;

    uint8_t SRX_reserved4[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t CHNUM:4;
            vuint32_t SCNIB:4;
            vuint32_t DNIB1:4;
            vuint32_t DNIB2:4;
            vuint32_t DNIB3:4;
            vuint32_t DNIB4:4;
            vuint32_t DNIB5:4;
            vuint32_t DNIB6:4;
        } B;
    } DMA_FMSG_DATA;

    union {
        vuint32_t R;
        struct {
            vuint32_t:12;
            vuint32_t CRC4b:4;
              vuint32_t:16;
        } B;
    } DMA_FMSG_CRC;

    union {
        vuint32_t R;
        struct {
            vuint32_t TS:32;
        } B;
    } DMA_FMSG_TS;

    uint8_t SRX_reserved5[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t CHNUM:4;
            vuint32_t TYPE:1;
              vuint32_t:16;
            vuint32_t CFG:1;
            vuint32_t ID:4;
              vuint32_t:1;
            vuint32_t IDorDATA:4;
              vuint32_t:1;
        } B;
    } DMA_SMSG3;

    union {
        vuint32_t R;
        struct {
            vuint32_t:10;
            vuint32_t SMCRC:6;
              vuint32_t:4;
            vuint32_t DATA:12;
        } B;
    } DMA_SMSG2;

    union {
        vuint32_t R;
        struct {
            vuint32_t TS:32;
        } B;
    } DMA_SMSG_TS;

    uint8_t SRX_reserved6[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t CMPRSC:15;
            vuint32_t COMP_EN:1;
              vuint32_t:1;
            vuint32_t PRSC:14;
        } B;
    } CH0_CLK_CTRL;

    union {
        vuint32_t R;
        struct {
	    vuint32_t BUS_IDLE:1;
            vuint32_t:3;
            vuint32_t CAL_RESYNC:1;
            vuint32_t CAL_20_25:1;
            vuint32_t SMSG_OFLW:1;
            vuint32_t FMSG_OFLW:1;
              vuint32_t:1;
            vuint32_t PP_DIAG_ERR:1;
            vuint32_t CAL_LEN_ERR:1;
            vuint32_t CAL_DIAG_ERR:1;
            vuint32_t NIB_VAL_ERR:1;
            vuint32_t SMSG_CRC_ERR:1;
            vuint32_t FMSG_CRC_ERR:1;
            vuint32_t NUM_EDGES_ERR:1;
              vuint32_t:16;
        } B;
    } CH0_STATUS;

    union {
        vuint32_t R;
        struct {
            vuint32_t BUS_IDLE_CNT:4;
            vuint32_t IE_CAL_RESYNC:1;
            vuint32_t IE_CAL_20_25:1;
            vuint32_t IE_SMSG_OFLW:1;
            vuint32_t IE_FMSG_OFLW:1;
            vuint32_t FCRC_CHK_OFF:1;
            vuint32_t IE_PP_DIAG_ERR:1;
            vuint32_t IE_CAL_LEN_ERR:1;
            vuint32_t IE_CAL_DIAG_ERR:1;
            vuint32_t IE_NIB_VAL_ERR:1;
            vuint32_t IE_SMSG_CRC_ERR:1;
            vuint32_t IE_FMSG_CRC_ERR:1;
            vuint32_t IE_NUM_EDGES_ERR:1;
            vuint32_t DCHNG_INT:1;
            vuint32_t CAL_RNG:1;
            vuint32_t PP_CHKSEL:1;
            vuint32_t FCRC_TYPE:1;
            vuint32_t FCRC_SC_EN:1;
            vuint32_t SCRC_TYPE:1;
            vuint32_t PAUSE_EN:1;
            vuint32_t SUCC_CAL_CHK:1;
            vuint32_t FIL_CNT:8;
        } B;
    } CH0_CONFIG;

    uint8_t SRX_reserved7[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t CMPRSC:15;
            vuint32_t COMP_EN:1;
              vuint32_t:1;
            vuint32_t PRSC:14;
        } B;
    } CH1_CLK_CTRL;

    union {
        vuint32_t R;
        struct {
	    vuint32_t BUS_IDLE:1;
	    vuint32_t:3;
            vuint32_t CAL_RESYNC:1;
            vuint32_t CAL_20_25:1;
            vuint32_t SMSG_OFLW:1;
            vuint32_t FMSG_OFLW:1;
            vuint32_t:1;
            vuint32_t PP_DIAG_ERR:1;
            vuint32_t CAL_LEN_ERR:1;
            vuint32_t CAL_DIAG_ERR:1;
            vuint32_t NIB_VAL_ERR:1;
            vuint32_t SMSG_CRC_ERR:1;
            vuint32_t FMSG_CRC_ERR:1;
            vuint32_t NUM_EDGES_ERR:1;
             vuint32_t:16;
        } B;
    } CH1_STATUS;

    union {
        vuint32_t R;
        struct {
            vuint32_t BUS_IDLE_CNT:4;
            vuint32_t IE_CAL_RESYNC:1;
            vuint32_t IE_CAL_20_25:1;
            vuint32_t IE_SMSG_OFLW:1;
            vuint32_t IE_FMSG_OFLW:1;
            vuint32_t FCRC_CHK_OFF:1;
            vuint32_t IE_PP_DIAG_ERR:1;
            vuint32_t IE_CAL_LEN_ERR:1;
            vuint32_t IE_CAL_DIAG_ERR:1;
            vuint32_t IE_NIB_VAL_ERR:1;
            vuint32_t IE_SMSG_CRC_ERR:1;
            vuint32_t IE_FMSG_CRC_ERR:1;
            vuint32_t IE_NUM_EDGES_ERR:1;
            vuint32_t DCHNG_INT:1;
            vuint32_t CAL_RNG:1;
            vuint32_t PP_CHKSEL:1;
            vuint32_t FCRC_TYPE:1;
            vuint32_t FCRC_SC_EN:1;
            vuint32_t SCRC_TYPE:1;
            vuint32_t PAUSE_EN:1;
            vuint32_t SUCC_CAL_CHK:1;
            vuint32_t FIL_CNT:8;
        } B;
    } CH1_CONFIG;

    uint8_t SRX_reserved8[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t CMPRSC:15;
            vuint32_t COMP_EN:1;
              vuint32_t:1;
            vuint32_t PRSC:14;
        } B;
    } CH2_CLK_CTRL;

    union {
        vuint32_t R;
        struct {
	    vuint32_t BUS_IDLE:1;
	    vuint32_t:3;
            vuint32_t CAL_RESYNC:1;
            vuint32_t CAL_20_25:1;
            vuint32_t SMSG_OFLW:1;
            vuint32_t FMSG_OFLW:1;
            vuint32_t:1;
            vuint32_t PP_DIAG_ERR:1;
            vuint32_t CAL_LEN_ERR:1;
            vuint32_t CAL_DIAG_ERR:1;
            vuint32_t NIB_VAL_ERR:1;
            vuint32_t SMSG_CRC_ERR:1;
            vuint32_t FMSG_CRC_ERR:1;
            vuint32_t NUM_EDGES_ERR:1;
            vuint32_t:16;
        } B;
    } CH2_STATUS;

    union {
        vuint32_t R;
        struct {
            vuint32_t BUS_IDLE_CNT:4;
            vuint32_t IE_CAL_RESYNC:1;
            vuint32_t IE_CAL_20_25:1;
            vuint32_t IE_SMSG_OFLW:1;
            vuint32_t IE_FMSG_OFLW:1;
            vuint32_t FCRC_CHK_OFF:1;
            vuint32_t IE_PP_DIAG_ERR:1;
            vuint32_t IE_CAL_LEN_ERR:1;
            vuint32_t IE_CAL_DIAG_ERR:1;
            vuint32_t IE_NIB_VAL_ERR:1;
            vuint32_t IE_SMSG_CRC_ERR:1;
            vuint32_t IE_FMSG_CRC_ERR:1;
            vuint32_t IE_NUM_EDGES_ERR:1;
            vuint32_t DCHNG_INT:1;
            vuint32_t CAL_RNG:1;
            vuint32_t PP_CHKSEL:1;
            vuint32_t FCRC_TYPE:1;
            vuint32_t FCRC_SC_EN:1;
            vuint32_t SCRC_TYPE:1;
            vuint32_t PAUSE_EN:1;
            vuint32_t SUCC_CAL_CHK:1;
            vuint32_t FIL_CNT:8;
        } B;
    } CH2_CONFIG;

    uint8_t SRX_reserved9[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t CMPRSC:15;
            vuint32_t COMP_EN:1;
              vuint32_t:1;
            vuint32_t PRSC:14;
        } B;
    } CH3_CLK_CTRL;

    union {
        vuint32_t R;
        struct {
            vuint32_t BUS_IDLE:1;
	    vuint32_t:3;
            vuint32_t CAL_RESYNC:1;
            vuint32_t CAL_20_25:1;
            vuint32_t SMSG_OFLW:1;
            vuint32_t FMSG_OFLW:1;
            vuint32_t:1;
            vuint32_t PP_DIAG_ERR:1;
            vuint32_t CAL_LEN_ERR:1;
            vuint32_t CAL_DIAG_ERR:1;
            vuint32_t NIB_VAL_ERR:1;
            vuint32_t SMSG_CRC_ERR:1;
            vuint32_t FMSG_CRC_ERR:1;
            vuint32_t NUM_EDGES_ERR:1;
            vuint32_t:16;
        } B;
    } CH3_STATUS;

    union {
        vuint32_t R;
        struct {
             vuint32_t BUS_IDLE_CNT:4;
            vuint32_t IE_CAL_RESYNC:1;
            vuint32_t IE_CAL_20_25:1;
            vuint32_t IE_SMSG_OFLW:1;
            vuint32_t IE_FMSG_OFLW:1;
            vuint32_t FCRC_CHK_OFF:1;
            vuint32_t IE_PP_DIAG_ERR:1;
            vuint32_t IE_CAL_LEN_ERR:1;
            vuint32_t IE_CAL_DIAG_ERR:1;
            vuint32_t IE_NIB_VAL_ERR:1;
            vuint32_t IE_SMSG_CRC_ERR:1;
            vuint32_t IE_FMSG_CRC_ERR:1;
            vuint32_t IE_NUM_EDGES_ERR:1;
            vuint32_t DCHNG_INT:1;
            vuint32_t CAL_RNG:1;
            vuint32_t PP_CHKSEL:1;
            vuint32_t FCRC_TYPE:1;
            vuint32_t FCRC_SC_EN:1;
            vuint32_t SCRC_TYPE:1;
            vuint32_t PAUSE_EN:1;
            vuint32_t SUCC_CAL_CHK:1;
            vuint32_t FIL_CNT:8;
        } B;
    } CH3_CONFIG;

    uint8_t SRX_reserved10[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:1;
            vuint32_t CMPRSC:15;
            vuint32_t COMP_EN:1;
              vuint32_t:1;
            vuint32_t PRSC:14;
        } B;
    } CH4_CLK_CTRL;

    union {
        vuint32_t R;
        struct {
            vuint32_t BUS_IDLE:1;
	    vuint32_t:3;
            vuint32_t CAL_RESYNC:1;
            vuint32_t CAL_20_25:1;
            vuint32_t SMSG_OFLW:1;
            vuint32_t FMSG_OFLW:1;
            vuint32_t:1;
            vuint32_t PP_DIAG_ERR:1;
            vuint32_t CAL_LEN_ERR:1;
            vuint32_t CAL_DIAG_ERR:1;
            vuint32_t NIB_VAL_ERR:1;
            vuint32_t SMSG_CRC_ERR:1;
            vuint32_t FMSG_CRC_ERR:1;
            vuint32_t NUM_EDGES_ERR:1;
              vuint32_t:16;
        } B;
    } CH4_STATUS;

    union {
        vuint32_t R;
        struct {
            vuint32_t BUS_IDLE_CNT:4;
            vuint32_t IE_CAL_RESYNC:1;
            vuint32_t IE_CAL_20_25:1;
            vuint32_t IE_SMSG_OFLW:1;
            vuint32_t IE_FMSG_OFLW:1;
            vuint32_t FCRC_CHK_OFF:1;
            vuint32_t IE_PP_DIAG_ERR:1;
            vuint32_t IE_CAL_LEN_ERR:1;
            vuint32_t IE_CAL_DIAG_ERR:1;
            vuint32_t IE_NIB_VAL_ERR:1;
            vuint32_t IE_SMSG_CRC_ERR:1;
            vuint32_t IE_FMSG_CRC_ERR:1;
            vuint32_t IE_NUM_EDGES_ERR:1;
            vuint32_t DCHNG_INT:1;
            vuint32_t CAL_RNG:1;
            vuint32_t PP_CHKSEL:1;
            vuint32_t FCRC_TYPE:1;
            vuint32_t FCRC_SC_EN:1;
            vuint32_t SCRC_TYPE:1;
            vuint32_t PAUSE_EN:1;
            vuint32_t SUCC_CAL_CHK:1;
            vuint32_t FIL_CNT:8;
        } B;
    } CH4_CONFIG;

    uint8_t SRX_reserved11[180];

    union {
        vuint32_t R;
        struct {
            vuint32_t CHNUM:4;
            vuint32_t SCNIB:4;
            vuint32_t DNIB1:4;
            vuint32_t DNIB2:4;
            vuint32_t DNIB3:4;
            vuint32_t DNIB4:4;
            vuint32_t DNIB5:4;
            vuint32_t DNIB6:4;
        } B;
    } CH0_FMSG_DATA;

    union {
        vuint32_t R;
        struct {
            vuint32_t:12;
            vuint32_t CRC4b:4;
              vuint32_t:16;
        } B;
    } CH0_FMSG_CRC;

    union {
        vuint32_t R;
        struct {
            vuint32_t TS:32;
        } B;
    } CH0_FMSG_TS;

    union {
        vuint32_t R;
        struct {
            vuint32_t CHNUM:4;
            vuint32_t TYPE:1;
            vuint32_t:16;
            vuint32_t CFG:1;
            vuint32_t ID:4;
            vuint32_t:1;
            vuint32_t IDorDATA:4;
            vuint32_t:1;
        } B;
    } CH0_SMSG3;

    union {
        vuint32_t R;
        struct {
            vuint32_t:10;
            vuint32_t SMCRC:6;
              vuint32_t:4;
            vuint32_t DATA:12;
        } B;
    } CH0_SMSG2;

    union {
        vuint32_t R;
        struct {
            vuint32_t TS:32;
        } B;
    } CH0_SMSG_TS;

    union {
        vuint32_t R;
        struct {
            vuint32_t CHNUM:4;
            vuint32_t SCNIB:4;
            vuint32_t DNIB1:4;
            vuint32_t DNIB2:4;
            vuint32_t DNIB3:4;
            vuint32_t DNIB4:4;
            vuint32_t DNIB5:4;
            vuint32_t DNIB6:4;
        } B;
    } CH1_FMSG_DATA;

    union {
        vuint32_t R;
        struct {
            vuint32_t:12;
            vuint32_t CRC4b:4;
              vuint32_t:16;
        } B;
    } CH1_FMSG_CRC;

    union {
        vuint32_t R;
        struct {
            vuint32_t TS:32;
        } B;
    } CH1_FMSG_TS;

    union {
        vuint32_t R;
        struct {
            vuint32_t CHNUM:4;
            vuint32_t TYPE:1;
              vuint32_t:16;
            vuint32_t CFG:1;
            vuint32_t ID:4;
              vuint32_t:1;
            vuint32_t IDorDATA:4;
              vuint32_t:1;
        } B;
    } CH1_SMSG3;

    union {
        vuint32_t R;
        struct {
            vuint32_t:10;
            vuint32_t SMCRC:6;
              vuint32_t:4;
            vuint32_t DATA:12;
        } B;
    } CH1_SMSG2;

    union {
        vuint32_t R;
        struct {
            vuint32_t TS:32;
        } B;
    } CH1_SMSG_TS;

    union {
        vuint32_t R;
        struct {
            vuint32_t CHNUM:4;
            vuint32_t SCNIB:4;
            vuint32_t DNIB1:4;
            vuint32_t DNIB2:4;
            vuint32_t DNIB3:4;
            vuint32_t DNIB4:4;
            vuint32_t DNIB5:4;
            vuint32_t DNIB6:4;
        } B;
    } CH2_FMSG_DATA;

    union {
        vuint32_t R;
        struct {
            vuint32_t:12;
            vuint32_t CRC4b:4;
              vuint32_t:16;
        } B;
    } CH2_FMSG_CRC;

    union {
        vuint32_t R;
        struct {
            vuint32_t TS:32;
        } B;
    } CH2_FMSG_TS;

    union {
        vuint32_t R;
        struct {
            vuint32_t CHNUM:4;
            vuint32_t TYPE:1;
              vuint32_t:16;
            vuint32_t CFG:1;
            vuint32_t ID:4;
              vuint32_t:1;
            vuint32_t IDorDATA:4;
              vuint32_t:1;
        } B;
    } CH2_SMSG3;

    union {
        vuint32_t R;
        struct {
            vuint32_t:10;
            vuint32_t SMCRC:6;
              vuint32_t:4;
            vuint32_t DATA:12;
        } B;
    } CH2_SMSG2;

    union {
        vuint32_t R;
        struct {
            vuint32_t TS:32;
        } B;
    } CH2_SMSG_TS;

    union {
        vuint32_t R;
        struct {
            vuint32_t CHNUM:4;
            vuint32_t SCNIB:4;
            vuint32_t DNIB1:4;
            vuint32_t DNIB2:4;
            vuint32_t DNIB3:4;
            vuint32_t DNIB4:4;
            vuint32_t DNIB5:4;
            vuint32_t DNIB6:4;
        } B;
    } CH3_FMSG_DATA;

    union {
        vuint32_t R;
        struct {
            vuint32_t:12;
            vuint32_t CRC4b:4;
              vuint32_t:16;
        } B;
    } CH3_FMSG_CRC;

    union {
        vuint32_t R;
        struct {
            vuint32_t TS:32;
        } B;
    } CH3_FMSG_TS;

    union {
        vuint32_t R;
        struct {
            vuint32_t CHNUM:4;
            vuint32_t TYPE:1;
              vuint32_t:16;
            vuint32_t CFG:1;
            vuint32_t ID:4;
              vuint32_t:1;
            vuint32_t IDorDATA:4;
              vuint32_t:1;
        } B;
    } CH3_SMSG3;

    union {
        vuint32_t R;
        struct {
            vuint32_t:10;
            vuint32_t SMCRC:6;
              vuint32_t:4;
            vuint32_t DATA:12;
        } B;
    } CH3_SMSG2;

    union {
        vuint32_t R;
        struct {
            vuint32_t TS:32;
        } B;
    } CH3_SMSG_TS;

    union {
        vuint32_t R;
        struct {
            vuint32_t CHNUM:4;
            vuint32_t SCNIB:4;
            vuint32_t DNIB1:4;
            vuint32_t DNIB2:4;
            vuint32_t DNIB3:4;
            vuint32_t DNIB4:4;
            vuint32_t DNIB5:4;
            vuint32_t DNIB6:4;
        } B;
    } CH4_FMSG_DATA;

    union {
        vuint32_t R;
        struct {
            vuint32_t:12;
            vuint32_t CRC4b:4;
              vuint32_t:16;
        } B;
    } CH4_FMSG_CRC;

    union {
        vuint32_t R;
        struct {
            vuint32_t TS:32;
        } B;
    } CH4_FMSG_TS;

    union {
        vuint32_t R;
        struct {
            vuint32_t CHNUM:4;
            vuint32_t TYPE:1;
              vuint32_t:16;
            vuint32_t CFG:1;
            vuint32_t ID:4;
              vuint32_t:1;
            vuint32_t IDorDATA:4;
              vuint32_t:1;
        } B;
    } CH4_SMSG3;

    union {
        vuint32_t R;
        struct {
            vuint32_t:10;
            vuint32_t SMCRC:6;
              vuint32_t:4;
            vuint32_t DATA:12;
        } B;
    } CH4_SMSG2;

    union {
        vuint32_t R;
        struct {
            vuint32_t TS:32;
        } B;
    } CH4_SMSG_TS;
};
/**************************************************************************/
/*                   Module: SSCM                                         */
/**************************************************************************/
struct SSCM_tag {
    union {
        vuint16_t R;
        struct {
            vuint16_t:1;
            vuint16_t CER:1;
              vuint16_t:1;
            vuint16_t NXEN1:1;
            vuint16_t NXEN:1;
              vuint16_t:3;
            vuint16_t BMODE:3;
            vuint16_t VLE:1;
              vuint16_t:4;
        } B;
    } STATUS;

    union {
        vuint16_t R;
        struct {
            vuint16_t JPIN:10;
              vuint16_t:1;
            vuint16_t MREV:4;
              vuint16_t:1;
        } B;
    } MEMCONFIG;

    uint8_t SSCM_reserved1[2];

    union {
        vuint16_t R;
        struct {
            vuint16_t:14;
            vuint16_t PAE:1;
            vuint16_t RAE:1;
        } B;
    } ERROR;


    uint8_t SSCM_reserved2[32];

    union {
        vuint32_t R;
        struct {
            vuint32_t SADR:32;
        } B;
    } PSA;

    uint8_t SSCM_reserved4[8];

    union {
        vuint32_t R;
        struct {
	    vuint32_t:22;
            vuint32_t PLC:2;
	    vuint32_t:5;
            vuint32_t LC:3;
        } B;
    } LCSTAT;
};

/**************************************************************************/
/*                   Module: STM                                          */
/**************************************************************************/
struct STM_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t CPS:8;
              vuint32_t:6;
            vuint32_t FRZ:1;
            vuint32_t TEN:1;
        } B;
    } CR;

    union {
        vuint32_t R;
        struct {
            vuint32_t CNT:32;
        } B;
    } CNT;

    uint8_t STM_reserved1[8];

    struct {
        union {
            vuint32_t R;
            struct {
                vuint32_t:31;
                vuint32_t CEN:1;
            } B;
        } CCR;

        union {
            vuint32_t R;
            struct {
                vuint32_t:31;
                vuint32_t CIF:1;
            } B;
        } CIR;

        union {
            vuint32_t R;
            struct {
                vuint32_t CMP:32;
            } B;
        } CMP;

        uint8_t Channel_reserved[4];

    } Channel[4];
};
/**************************************************************************/
/*                   Module: SWT                                          */
/**************************************************************************/
struct SWT_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t MAP0:1;
            vuint32_t MAP1:1;
            vuint32_t MAP2:1;
            vuint32_t MAP3:1;
            vuint32_t MAP4:1;
            vuint32_t MAP5:1;
            vuint32_t MAP6:1;
            vuint32_t MAP7:1;
              vuint32_t:13;
            vuint32_t SMD:2;
            vuint32_t RIA:1;
            vuint32_t WND:1;
            vuint32_t ITR:1;
            vuint32_t HLK:1;
            vuint32_t SLK:1;
            vuint32_t :1;
            vuint32_t STP:1;
            vuint32_t FRZ:1;
            vuint32_t WEN:1;
        } B;
    } CR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:31;
            vuint32_t TIF:1;
        } B;
    } IR;

    union {
        vuint32_t R;
        struct {
            vuint32_t WTO:32;
        } B;
    } TO;

    union {
        vuint32_t R;
        struct {
            vuint32_t WST:32;
        } B;
    } WN;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t WSC:16;
        } B;
    } SR;

    union {
        vuint32_t R;
        struct {
            vuint32_t CNT:32;
        } B;
    } CO;

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t SK:16;
        } B;
    } SK;
};

/**************************************************************************/
/*                   Module: WKPU                                        */
/**************************************************************************/
struct WKPU_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t NIF2:1;
            vuint32_t NOVF2:1;
            vuint32_t:6;
            vuint32_t RIF:1;
            vuint32_t ROVF:1;
            vuint32_t:6;
        } B;
    } NSR;

    uint8_t WKPU_reserved1[4];

    union {
        vuint32_t R;
        struct {
            vuint32_t:16;
            vuint32_t NLOCK2:1;
            vuint32_t NDSS2:2;
            vuint32_t NWRE2:1;
            vuint32_t:1;
            vuint32_t NREE2:1;
            vuint32_t NFEE2:1;
            vuint32_t:1;
            vuint32_t RLOCK:1;
            vuint32_t RDSS:2;
            vuint32_t RWRE:1;
            vuint32_t:1;
            vuint32_t RREE:1;
            vuint32_t RFEE:1;
            vuint32_t:1;
        } B;
    } NCR;

    
    uint8_t WKPU_reserved3[8];

    union {
        vuint32_t R;
        struct {
            vuint32_t:13;
            vuint32_t EIF18:1;
            vuint32_t EIF17:1;
            vuint32_t:2;
            vuint32_t EIF:11;
            vuint32_t:4;
        } B;
    } WISR;

    union {
        vuint32_t R;
        struct {
            vuint32_t:13;
            vuint32_t EIRE18:1;
            vuint32_t EIRE17:1;
            vuint32_t:2;
            vuint32_t EIRE:11;
            vuint32_t:4;
        } B;
    } IRER;
    uint8_t WKPU_reserved4[12];

    union {
        vuint32_t R;
        struct {
            vuint32_t:13;
            vuint32_t IREE18:1;
            vuint32_t IREE17:1;
            vuint32_t:2;
            vuint32_t IREE:11;
            vuint32_t:4;
        } B;
    } WIREER;

    union {
        vuint32_t R;
        struct {
            vuint32_t:13;
            vuint32_t IFEE18:1;
            vuint32_t IFEE17:1;
            vuint32_t:2;
            vuint32_t IFEE:11;
            vuint32_t:4;
        } B;
    } WIFEER;
};
/**************************************************************************/
/*                   Module: XBAR                                         */
/**************************************************************************/
struct XBAR_tag {
    struct {
        union {
            vuint32_t R;
            struct {
                vuint32_t:20;
	        vuint32_t:1;
                vuint32_t M2:3;
                vuint32_t:1;
                vuint32_t M1:3;
                vuint32_t:1;
                vuint32_t M0:3;
            } B;
        } PRS;

        uint8_t Channel_reserved1[12];

        union {
            vuint32_t R;
            struct {
                vuint32_t RO:1;
                vuint32_t HRP:1;
                vuint32_t:11;
		vuint32_t HPE2:1;
		vuint32_t HPE1:1;
		vuint32_t HPE0:1;
		vuint32_t:6;
                vuint32_t ARB:2;
                vuint32_t:2;
                vuint32_t PCTL:2;
                vuint32_t:1;
                vuint32_t PARK:3;
            } B;
        } CRS;

        uint8_t Channel_reserved2[236];
    } CHANNEL[3];
};

/**************************************************************************/
/*                   Module: XOSC                                         */
/**************************************************************************/
struct XOSC_tag {
    union {
        vuint32_t R;
        struct {
            vuint32_t OSCBYP:1;
              vuint32_t:7;
            vuint32_t EOCV:8;
            vuint32_t M_OSC:1;
              vuint32_t:7;
            vuint32_t I_OSC:1;
              vuint32_t:7;
        } B;
    } XOSC_CTL;
};

/****************************************************************************/
/*                     MODULE : Decimation Filter (DECFILTER)                  */
/****************************************************************************/
    struct DECFILTER_tag {
        union {
            vuint32_t R;
            struct {
                vuint32_t MDIS:1;
                vuint32_t FREN:1;
                vuint32_t:1;
                vuint32_t FRZ:1;
                vuint32_t SRES:1;
                vuint32_t :2;
                vuint32_t IDEN:1;
                vuint32_t ODEN:1;
                vuint32_t ERREN:1;
                vuint32_t:1;
                vuint32_t FTYPE:2;
                vuint32_t:1;
                vuint32_t SCAL:2;
                vuint32_t IDIS:1;
                vuint32_t SAT:1;
                vuint32_t ISEL:1;
                vuint32_t:1;
                vuint32_t DEC_RATE:4;
                vuint32_t SDIE:1;
                vuint32_t DSEL:1;
                vuint32_t IBIE:1;
                vuint32_t OBIE:1;
                vuint32_t :4;
            } B;
        } MCR;                  /* Configuration Register @baseaddress + 0x00 */

        union {
            vuint32_t R;
            struct {
                vuint32_t BSY:1;
                vuint32_t:1;
                vuint32_t DEC_COUNTER:4;
                vuint32_t IDFC:1;
                vuint32_t ODFC:1;
                vuint32_t:1;
                vuint32_t IBIC:1;
                vuint32_t OBIC:1;
                vuint32_t:2;
                vuint32_t OVFC:1;
                vuint32_t OVRC:1;
                vuint32_t IVRC:1;
                vuint32_t:6;
                vuint32_t IDF:1;
                vuint32_t ODF:1;
                vuint32_t:1;
                vuint32_t IBIF:1;
                vuint32_t OBIF:1;
                vuint32_t:2;
                vuint32_t OVF:1;
                vuint32_t OVR:1;
                vuint32_t IVR:1;
            } B;
        } MSR;                  /* Status Register @baseaddress + 0x04 */

        union {
            vuint32_t R;
            struct {
                vuint32_t SDMAE:1;
                vuint32_t SSIG:1;
                vuint32_t SSAT:1;
                vuint32_t SCSAT:1;
		vuint32_t :10;
                vuint32_t SRQ:1;
		vuint32_t SZRO:1;
		vuint32_t SISEL:1;
                vuint32_t :1;
		vuint32_t SZROSEL:2;
		vuint32_t :2;
		vuint32_t SHLTSEL:2;
                vuint32_t :1;
		vuint32_t SRQSEL:3;
		vuint32_t :2;
		vuint32_t SENSEL:2;
            } B;
        } MXCR;

	union {
            vuint32_t R;
            struct {
                vuint32_t :7;
                vuint32_t SDFC:1;
                vuint32_t :2;
                vuint32_t SSEC:1;
		vuint32_t SCEC:1;
                vuint32_t :1;
		vuint32_t SSOVFC:1;
		vuint32_t SCOVFC:1;
                vuint32_t SVRC:1;
		vuint32_t :7;
		vuint32_t SDF:1;
                vuint32_t :2;
		vuint32_t SSE:1;
	        vuint32_t SCE:1;
		vuint32_t :1;
	        vuint32_t SSOVF:1;
	        vuint32_t SCOVF:1;
		vuint32_t SVR:1;

            } B;
        } MXSR; 

        union {
            vuint32_t R;
            struct {
                vuint32_t:4;
                vuint32_t INTAG:4;
                vuint32_t:6;
                vuint32_t PREFILL:1;
                vuint32_t FLUSH:1;
                vuint32_t INPBUF:16;
            } B;
        } IB;                   /* Interface Input Buffer @baseaddress + 0x10  */

        union {
            vuint32_t R;
            struct {
                vuint32_t:12;
                vuint32_t OUTTAG:4;
                vuint32_t OUTBUF:16;
            } B;
        } OB;                   /* Interface Output Buffer @baseaddress + 0x14  */

        uint32_t decfil_reserved0018[2];        /* 0x0018 - 0x001F */

        union {
            vuint32_t R;
            struct {
                vuint32_t:8;
                vuint32_t COEF:24;
            } B;
        } COEF[9];              /* Filter Coefficient Registers @baseaddress + 0x20 - 0x40  */

        uint32_t decfil_reserved0044[13];       /* 0x0044 - 0x0077 */

        union {
            vuint32_t R;
            struct {
                vuint32_t:8;
                vuint32_t TAP:24;
            } B;
        } TAP[8];               /* Filter TAP Registers @baseaddress + 0x78 - 0x94 */

        uint32_t decfil_reserved00D0[18];       /* 0x00D0 - 0x00D3 */

	union {
            vuint32_t R;
            struct {
                vuint32_t:12;
                vuint32_t OUTTAG:4;
                vuint32_t OUTBUF:16;
            } B;
        } FINTVAL;

	union {
            vuint32_t R;
            struct {
                vuint32_t:12;
                vuint32_t OUTTAG:4;
                vuint32_t OUTBUF:16;
            } B;
        } FINTCNT;
	
        union {
            vuint32_t R;
            struct {
                vuint32_t:12;
                vuint32_t OUTTAG:4;
                vuint32_t OUTBUF:16;
            } B;
        } CINTVAL;

	union {
            vuint32_t R;
            struct {
                vuint32_t:12;
                vuint32_t OUTTAG:4;
                vuint32_t OUTBUF:16;
            } B;
        } CINTCNT; 


};
    
/* Define memories */ 
#define SRAM0_START   0x40000000UL
#define SRAM0_SIZE    0x10000UL
#define SRAM0_END     0x401FFFFFUL
    
#define FLASH_START          0x0UL
#define FLASH_SIZE    0x10000000UL
#define FLASH_END     0x0FFFFFFFUL
    
    
/* Define instances of modules PBRIDGE_A */ 
#define PBRIDGE_A     (*(volatile struct PBRIDGE_tag *)   0xFC000000UL)
#define XBAR_0        (*(volatile struct XBAR_tag *)      0xFC004000UL)
#define SMPU_0        (*(volatile struct SMPU_tag *)      0xFC010000UL)
#define PRAM          (*(volatile struct PRAM_tag *)      0xFC020000UL)
#define PCM           (*(volatile struct PCM_tag *)       0xFC028000UL)
#define PFLASH        (*(volatile struct PFLASH_tag *)    0xFC030000UL)
#define INTC          (*(volatile struct INTC_tag *)      0xFC040000UL)
#define SWT_2         (*(volatile struct SWT_tag *)       0xFC058000UL)
#define SWT_3         (*(volatile struct SWT_tag *)       0xFC05C000UL)
#define STM_2         (*(volatile struct STM_tag *)       0xFC070000UL)
#define DMA_0         (*(volatile struct DMA_tag *)       0xFC0A0000UL)
#define FEC           (*(volatile struct FEC_tag *)       0xFC0B0000UL)
#define EIM           (*(volatile struct EIM_tag *)       0xFC0DC000UL)
#define ERM           (*(volatile struct ERM_tag *)       0xFC0E0000UL)
#define GTMINT        (*(volatile struct GTMINT_tag *)    0xFFD00000UL)
#define SARADC_0      (*(volatile struct SARADC_tag *)    0xFFE00000UL)
#define SARADC_4      (*(volatile struct SARADC_tag *)    0xFFE10000UL)
#define SARADC_B      (*(volatile struct SARADC_tag *)    0xFFE3C000UL)
#define SRX_0         (*(volatile struct SRX_tag *)       0xFFE5C000UL)
#define DSPI_0        (*(volatile struct DSPI_tag *)      0xFFE70000UL)
#define DSPI_4        (*(volatile struct DSPI_tag *)      0xFFE78000UL)
#define LINFlexD_0    (*(volatile struct LINFlexD_tag *)  0xFFE8C000UL)
#define LINFlexD_1    (*(volatile struct LINFlexD_tag *)  0xFFE90000UL)
#define LINFlexD_14   (*(volatile struct LINFlexD_tag *)  0xFFEA8000UL)
//#define CANRAM      0xFFED4000UL
#define MCAN_1        (*(volatile struct MCAN_tag *)      0xFFEE4000UL)
#define MCAN_2        (*(volatile struct MCAN_tag *)      0xFFEE8000UL)
#define CCCU          (*(volatile struct CCCU_tag *)      0xFFF04000UL)
#define SDADC_3       (*(volatile struct SDADC_tag *)     0xFFF10000UL)
#define DTS           (*(volatile struct DTS_tag *)       0xFFF38000UL)
#define JDC           (*(volatile struct JDC_tag *)       0xFFF3C000UL)
#define JTAGM         (*(volatile struct JTAGM_tag *)     0xFFF48000UL)
#define DMAMUX_0      (*(volatile struct DMACHMUX_tag *)  0xFFF6C000UL)
#define DMAMUX_1      (*(volatile struct DMACHMUX_tag *)  0xFFF6C200UL)
#define PIT_1         (*(volatile struct PIT_tag *)       0xFFF80000UL)
#define PIT_0         (*(volatile struct PIT_tag *)       0xFFF84000UL)
#define DECFILTER     (*(volatile struct DECFILTER_tag *) 0xFFF88000UL)
#define WKPU          (*(volatile struct WKPU_tag *)      0xFFF98000UL)
//define BAR          0xFFFFC000
#define MC_PCU        (*(volatile struct MC_PCU_tag *)    0xFFFA0000UL)
#define PMCDIG        (*(volatile struct PMCDIG_tag *)    0xFFFA0400UL)  
#define MC_RGM        (*(volatile struct MC_RGM_tag *)    0xFFFA8000UL)
#define RCOSC         (*(volatile struct RCOSC_tag *)     0xFFFB0000UL)
#define XOSC          (*(volatile struct XOSC_tag *)      0xFFFB0080UL)
#define PLLDIG        (*(volatile struct PLLDIG_tag *)    0xFFFB0100UL)
#define CMU_PLL       (*(volatile struct CMU_tag *)       0xFFFB0200UL)
#define MC_CGM        (*(volatile struct MC_CGM_tag *)    0xFFFB0700UL)
#define MC_ME         (*(volatile struct MC_ME_tag *)     0xFFFB8000UL)
#define SIUL2         (*(volatile struct SIUL2_tag *)     0xFFFC0000UL)
#define SIPI_0        (*(volatile struct SIPI_tag *)      0xFFFD0000UL)
#define LFAST_0       (*(volatile struct LFAST_tag *)     0xFFFD8000UL)
#define FLASH         (*(volatile struct FLASH_tag *)     0xFFFE0000UL) 
#define PASS          (*(volatile struct PASS_tag *)      0xFFFF4000UL)
#define SSCM          (*(volatile struct SSCM_tag *)      0xFFFF8000UL)
    
#ifdef __MWERKS__
#pragma pop
#endif  /* 
 */
    
#ifdef  __cplusplus
} 
#endif  /* 
 */
    
#endif /* ifdef _SPC5726_L_H */
