/****************************************************************************
*
* Copyright © 2017-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY – NOT FOR USE IN PRODUCTION
*****************************************************************************/

/**
 * @file    spc5726l_registry.h
 * @brief   SPC5726L capabilities registry.
 *
 * @addtogroup PLATFORM
 * @{
 */

#ifndef _SPC5726L_REGISTRY_H_
#define _SPC5726L_REGISTRY_H_

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Platform capabilities.                                                    */
/*===========================================================================*/

/**
 * @name    SPC572L64x capabilities
 * @{
 */
/* eDMA attributes.*/
#define SPC5_HAS_EDMA                       TRUE
#define SPC5_HAS_EDMA0                      FALSE
#define SPC5_HAS_EDMA1                      TRUE
#define SPC5_EDMA_DMA1_BASE                 0xFC0A0000UL
#define SPC5_EDMA_NCHANNELS                 16U
#define SPC5_EDMA_COMBO_CH_ERR_HANDLER      vector52
#define SPC5_EDMA_CH0_HANDLER               vector53
#define SPC5_EDMA_CH1_HANDLER               vector54
#define SPC5_EDMA_CH2_HANDLER               vector55
#define SPC5_EDMA_CH3_HANDLER               vector56
#define SPC5_EDMA_CH4_HANDLER               vector57
#define SPC5_EDMA_CH5_HANDLER               vector58
#define SPC5_EDMA_CH6_HANDLER               vector59
#define SPC5_EDMA_CH7_HANDLER               vector60
#define SPC5_EDMA_CH8_HANDLER               vector61
#define SPC5_EDMA_CH9_HANDLER               vector62
#define SPC5_EDMA_CH10_HANDLER              vector63
#define SPC5_EDMA_CH11_HANDLER              vector64
#define SPC5_EDMA_CH12_HANDLER              vector65
#define SPC5_EDMA_CH13_HANDLER              vector66
#define SPC5_EDMA_CH14_HANDLER              vector67
#define SPC5_EDMA_CH15_HANDLER              vector68
#define SPC5_EDMA_COMBO_CH_ERR_NUMBER       52U
#define SPC5_EDMA_CH0_NUMBER                53U
#define SPC5_EDMA_HAS_MUX                   TRUE
#define SPC5_EDMA_NUM_OF_MUX                2U
#define SPC5_EDMA_MUX0_BASE                 0xFFF6C000UL
#define SPC5_EDMA_MUX0_CH_NUM               8U
#define SPC5_EDMA_MUX1_BASE                 0xFFF6C200UL
#define SPC5_EDMA_MUX1_CH_NUM               8U
#define SPC5_EDMA_MUX0_PCTL                 36

/* DSPI attributes.*/
#define SPC5_HAS_DSPI0                      TRUE
#define SPC5_DSPI0_BASE                     0xFFE70000UL
#define SPC5_HAS_DSPI1                      FALSE
#define SPC5_HAS_DSPI2                      FALSE
#define SPC5_HAS_DSPI3                      FALSE
#define SPC5_HAS_DSPI4                      TRUE
#define SPC5_DSPI4_BASE                     0xFFE78000UL
#define SPC5_HAS_DSPI5                      FALSE
#define SPC5_HAS_DSPI6                      FALSE
#define SPC5_HAS_DSPI7                      FALSE
#define SPC5_HAS_DSPI8                      FALSE
#define SPC5_HAS_DSPI9                      FALSE
#define SPC5_DSPI_FIFO_DEPTH                4U
#define SPC5_DSPI0_EOQF_HANDLER             vector260
#define SPC5_DSPI0_EOQF_NUMBER              260
#define SPC5_DSPI0_TFFF_HANDLER             vector261
#define SPC5_DSPI0_TFFF_NUMBER              261
#define SPC5_DSPI0_RFDF_HANDLER             vector263
#define SPC5_DSPI0_RFDF_NUMBER              263
#define SPC5_DSPI4_EOQF_HANDLER             vector296
#define SPC5_DSPI4_EOQF_NUMBER              296
#define SPC5_DSPI4_TFFF_HANDLER             vector297
#define SPC5_DSPI4_TFFF_NUMBER              297
#define SPC5_DSPI4_RFDF_HANDLER             vector299
#define SPC5_DSPI4_RFDF_NUMBER              299
#define SPC5_DSPI0_PCTL                     99
#define SPC5_DSPI4_PCTL                     97

#define SPC5_DSPI0_TX1_DMA_DEV_ID           0
#define SPC5_DSPI0_TX2_DMA_DEV_ID           0
#define SPC5_DSPI0_RX_DMA_DEV_ID            0

#define SPC5_DSPI4_TX1_DMA_DEV_ID           0
#define SPC5_DSPI4_TX2_DMA_DEV_ID           0
#define SPC5_DSPI4_RX_DMA_DEV_ID            0
#define SPC5_DSPI0_ENABLE_CLOCK()                                           \
  SPCSetPeripheralClockMode(SPC5_DSPI0_PCTL, SPC5_SPI_DSPI0_START_PCTL)
#define SPC5_DSPI0_DISABLE_CLOCK()                                          \
  SPCSetPeripheralClockMode(SPC5_DSPI0_PCTL, SPC5_SPI_DSPI0_STOP_PCTL)
#define SPC5_DSPI4_ENABLE_CLOCK()                                           \
  SPCSetPeripheralClockMode(SPC5_DSPI4_PCTL, SPC5_SPI_DSPI4_START_PCTL)
#define SPC5_DSPI4_DISABLE_CLOCK()                                          \
  SPCSetPeripheralClockMode(SPC5_DSPI4_PCTL, SPC5_SPI_DSPI4_STOP_PCTL)

/* LINFlex attributes.*/
#define SPC5_HAS_LINFLEX0                   TRUE
#define SPC5_LINFLEX0_BASE                  0xFFE8C000UL
#define SPC5_LINFLEX0L_BASE                 0xFFE8C000UL
#define SPC5_LINFLEX0H_BASE                 0xFFE8C08CUL
#define SPC5_LINFLEX0_PCTL                  92
#define SPC5_LINFLEX0_RXI_HANDLER           vector376
#define SPC5_LINFLEX0_TXI_HANDLER           vector377
#define SPC5_LINFLEX0_ERR_HANDLER           vector378
#define SPC5_LINFLEX0_RXI_NUMBER            376
#define SPC5_LINFLEX0_TXI_NUMBER            377
#define SPC5_LINFLEX0_ERR_NUMBER            378
#define SPC5_LINFLEX0_DMA_SUPPORTED         TRUE
#define SPC5_LINFLEX0_RX_DMA_MUX0_DEV_ID    16
#define SPC5_LINFLEX0_RX_DMA_MUX1_DEV_ID    3
#define SPC5_LINFLEX0_TX_DMA_MUX0_DEV_ID    17
#define SPC5_LINFLEX0_TX_DMA_MUX1_DEV_ID    4
#define SPC5_LINFLEX0_CLK                   SPC5_LIN_CLK

#define SPC5_HAS_LINFLEX1                   TRUE
#define SPC5_LINFLEX1_PCTL                  91
#define SPC5_LINFLEX1_BASE                  0xFFE90000UL
#define SPC5_LINFLEX1L_BASE                 0xFFE90000UL
#define SPC5_LINFLEX1H_BASE                 0xFFE9004CUL
#define SPC5_LINFLEX1_RXI_HANDLER           vector380
#define SPC5_LINFLEX1_TXI_HANDLER           vector381
#define SPC5_LINFLEX1_ERR_HANDLER           vector382
#define SPC5_LINFLEX1_RXI_NUMBER            380
#define SPC5_LINFLEX1_TXI_NUMBER            381
#define SPC5_LINFLEX1_ERR_NUMBER            382
#define SPC5_LINFLEX1_DMA_SUPPORTED         TRUE
#define SPC5_LINFLEX1_RX_DMA_MUX1_DEV_ID    5
#define SPC5_LINFLEX1_TX_DMA_MUX1_DEV_ID    6
#define SPC5_LINFLEX1_CLK                   SPC5_LIN_CLK

#define SPC5_HAS_LINFLEX14                  TRUE
#define SPC5_LINFLEX14_PCTL                 85
#define SPC5_LINFLEX14_BASE                 0xFFEA8000UL
#define SPC5_LINFLEX14L_BASE                0xFFEA8000UL
#define SPC5_LINFLEX14H_BASE                0xFFEA804CUL
#define SPC5_LINFLEX14_RXI_HANDLER          vector432
#define SPC5_LINFLEX14_TXI_HANDLER          vector433
#define SPC5_LINFLEX14_ERR_HANDLER          vector434
#define SPC5_LINFLEX14_RXI_NUMBER           432
#define SPC5_LINFLEX14_TXI_NUMBER           433
#define SPC5_LINFLEX14_ERR_NUMBER           434
#define SPC5_LINFLEX14_DMA_SUPPORTED        TRUE
#define SPC5_LINFLEX14_RX_DMA_MUX0_DEV_ID   18
#define SPC5_LINFLEX14_RX_DMA_MUX1_DEV_ID   7
#define SPC5_LINFLEX14_TX_DMA_MUX1_DEV_ID   8
#define SPC5_LINFLEX14_CLK                  SPC5_LIN_CLK

#define SPC5_HAS_LINFLEX2                   FALSE
#define SPC5_HAS_LINFLEX3                   FALSE
#define SPC5_HAS_LINFLEX4                   FALSE
#define SPC5_HAS_LINFLEX5                   FALSE
#define SPC5_HAS_LINFLEX6                   FALSE
#define SPC5_HAS_LINFLEX7                   FALSE
#define SPC5_HAS_LINFLEX8                   FALSE
#define SPC5_HAS_LINFLEX9                   FALSE
#define SPC5_HAS_LINFLEX10                  FALSE
#define SPC5_HAS_LINFLEX11                  FALSE
#define SPC5_HAS_LINFLEX12                  FALSE
#define SPC5_HAS_LINFLEX13                  FALSE
#define SPC5_HAS_LINFLEX15                  FALSE
#define SPC5_HAS_LINFLEX16                  FALSE
#define SPC5_HAS_LINFLEX17                  FALSE
#define SPC5_HAS_LINFLEX18                  FALSE
#define SPC5_HAS_LINFLEX19                  FALSE
#define SPC5_HAS_LINFLEX20                  FALSE
#define SPC5_HAS_LINFLEX21                  FALSE
#define SPC5_HAS_LINFLEX22                  FALSE
#define SPC5_HAS_LINFLEX23                  FALSE

/* SIUL2 attributes.*/
#define SPC5_HAS_SIUL2                      TRUE
#define SPC5_HAS_SIUL_PARALLEL_PORT_REG     TRUE
#define SPC5_SIUL2_NUM_PORTS                7
#define SPC5_SIUL2_NUM_MUXES                85

/* PIT Attributes */
#define SPC5_HAS_PIT0                       TRUE
#define SPC5_PIT0_BASE                      0xFFF84000UL
#define SPC5_PIT0_CHANNELS                  4
#define SPC5_PIT0_PCTL                      30
#define SPC5_PIT0_ENABLE_CLOCK()            SPCSetPeripheralClockMode(SPC5_PIT0_PCTL, SPC5_PIT0_START_PCTL);
#define SPC5_PIT0_DISABLE_CLOCK()           SPCSetPeripheralClockMode(SPC5_PIT0_PCTL, SPC5_PIT0_STOP_PCTL);
#define SPC5_HAS_PIT0_CH0                   TRUE
#define SPC5_HAS_PIT0_CH1                   TRUE
#define SPC5_HAS_PIT0_CH2                   TRUE
#define SPC5_HAS_PIT0_CH3                   TRUE
#define SPC5_PIT0_CH0_HANDLER               vector226
#define SPC5_PIT0_CH1_HANDLER               vector227
#define SPC5_PIT0_CH2_HANDLER               vector228
#define SPC5_PIT0_CH3_HANDLER               vector229
#define SPC5_PIT0_CH0_INT_NUMBER            226
#define SPC5_PIT0_CH1_INT_NUMBER            227
#define SPC5_PIT0_CH2_INT_NUMBER            228
#define SPC5_PIT0_CH3_INT_NUMBER            229

#define SPC5_HAS_PIT0_CH4                   FALSE
#define SPC5_HAS_PIT0_CH5                   FALSE
#define SPC5_HAS_PIT0_CH6                   FALSE
#define SPC5_HAS_PIT0_CH7                   FALSE


#define SPC5_HAS_PIT1                       TRUE
#define SPC5_PIT1_BASE                      0xFFF80000UL
#define SPC5_PIT1_CHANNELS                  2
#define SPC5_PIT1_PCTL                      31
#define SPC5_PIT1_ENABLE_CLOCK()            SPCSetPeripheralClockMode(SPC5_PIT1_PCTL, SPC5_PIT1_START_PCTL);
#define SPC5_PIT1_DISABLE_CLOCK()           SPCSetPeripheralClockMode(SPC5_PIT1_PCTL, SPC5_PIT1_STOP_PCTL);
#define SPC5_HAS_PIT1_CH0                   TRUE
#define SPC5_HAS_PIT1_CH1                   TRUE
#define SPC5_PIT1_CH0_HANDLER               vector240
#define SPC5_PIT1_CH1_HANDLER               vector241
#define SPC5_PIT1_CH0_INT_NUMBER            240
#define SPC5_PIT1_CH1_INT_NUMBER            241

#define SPC5_HAS_PIT1_CH2                   FALSE
#define SPC5_HAS_PIT1_CH3                   FALSE
#define SPC5_HAS_PIT1_CH4                   FALSE
#define SPC5_HAS_PIT1_CH5                   FALSE
#define SPC5_HAS_PIT1_CH6                   FALSE
#define SPC5_HAS_PIT1_CH7                   FALSE

/* STM Attributes */
#define SPC5_HAS_STM0                       FALSE
#define SPC5_HAS_STM1                       FALSE
#define SPC5_HAS_STM2                       TRUE
#define SPC5_STM2_BASE                      0xFC070000UL
#define SPC5_STM2_CHANNELS                  4
#define SPC5_HAS_STM2_CH0                   TRUE
#define SPC5_HAS_STM2_CH1                   TRUE
#define SPC5_HAS_STM2_CH2                   TRUE
#define SPC5_HAS_STM2_CH3                   TRUE
#define SPC5_STM0_CH1_CH3_SHARED_INT        FALSE
#define SPC5_STM2_CH0_HANDLER               vector44
#define SPC5_STM2_CH1_HANDLER               vector45
#define SPC5_STM2_CH2_HANDLER               vector46
#define SPC5_STM2_CH3_HANDLER               vector47
#define SPC5_STM2_CH0_INT_NUMBER            44
#define SPC5_STM2_CH1_INT_NUMBER            45
#define SPC5_STM2_CH2_INT_NUMBER            46
#define SPC5_STM2_CH3_INT_NUMBER            47

/* SWT Attributes */
#define SPC5_HAS_SWT0                       FALSE
#define SPC5_HAS_SWT1                       FALSE

#define SPC5_HAS_SWT2                       TRUE
#define SPC5_SWT2_BASE                      0xFC058000UL
#define SPC5_SWT2_HANDLER                   vector34
#define SPC5_SWT2_INT_NUMBER                34

#define SPC5_HAS_SWT3                       TRUE
#define SPC5_SWT3_BASE                      0xFC05C000UL
#define SPC5_SWT3_HANDLER                   vector35
#define SPC5_SWT3_INT_NUMBER                35

/* GTM Attributes */
#define SPC5_HAS_GTM                        TRUE
#define SPC5_GTMINT_PCTL                    128

/* CAN SUBSYSTEM 0 */
#define SPC5_HAS_CAN_SUB_0_M_CAN_0             FALSE
 
#define SPC5_HAS_CAN_SUB_0_M_CAN_1             TRUE
#define SPC5_CAN_SUB_0_M_CAN_1_PTCL            70
#define SPC5_CAN_SUB_0_M_CAN_1_ENABLE_CLOCK()  SPCSetPeripheralClockMode(SPC5_CAN_SUB_0_M_CAN_1_PTCL, SPC5_CAN_SUB_0_M_CAN_1_START_PTCL);
#define SPC5_CAN_SUB_0_M_CAN_1_DISABLE_CLOCK() SPCSetPeripheralClockMode(SPC5_CAN_SUB_0_M_CAN_1_PTCL, SPC5_CAN_SUB_0_M_CAN_1_STOP_PTCL);
#define SPC5_CAN_SUB_0_M_CAN_1_L0_HANDLER      vector688
#define SPC5_CAN_SUB_0_M_CAN_1_L1_HANDLER      vector689
#define SPC5_CAN_SUB_0_M_CAN_1_L0_NUMBER       688
#define SPC5_CAN_SUB_0_M_CAN_1_L1_NUMBER       689
                                              
#define SPC5_HAS_CAN_SUB_0_M_CAN_2             TRUE
#define SPC5_CAN_SUB_0_M_CAN_2_PTCL            69
#define SPC5_CAN_SUB_0_M_CAN_2_ENABLE_CLOCK()  SPCSetPeripheralClockMode(SPC5_CAN_SUB_0_M_CAN_2_PTCL, SPC5_CAN_SUB_0_M_CAN_2_START_PTCL);
#define SPC5_CAN_SUB_0_M_CAN_2_DISABLE_CLOCK() SPCSetPeripheralClockMode(SPC5_CAN_SUB_0_M_CAN_2_PTCL, SPC5_CAN_SUB_0_M_CAN_2_STOP_PTCL);
#define SPC5_CAN_SUB_0_M_CAN_2_L0_HANDLER      vector690
#define SPC5_CAN_SUB_0_M_CAN_2_L1_HANDLER      vector691
#define SPC5_CAN_SUB_0_M_CAN_2_L0_NUMBER       690
#define SPC5_CAN_SUB_0_M_CAN_2_L1_NUMBER       691
                                       
#define SPC5_HAS_CAN_SUB_0_M_CAN_3             FALSE
#define SPC5_HAS_CAN_SUB_0_M_CAN_4             FALSE

#define SPC5_HAS_CAN_SUB_0_RAM	               TRUE
#define SPC5_CAN_SUB_0_RAM_PTCL                74
#define SPC5_CAN_SUB_0_RAM_ENABLE_CLOCK()      SPCSetPeripheralClockMode(SPC5_CAN_SUB_0_RAM_PTCL, SPC5_CAN_SUB_0_RAM_START_PTCL);
#define SPC5_CAN_SUB_0_RAM_DISABLE_CLOCK()     SPCSetPeripheralClockMode(SPC5_CAN_SUB_0_RAM_PTCL, SPC5_CAN_SUB_0_RAM_STOP_PTCL);
                                             
/* CAN SUBSYSTEM 1 */       
#define SPC5_HAS_CAN_SUB_1_M_CAN_0             FALSE
#define SPC5_HAS_CAN_SUB_1_M_CAN_1             FALSE
#define SPC5_HAS_CAN_SUB_1_M_CAN_2             FALSE
#define SPC5_HAS_CAN_SUB_1_M_CAN_3             FALSE
#define SPC5_HAS_CAN_SUB_1_M_CAN_4             FALSE
#define SPC5_HAS_CAN_SUB_1_RAM                 FALSE

#define SPC5_CAN_SUB_MAX_STD_FILTERS           128
#define SPC5_CAN_SUB_MAX_XTD_FILTERS           64

/* CLOCK CALIBRATION CONTROL UNIT */
#define SPC5_HAS_CCCU_0                        TRUE
#define SPC5_CCCU_0_PTCL                       62
#define SPC5_CCCU_0_ENABLE_CLOCK()             SPCSetPeripheralClockMode(SPC5_CCCU_0_PTCL, SPC5_CCCU_0_START_PTCL);
#define SPC5_CCCU_0_DISABLE_CLOCK()            SPCSetPeripheralClockMode(SPC5_CCCU_0_PTCL, SPC5_CCCU_0_STOP_PTCL);

#define SPC5_HAS_CCCU_1                        FALSE

/* SARADC Attributes */
#define SPC5_HAS_SARADC12_0                 TRUE
#define SPC5_SARADC12_0_PCTL                127
#define SPC5_SARADC12_0_HANDLER             vector528
#define SPC5_SARADC12_0_INT_NUMBER          528
#define SPC5_SARADC12_0_DMA_MUX0_DEV_ID     1
#define SPC5_SARADC12_0_DMA_MUX1_DEV_ID     55

#define SPC5_HAS_SARADC12_1                 FALSE
#define SPC5_HAS_SARADC12_2                 FALSE
#define SPC5_HAS_SARADC12_3                 FALSE

#define SPC5_HAS_SARADC12_4                 TRUE
#define SPC5_SARADC12_4_PCTL                123
#define SPC5_SARADC12_4_HANDLER             vector532
#define SPC5_SARADC12_4_INT_NUMBER          532
#define SPC5_SARADC12_4_DMA_MUX0_DEV_ID     10
#define SPC5_SARADC12_4_DMA_MUX1_DEV_ID     56

#define SPC5_HAS_SARADC12_5                 FALSE
#define SPC5_HAS_SARADC12_6                 FALSE

#define SPC5_HAS_SARADC12_SV                TRUE
#define SPC5_SARADC12_SV_PCTL               112
#define SPC5_SARADC12_SV_HANDLER            vector543
#define SPC5_SARADC12_SV_INT_NUMBER         543
#define SPC5_SARADC12_SV_DMA_MUX0_DEV_ID    3

#define SPC5_HAS_SARADC12_SV_1              FALSE
#define SPC5_HAS_SARADC10_0                 FALSE
#define SPC5_HAS_SARADC10_1                 FALSE
#define SPC5_HAS_SARADC10_STANDBY           FALSE
/** @} */

#endif /* _SPC5726L_REGISTRY_H_ */

/** @} */
