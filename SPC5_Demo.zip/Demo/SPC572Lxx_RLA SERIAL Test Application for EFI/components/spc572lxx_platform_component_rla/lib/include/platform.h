/****************************************************************************
*
* Copyright © 2015-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY – NOT FOR USE IN PRODUCTION
*****************************************************************************/

/**
 * @file    platform.h
 * @brief   platform file.
 */

#ifndef _PLATFORM_H_
#define _PLATFORM_H_

#include "core.h"
#include "toolchain.h"
#include "intc.h"
#if !defined(_FROM_ASM_)
#include "typedefs.h"
#include "spr.h"
#include "spc5726l_registry.h"
#include "spc5726l.h"
#endif

/**
 * @name    MCAN subsystems references
 * @{
 */
#define MCAN_IP_VER				 2U 
#define BYPASS_CANFD_CONF        TRUE
#define spc5_mcan                MCAN_tag			 
#define CAN_SUB_0_RAM	         0xFFED4000UL
#define CAN_SUB_0_RAM_SIZE		 3232U
#define SPC5_MCAN_1              MCAN_1
#define SPC5_MCAN_2              MCAN_2
#define NBTP					 BTP
#define NSJW					 SJW
#define NTSEG1					 TSEG1
#define NTSEG2					 TSEG2
#define NBRP					 BRP
#define MCAN_ERROR_MASK          0xFFF60000UL

/**
 * @name    Clock Calibration Unit references
 * @{
 */
#define SPC5_CCCU_0              CCCU

/** @} */

/**
 * @name    SARDADC References
 *
 * @{
 */
#define SPC5_SARADC_HAS_ALT_REFERENCE  TRUE
#define spc5_saradc	                   SARADC_tag
#define SPC5_SARADC12_0			       SARADC_0
#define SPC5_SARADC12_4                SARADC_4
#define SPC5_SARADC12_SV               SARADC_B
/** @} */



#endif /* _PLATFORM_H_ */
