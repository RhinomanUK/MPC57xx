/****************************************************************************
*
* Copyright © 2017-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY – NOT FOR USE IN PRODUCTION
*****************************************************************************/

/**
 * @file    lldconf.h
 * @brief   LLD configuration header.
 * @details LLD configuration file, this file allows to enable or disable the
 *          various device drivers from your application. You may also use
 *          this file in order to override the device drivers default settings.
 *
 * @addtogroup LLD_CONF
 * @{
 */

#ifndef _LLDCONF_H_
#define _LLDCONF_H_

/**
 * @name    Drivers enable switches
 */
#define LLD_USE_DMA                 TRUE
#define LLD_USE_PAL                 TRUE
#define LLD_USE_PIT                 FALSE
#define LLD_USE_STM                 FALSE
#define LLD_USE_SERIAL              TRUE
#define LLD_USE_PWM                 FALSE
#define LLD_USE_ICU                 FALSE
#define LLD_USE_CAN                 FALSE
#define LLD_USE_SPI                 FALSE
#define LLD_USE_ADC                 FALSE
#define LLD_USE_CTU                 FALSE
#define LLD_USE_I2C                 FALSE
#define LLD_USE_RTC                 FALSE
#define LLD_USE_SWT                 FALSE
#define LLD_USE_SARADC              FALSE
#define LLD_USE_FCCU                FALSE
#define LLD_USE_CRC                 FALSE
#define LLD_USE_WKPU                FALSE
#define LLD_USE_LIN                 FALSE
#define LLD_USE_I2S                 FALSE
/** @} */

/*===========================================================================*/
/**
 * @name SERIAL driver related setting
 * @{
 */
/*===========================================================================*/

/**
 * @name    SERIAL DMA modes
 * @{
 */
#define SPC5_SERIAL_DMA_OFF                 0
#define SPC5_SERIAL_DMA_ON                  1
/** @} */

/**
 * @name    LIN DMA modes
 * @{
 */
#define SPC5_LIN_DMA_OFF                    0
#define SPC5_LIN_DMA_ON                     1
/** @} */

/**
 * @name    LINFlex Mode Settings
 * @{
 */
#define SPC5_LINFLEX_MODE_NONE              0
#define SPC5_LINFLEX_MODE_SERIAL            1
#define SPC5_LINFLEX_MODE_LIN               2
/** @} */

/** @} */

/*===========================================================================*/
/**
 * @name SPI driver related setting
 * @{
 */
/*===========================================================================*/

/**
 * @brief   Enables synchronous APIs.
 * @note    Disabling this option saves both code and data space.
 */
#if !defined(SPI_USE_WAIT) || defined(__DOXYGEN__)
#define SPI_USE_WAIT                TRUE
#endif

/**
 * @brief   Enables the @p spiAcquireBus() and @p spiReleaseBus() APIs.
 * @note    Disabling this option saves both code and data space.
 */
#if !defined(SPI_USE_MUTUAL_EXCLUSION) || defined(__DOXYGEN__)
#define SPI_USE_MUTUAL_EXCLUSION    FALSE
#endif
/** @} */

/**
 * @name    SPI DMA modes
 * @{
 */
#define SPC5_SPI_DMA_NONE                   0
#define SPC5_SPI_DMA_RX_ONLY                1
#define SPC5_SPI_DMA_RX_AND_TX              2
/** @} */

/*
 * EDMA driver settings.
 */
#define SPC5_EDMA_CR_SETTING                (EDMA_CR_GRP1PRI(1) |           \
                                             EDMA_CR_GRP0PRI(0) |           \
                                             EDMA_CR_EMLM       |           \
                                             EDMA_CR_ERGA)
#define SPC5_EDMA1_GROUP0_PRIORITIES        0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15
#define SPC5_EDMA_COMBO_CH_ERR_IRQ_PRIO     10

/*
 * SERIAL driver system settings.
 */
#define SPC5_LINFLEX0_SETTING               SPC5_LINFLEX_MODE_SERIAL
#define SPC5_LINFLEX1_SETTING               SPC5_LINFLEX_MODE_NONE
#define SPC5_LINFLEX14_SETTING               SPC5_LINFLEX_MODE_NONE
#define SPC5_LINFLEX0_PRIORITY              INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 8)
#define SPC5_LINFLEX1_PRIORITY              INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 8)
#define SPC5_LINFLEX14_PRIORITY             INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 8)
#define SPC5_SERIAL_DMA_MODE                SPC5_SERIAL_DMA_OFF
#define SPC5_LIN_DMA_MODE                   SPC5_LIN_DMA_OFF

#define SPC5_SERIAL_LINFLEX0_RX_DMA_CH_ID   1
#define SPC5_SERIAL_LINFLEX0_TX_DMA_CH_ID   0
#define SPC5_SERIAL_LINFLEX1_RX_DMA_CH_ID   9
#define SPC5_SERIAL_LINFLEX1_TX_DMA_CH_ID   8
#define SPC5_SERIAL_LINFLEX14_RX_DMA_CH_ID  2
#define SPC5_SERIAL_LINFLEX14_TX_DMA_CH_ID  10

#define SPC5_SERIAL_LINFLEX0_DMA_IRQ_PRIO   INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 8)
#define SPC5_SERIAL_LINFLEX1_DMA_IRQ_PRIO   INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 8)
#define SPC5_SERIAL_LINFLEX14_DMA_IRQ_PRIO  INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 8)

#define SPC5_LINFLEX0_RX_DMA_MUX            0U
#define SPC5_LINFLEX0_RX_DMA_DEV_ID         SPC5_LINFLEX0_RX_DMA_MUX0_DEV_ID
#define SPC5_LINFLEX0_TX_DMA_MUX            0U
#define SPC5_LINFLEX0_TX_DMA_DEV_ID         SPC5_LINFLEX0_TX_DMA_MUX0_DEV_ID
#define SPC5_LINFLEX1_RX_DMA_MUX            1U
#define SPC5_LINFLEX1_RX_DMA_DEV_ID         SPC5_LINFLEX1_RX_DMA_MUX1_DEV_ID
#define SPC5_LINFLEX1_TX_DMA_MUX            1U
#define SPC5_LINFLEX1_TX_DMA_DEV_ID         SPC5_LINFLEX1_TX_DMA_MUX1_DEV_ID
#define SPC5_LINFLEX14_RX_DMA_MUX           0U
#define SPC5_LINFLEX14_RX_DMA_DEV_ID        SPC5_LINFLEX14_RX_DMA_MUX0_DEV_ID
#define SPC5_LINFLEX14_TX_DMA_MUX           1U
#define SPC5_LINFLEX14_TX_DMA_DEV_ID        SPC5_LINFLEX14_TX_DMA_MUX1_DEV_ID

/*
* PIT driver system settings.
*/
#define SPC5_PIT_USE_PIT0                   FALSE
#define PIT0_CHANNEL_CH0_ENABLED			FALSE
#define PIT0_CHANNEL_CH1_ENABLED			FALSE
#define PIT0_CHANNEL_CH2_ENABLED			FALSE
#define PIT0_CHANNEL_CH3_ENABLED			FALSE

#define PIT0_CHANNEL_CH4_ENABLED			FALSE
#define PIT0_CHANNEL_CH5_ENABLED			FALSE
#define PIT0_CHANNEL_CH6_ENABLED			FALSE
#define PIT0_CHANNEL_CH7_ENABLED			FALSE

#define SPC5_PIT0_START_PCTL                 (SPC5_ME_PCTL_RUN(2) |          \
                                             SPC5_ME_PCTL_LP(2))
#define SPC5_PIT0_STOP_PCTL                  (SPC5_ME_PCTL_RUN(0) |          \
                                             SPC5_ME_PCTL_LP(0))

#define SPC5_PIT_USE_PIT1                   FALSE
#define PIT1_CHANNEL_CH0_ENABLED			FALSE
#define PIT1_CHANNEL_CH1_ENABLED			FALSE

#define PIT1_CHANNEL_CH2_ENABLED			FALSE
#define PIT1_CHANNEL_CH3_ENABLED			FALSE
#define PIT1_CHANNEL_CH4_ENABLED			FALSE
#define PIT1_CHANNEL_CH5_ENABLED			FALSE
#define PIT1_CHANNEL_CH6_ENABLED			FALSE
#define PIT1_CHANNEL_CH7_ENABLED			FALSE

#define SPC5_PIT1_START_PCTL                 (SPC5_ME_PCTL_RUN(2) |          \
                                             SPC5_ME_PCTL_LP(2))
#define SPC5_PIT1_STOP_PCTL                  (SPC5_ME_PCTL_RUN(0) |          \
                                             SPC5_ME_PCTL_LP(0))
                                             
#define SPC5_PIT0_CH0_IRQ_PRIO               INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 4)
#define SPC5_PIT0_CH1_IRQ_PRIO               INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 12)
#define SPC5_PIT0_CH2_IRQ_PRIO               INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 12)
#define SPC5_PIT0_CH3_IRQ_PRIO               INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 12)

#define SPC5_PIT1_CH0_IRQ_PRIO               INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 12)
#define SPC5_PIT1_CH1_IRQ_PRIO               INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 12)

/*
* STM driver system settings.
*/
#define SPC5_STM_USE_STM2                   FALSE
#define SPC5_STM2_CH0_ENABLED				FALSE
#define SPC5_STM2_CH1_ENABLED				FALSE
#define SPC5_STM2_CH2_ENABLED				FALSE
#define SPC5_STM2_CH3_ENABLED				FALSE
#define SPC5_STM2_SYSCLOCK_PRE				1
#define SPC5_STM2_CH0_IRQ_PRIORITY          INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 11)
#define SPC5_STM2_CH1_IRQ_PRIORITY          INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 11)
#define SPC5_STM2_CH2_IRQ_PRIORITY          INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 11)
#define SPC5_STM2_CH3_IRQ_PRIORITY          INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 12)

/*
 * SPI driver system settings.
 */
#define SPC5_SPI_USE_DSPI0                  FALSE
#define SPC5_SPI_USE_DSPI4                  FALSE
#define SPC5_SPI_DMA_MODE                   SPC5_SPI_DMA_NONE
#define SPC5_SPI_DSPI0_MCR                  (0U | SPC5_MCR_PCSIS0 | SPC5_MCR_PCSIS1 | SPC5_MCR_PCSIS2 | SPC5_MCR_PCSIS3 | SPC5_MCR_PCSIS4 | SPC5_MCR_PCSIS5 | SPC5_MCR_PCSIS6 | SPC5_MCR_PCSIS7)
#define SPC5_SPI_DSPI4_MCR                  (0U | SPC5_MCR_PCSIS0 | SPC5_MCR_PCSIS1 | SPC5_MCR_PCSIS2 | SPC5_MCR_PCSIS3 | SPC5_MCR_PCSIS4 | SPC5_MCR_PCSIS5 | SPC5_MCR_PCSIS6 | SPC5_MCR_PCSIS7)

#define SPC5_SPI_DSPI0_IRQ_PRIO             INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 10) 
#define SPC5_SPI_DSPI4_IRQ_PRIO             INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 10)

/*
 * SWT driver system settings.
 */

/* SWT2 settings */
#define SPC5_SWT_USE_SWT2                   FALSE
#define SPC5_SWT2_IRQ_PRIORITY              INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 63)

#define SPC5_SWT2_CLOCK_SOURCE_OSC          TRUE
#define SPC5_SWT2_FREQUENCY                 16000000U
#define SPC5_SWT2_TIMEOUT_PERIOD            0
#define SPC5_SWT2_INTERRUPT_MODE            TRUE
#define SPC5_SWT2_PSEUDO_RANDOM_KEY         FALSE
#define SPC5_SWT2_WINDOW_MODE               FALSE
#define SPC5_SWT2_WINDOW_PERIOD             0
#define SPC5_SWT2_STOP_IN_STOP_MODE         FALSE
#define SPC5_SWT2_FREEZE_IN_DEBUG_MODE      TRUE
#define SPC5_SWT2_SYSTEM_RESET              FALSE

/* SWT3 settings */
#define SPC5_SWT_USE_SWT3                   FALSE
#define SPC5_SWT3_IRQ_PRIORITY              INTC_PSR_ENABLE(INTC_PSR_MAINCORE, 63)

#define SPC5_SWT3_CLOCK_SOURCE_OSC          TRUE
#define SPC5_SWT3_FREQUENCY                 16000000U
#define SPC5_SWT3_TIMEOUT_PERIOD            0
#define SPC5_SWT3_INTERRUPT_MODE            TRUE
#define SPC5_SWT3_PSEUDO_RANDOM_KEY         FALSE
#define SPC5_SWT3_WINDOW_MODE               FALSE
#define SPC5_SWT3_WINDOW_PERIOD             0
#define SPC5_SWT3_STOP_IN_STOP_MODE         FALSE
#define SPC5_SWT3_FREEZE_IN_DEBUG_MODE      TRUE
#define SPC5_SWT3_SYSTEM_RESET              FALSE

/*
 * CAN SUBSYSTEM 0 driver system settings.
 */ 
#define SPC5_USE_CAN_SUB_0_M_CAN_1          FALSE
#define SPC5_CAN_SUB_0_M_CAN_1_START_PTCL   (SPC5_ME_PCTL_RUN(2) | SPC5_ME_PCTL_LP(2))
#define SPC5_CAN_SUB_0_M_CAN_1_STOP_PTCL    (SPC5_ME_PCTL_RUN(0) | SPC5_ME_PCTL_LP(0))
#define SPC5_CAN_SUB_0_M_CAN_1_RAM_START	0x6E0UL
#define SPC5_CAN_SUB_0_M_CAN_1_RAM_SIZE     2080UL
#define SPC5_CAN_SUB_0_M_CAN_1_L0_PRIORITY  INTC_PSR_ENABLE(INTC_PSR_CORE0, 10)
#define SPC5_CAN_SUB_0_M_CAN_1_L1_PRIORITY  INTC_PSR_ENABLE(INTC_PSR_CORE0, 10)

#define SPC5_USE_CAN_SUB_0_M_CAN_2          FALSE
#define SPC5_CAN_SUB_0_M_CAN_2_START_PTCL   (SPC5_ME_PCTL_RUN(2) | SPC5_ME_PCTL_LP(2))
#define SPC5_CAN_SUB_0_M_CAN_2_STOP_PTCL    (SPC5_ME_PCTL_RUN(0) | SPC5_ME_PCTL_LP(0))
#define SPC5_CAN_SUB_0_M_CAN_2_RAM_START	0x1880UL
#define SPC5_CAN_SUB_0_M_CAN_2_RAM_SIZE     1152UL
#define SPC5_CAN_SUB_0_M_CAN_2_L0_PRIORITY  INTC_PSR_ENABLE(INTC_PSR_CORE0, 10)
#define SPC5_CAN_SUB_0_M_CAN_2_L1_PRIORITY  INTC_PSR_ENABLE(INTC_PSR_CORE0, 10)

#define SPC5_CAN_SUB_0_RAM_START_PTCL       (SPC5_ME_PCTL_RUN(2) | SPC5_ME_PCTL_LP(2))
#define SPC5_CAN_SUB_0_RAM_STOP_PTCL        (SPC5_ME_PCTL_RUN(0) | SPC5_ME_PCTL_LP(0))

/* CCCU system settings */
#define SPC5_CCCU_0_START_PTCL              (SPC5_ME_PCTL_RUN(2) | SPC5_ME_PCTL_LP(2))
#define SPC5_CCCU_0_STOP_PTCL               (SPC5_ME_PCTL_RUN(0) | SPC5_ME_PCTL_LP(0))

/*
 * SARADC driver system settings.
 */ 
#define SPC5_SARADC_USE_SARADC12_0			FALSE
#define SPC5_SARADC12_0_PRIORITY			INTC_PSR_ENABLE(INTC_PSR_CORE0, 10)
#define SPC5_SARADC12_0_DMA_CH_ID           1
#define SPC5_SARADC12_0_DMA_IRQ_PRIO        SPC5_SARADC12_0_PRIORITY
#define SPC5_SARADC12_0_DMA_MUX             0U
#define SPC5_SARADC12_0_DMA_DEV_ID          SPC5_SARADC12_0_DMA_MUX0_DEV_ID

#define SPC5_SARADC_USE_SARADC12_4			FALSE
#define SPC5_SARADC12_4_PRIORITY			INTC_PSR_ENABLE(INTC_PSR_CORE0, 10)
#define SPC5_SARADC12_4_DMA_CH_ID           2
#define SPC5_SARADC12_4_DMA_IRQ_PRIO        SPC5_SARADC12_4_PRIORITY
#define SPC5_SARADC12_4_DMA_MUX             0U
#define SPC5_SARADC12_4_DMA_DEV_ID          SPC5_SARADC12_4_DMA_MUX0_DEV_ID

#define SPC5_SARADC_USE_SARADC12_SV			FALSE
#define SPC5_SARADC12_SV_PRIORITY			INTC_PSR_ENABLE(INTC_PSR_CORE0, 10)
#define SPC5_SARADC12_SV_DMA_CH_ID          0
#define SPC5_SARADC12_SV_DMA_IRQ_PRIO       SPC5_SARADC12_SV_PRIORITY
#define SPC5_SARADC12_SV_DMA_MUX            0U
#define SPC5_SARADC12_SV_DMA_DEV_ID         SPC5_SARADC12_SV_DMA_MUX0_DEV_ID


#define SPC5_SARADC_USE_DMA                 FALSE
#define SPC5_SARADC_DMA_BUFFER_LENGHT       0U
#define SPC5_SARADC_MAX_NUMOFCHANNELS	    0U
#define SPC5_SARADC_MAX_NUMOFTHRESHOLDS     1U
#define SPC5_SARADC_DMA_ERROR_HOOK(saradcp) irqSysHalt()
/*
 * PWM driver system settings.
 */
#define SPC5_PWM_USE_PWM0                   FALSE
#define SPC5_PWM_USE_PWM1                   FALSE
#define SPC5_PWM_USE_PWM2                   FALSE
#define SPC5_PWM_USE_PWM3                   FALSE
#define SPC5_PWM_USE_PWM4                   FALSE
#define SPC5_PWM_USE_PWM5                   FALSE
#define SPC5_PWM_USE_PWM6                   FALSE
#define SPC5_PWM_USE_PWM7                   FALSE
#define SPC5_PWM_USE_PWM8                   FALSE
#define SPC5_PWM_USE_PWM9                   FALSE
#define SPC5_PWM_USE_PWM10                   FALSE
#define SPC5_PWM_USE_PWM11                   FALSE
#define SPC5_PWM_USE_PWM12                   FALSE
#define SPC5_PWM_USE_PWM13                   FALSE
#define SPC5_PWM_USE_PWM14                   FALSE
#define SPC5_PWM_USE_PWM15                   FALSE
#define SPC5_PWM_USE_PWM16                   FALSE
#define SPC5_PWM_USE_PWM17                   FALSE
#define SPC5_PWM_USE_PWM18                   FALSE
#define SPC5_PWM_USE_PWM19                   FALSE
#define SPC5_PWM_USE_PWM20                   FALSE
#define SPC5_PWM_USE_PWM21                   FALSE
#define SPC5_PWM_USE_PWM22                   FALSE
#define SPC5_PWM_USE_PWM23                   FALSE
#define SPC5_PWM_USE_PWM24                   FALSE
#define SPC5_PWM_USE_PWM25                   FALSE
#define SPC5_PWM_USE_PWM26                   FALSE
#define SPC5_PWM_USE_PWM27                   FALSE
#define SPC5_PWM_USE_PWM28                   FALSE
#define SPC5_PWM_USE_PWM29                   FALSE
#define SPC5_PWM_USE_PWM30                   FALSE
#define SPC5_PWM_USE_PWM31                   FALSE


#endif /* _LLDCONF_H_ */

/** @} */
