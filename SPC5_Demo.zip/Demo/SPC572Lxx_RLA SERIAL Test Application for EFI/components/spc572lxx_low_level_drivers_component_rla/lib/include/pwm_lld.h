/****************************************************************************
*
* Copyright © 2015-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY – NOT FOR USE IN PRODUCTION
*****************************************************************************/
/**
 * @file    pwm_lld.h
 * @brief   SPC5xx PWM low level driver header.
 *
 * @addtogroup PWM
 * @{
 */

#ifndef _PWM_LLD_H_
#define _PWM_LLD_H_

#include "spc5_lld.h"
#include "lldconf.h"

#if (LLD_USE_PWM == TRUE) || defined(__DOXYGEN__)

#include "gtm.h"

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/**
 * @name    PWM output mode macros
 * @{
 */


/**
 * @brief   Max number of PWM channels per PWM driver.
 */
#define PWM_CHANNELS                        1U

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

/**
 * @name    PWM duty cycle conversion
 * @{
 */
/**
 * @brief   Converts from fraction to pulse width.
 * @note    Be careful with rounding errors, this is integer math not magic.
 *          You can specify tenths of thousandth but make sure you have the
 *          proper hardware resolution by carefully choosing the clock source
 *          and prescaler settings, see @p PWM_COMPUTE_PSC.
 *
 * @param[in] pwmp      pointer to a @p PWMDriver object
 * @param[in] channel   channel number
 * @param[in] denominator denominator of the fraction
 * @param[in] numerator numerator of the fraction
 * @return              The pulse width to be passed to @p pwm_lld_enable_channel().
 *
 * @api
 */
#define PWM_FRACTION_TO_WIDTH(pwmp, channel, denominator, numerator)        \
  ((pwmcnt_t)((((pwmcnt_t)(pwmp)->config->period) *                         \
               (pwmcnt_t)(numerator)) / (pwmcnt_t)(denominator)))
/**
 * @brief   Converts from percentage to pulse width.
 * @note    Be careful with rounding errors, this is integer math not magic.
 *          You can specify tenths of thousandth but make sure you have the
 *          proper hardware resolution by carefully choosing the clock source
 *          and prescaler settings, see @p PWM_COMPUTE_PSC.
 *
 * @param[in] pwmp      pointer to a @p PWMDriver object
 * @param[in] channel   Channel number
 * @param[in] percentage percentage as an integer between 0 and 10000
 * @return              The pulse width to be passed to @p pwm_lld_enable_channel().
 *
 * @api
 */
#define PWM_PERCENTAGE_TO_WIDTH(pwmp, channel, percentage)                  \
  PWM_FRACTION_TO_WIDTH(pwmp, channel, 10000, percentage)
/** @} */


/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/**
 * @brief   Type of a structure representing a PWM driver.
 */
typedef struct PWMDriver PWMDriver;

/**
 * @brief   PWM notification callback type.
 *
 * @param[in] pwmp      pointer to a @p PWMDriver object
 */
typedef void (*pwmcallback_t)(PWMDriver *pwmp);

/**
 * @brief   PWM mode type.
 */
typedef uint32_t pwmmode_t;

/**
 * @brief   PWM channel type.
 */
typedef uint8_t pwmchannel_t;

/**
 * @brief   PWM counter type.
 */
typedef uint16_t pwmcnt_t;

/**
 * @brief   PWM driver channel configuration structure.
 */
typedef struct {
	  /**
	   * @brief Channel active logic level.
	   */
	  pwmmode_t                 mode;
	  /**
	   * @brief Channel callback pointer.
	   * @note  This callback is invoked on the channel compare event. If set to
	   *        @p NULL then the callback is disabled.
	   */
	  pwmcallback_t             callback;
	  /* End of the mandatory fields.*/
} PWMChannelConfig;

/**
 * @brief   PWM driver configuration structure.
 */
typedef struct {
  /**
   * @brief Timer clock in Hz.
   */
  uint32_t                  frequency;
  /**
   * @brief PWM period in ticks.
   */
  pwmcnt_t                  period;
  /**
   * @brief Periodic callback pointer.
   * @note  This callback is invoked on PWM counter reset. If set to
   *        @p NULL then the callback is disabled.
   */
  pwmcallback_t             callback;
  /**
   * @brief Channels configurations.
   */
  PWMChannelConfig          channels[PWM_CHANNELS];
  /* End of the mandatory fields.*/
  /**
   * @brief PWM functional mode.
   */
  pwmmode_t                 mode;
} PWMConfig;

/**
 * @brief   Structure representing a PWM driver.
 */
struct PWMDriver {
  /**
   * @brief eMIOSx channel number.
   */
  uint8_t                   ch_number;
  /**
   * @brief Current driver configuration data.
   */
  const PWMConfig           *config;
  /**
   * @brief Current PWM period in ticks.
   */
  pwmcnt_t                  period;
  /**
   * @brief Pointer to the volatile FlexPWM registers block.
   */
  volatile struct GTM_TOM_tag *gtm_pwm;
};


/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/

#if (SPC5_PWM_USE_PWM0 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD1;
#endif

#if (SPC5_PWM_USE_PWM1 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD2;
#endif

#if (SPC5_PWM_USE_PWM2 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD3;
#endif

#if (SPC5_PWM_USE_PWM3 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD4;
#endif

#if (SPC5_PWM_USE_PWM4 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD5;
#endif

#if (SPC5_PWM_USE_PWM5 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD6;
#endif

#if (SPC5_PWM_USE_PWM6 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD7;
#endif

#if (SPC5_PWM_USE_PWM7 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD8;
#endif

#if (SPC5_PWM_USE_PWM8 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD9;
#endif

#if (SPC5_PWM_USE_PWM9 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD10;
#endif

#if (SPC5_PWM_USE_PWM10 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD11;
#endif

#if (SPC5_PWM_USE_PWM11 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD12;
#endif

#if (SPC5_PWM_USE_PWM12 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD13;
#endif

#if (SPC5_PWM_USE_PWM13 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD14;
#endif

#if (SPC5_PWM_USE_PWM14 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD15;
#endif

#if (SPC5_PWM_USE_PWM15 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD16;
#endif

#if (SPC5_PWM_USE_PWM16 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD17;
#endif

#if (SPC5_PWM_USE_PWM17 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD18;
#endif

#if (SPC5_PWM_USE_PWM18 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD19;
#endif

#if (SPC5_PWM_USE_PWM19 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD20;
#endif

#if (SPC5_PWM_USE_PWM20 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD21;
#endif

#if (SPC5_PWM_USE_PWM21 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD22;
#endif

#if (SPC5_PWM_USE_PWM22 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD23;
#endif

#if (SPC5_PWM_USE_PWM23 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD24;
#endif

#if (SPC5_PWM_USE_PWM24 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD25;
#endif

#if (SPC5_PWM_USE_PWM25 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD26;
#endif

#if (SPC5_PWM_USE_PWM26 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD27;
#endif

#if (SPC5_PWM_USE_PWM27 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD28;
#endif

#if (SPC5_PWM_USE_PWM28 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD29;
#endif

#if (SPC5_PWM_USE_PWM29 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD30;
#endif

#if (SPC5_PWM_USE_PWM30 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD31;
#endif

#if (SPC5_PWM_USE_PWM31 == TRUE) && !defined(__DOXYGEN__)
extern PWMDriver PWMD32;
#endif


#ifdef __cplusplus
extern "C" {
#endif
  void pwm_lld_init(void);
  void pwm_lld_start(PWMDriver *pwmp, const PWMConfig *config);
  void pwm_lld_stop(PWMDriver *pwmp);
  void pwm_lld_enable_channel(PWMDriver *pwmp,
                              pwmchannel_t channel,
                              pwmcnt_t width);
  void pwm_lld_disable_channel(PWMDriver *pwmp, pwmchannel_t channel);
  void pwm_lld_change_period(PWMDriver *pwmp, pwmcnt_t period);
#ifdef __cplusplus
}
#endif

#endif /* LLD_USE_PWM */

#endif /* _PWM_LLD_H_ */

/** @} */
