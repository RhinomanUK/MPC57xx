/****************************************************************************
*
* Copyright © 2015-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY – NOT FOR USE IN PRODUCTION
*****************************************************************************/
/**
 * @file    pwm_lld.c
 * @brief   SPC5xx PWM low level driver code.
 *
 * @addtogroup PWM
 * @{
 */

#include "pwm_lld.h"

#if (LLD_USE_PWM == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/


/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/

#if (SPC5_PWM_USE_PWM0 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD1 driver identifier,
 * @note    referred to TOM0 Channel 0
 */
PWMDriver PWMD1;
#endif

#if (SPC5_PWM_USE_PWM1 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD2 driver identifier,
 * @note    referred to TOM0 Channel 1
 */
PWMDriver PWMD2;
#endif

#if (SPC5_PWM_USE_PWM2 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD3 driver identifier,
 * @note    referred to TOM0 Channel 2
 */
PWMDriver PWMD3;
#endif

#if (SPC5_PWM_USE_PWM3 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD4 driver identifier,
 * @note    referred to TOM0 Channel 3
 */
PWMDriver PWMD4;
#endif

#if (SPC5_PWM_USE_PWM4 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD5 driver identifier,
 * @note    referred to TOM0 Channel 4
 */
PWMDriver PWMD5;
#endif

#if (SPC5_PWM_USE_PWM5 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD6 driver identifier,
 * @note    referred to TOM0 Channel 5
 */
PWMDriver PWMD6;
#endif

#if (SPC5_PWM_USE_PWM6 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD7 driver identifier,
 * @note    referred to TOM0 Channel 6
 */
PWMDriver PWMD7;
#endif

#if (SPC5_PWM_USE_PWM7 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD8 driver identifier,
 * @note    referred to TOM0 Channel 7
 */
PWMDriver PWMD8;
#endif

#if (SPC5_PWM_USE_PWM8 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD9 driver identifier,
 * @note    referred to TOM0 Channel 8
 */
PWMDriver PWMD9;
#endif

#if (SPC5_PWM_USE_PWM9 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD10 driver identifier,
 * @note    referred to TOM0 Channel 9
 */
PWMDriver PWMD10;
#endif

#if (SPC5_PWM_USE_PWM10 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD11 driver identifier,
 * @note    referred to TOM0 Channel 10
 */
PWMDriver PWMD11;
#endif

#if (SPC5_PWM_USE_PWM11 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD12 driver identifier,
 * @note    referred to TOM0 Channel 11
 */
PWMDriver PWMD12;
#endif

#if (SPC5_PWM_USE_PWM12 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD13 driver identifier,
 * @note    referred to TOM0 Channel 12
 */
PWMDriver PWMD13;
#endif

#if (SPC5_PWM_USE_PWM13 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD14 driver identifier,
 * @note    referred to TOM0 Channel 13
 */
PWMDriver PWMD14;
#endif

#if (SPC5_PWM_USE_PWM14 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD15 driver identifier,
 * @note    referred to TOM0 Channel 14
 */
PWMDriver PWMD15;
#endif

#if (SPC5_PWM_USE_PWM15 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD16 driver identifier,
 * @note    referred to TOM0 Channel 15
 */
PWMDriver PWMD16;
#endif

#if (SPC5_PWM_USE_PWM16 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD17 driver identifier,
 * @note    referred to TOM1 Channel 0
 */
PWMDriver PWMD17;
#endif

#if (SPC5_PWM_USE_PWM17 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD18 driver identifier,
 * @note    referred to TOM1 Channel 1
 */
PWMDriver PWMD18;
#endif

#if (SPC5_PWM_USE_PWM18 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD19 driver identifier,
 * @note    referred to TOM1 Channel 2
 */
PWMDriver PWMD19;
#endif

#if (SPC5_PWM_USE_PWM19 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD20 driver identifier,
 * @note    referred to TOM1 Channel 3
 */
PWMDriver PWMD20;
#endif

#if (SPC5_PWM_USE_PWM20 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD21 driver identifier,
 * @note    referred to TOM1 Channel 4
 */
PWMDriver PWMD21;
#endif

#if (SPC5_PWM_USE_PWM21 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD22 driver identifier,
 * @note    referred to TOM1 Channel 5
 */
PWMDriver PWMD22;
#endif

#if (SPC5_PWM_USE_PWM22 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD23 driver identifier,
 * @note    referred to TOM1 Channel 6
 */
PWMDriver PWMD23;
#endif

#if (SPC5_PWM_USE_PWM23 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD24 driver identifier,
 * @note    referred to TOM1 Channel 7
 */
PWMDriver PWMD24;
#endif

#if (SPC5_PWM_USE_PWM24 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD25 driver identifier,
 * @note    referred to TOM1 Channel 8
 */
PWMDriver PWMD25;
#endif

#if (SPC5_PWM_USE_PWM25 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD26 driver identifier,
 * @note    referred to TOM1 Channel 9
 */
PWMDriver PWMD26;
#endif

#if (SPC5_PWM_USE_PWM26 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD27 driver identifier,
 * @note    referred to TOM1 Channel 10
 */
PWMDriver PWMD27;
#endif

#if (SPC5_PWM_USE_PWM27 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD28 driver identifier,
 * @note    referred to TOM1 Channel 11
 */
PWMDriver PWMD28;
#endif

#if (SPC5_PWM_USE_PWM28 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD29 driver identifier,
 * @note    referred to TOM1 Channel 12
 */
PWMDriver PWMD29;
#endif

#if (SPC5_PWM_USE_PWM29 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD30 driver identifier,
 * @note    referred to TOM1 Channel 13
 */
PWMDriver PWMD30;
#endif

#if (SPC5_PWM_USE_PWM30 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD31 driver identifier,
 * @note    referred to TOM1 Channel 14
 */
PWMDriver PWMD31;
#endif

#if (SPC5_PWM_USE_PWM31 == TRUE) || defined(__DOXYGEN__)
/**
 * @brief   PWMD32 driver identifier,
 * @note    referred to TOM1 Channel 15
 */
PWMDriver PWMD32;
#endif


/**
 * @brief   Low level PWM driver initialization.
 *
 * @init
 */
void pwm_lld_init(void) {
	/* Driver initialization.*/

#if (SPC5_PWM_USE_PWM0 == TRUE)
  PWMD1.ch_number = 0;
  PWMD1.config = NULL;
  PWMD1.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM1 == TRUE)
  PWMD2.ch_number = 1;
  PWMD2.config = NULL;
  PWMD2.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM2 == TRUE)
  PWMD3.ch_number = 2;
  PWMD3.config = NULL;
  PWMD3.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM3 == TRUE)
  PWMD4.ch_number = 3;
  PWMD4.config = NULL;
  PWMD4.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM4 == TRUE)
  PWMD5.ch_number = 4;
  PWMD5.config = NULL;
  PWMD5.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM5 == TRUE)
  PWMD6.ch_number = 5;
  PWMD6.config = NULL;
  PWMD6.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM6 == TRUE)
  PWMD7.ch_number = 6;
  PWMD7.config = NULL;
  PWMD7.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM7 == TRUE)
  PWMD8.ch_number = 7;
  PWMD8.config = NULL;
  PWMD8.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM8 == TRUE)
  PWMD9.ch_number = 8;
  PWMD9.config = NULL;
  PWMD9.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM9 == TRUE)
  PWMD10.ch_number = 9;
  PWMD10.config = NULL;
  PWMD10.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM10 == TRUE)
  PWMD11.ch_number = 10;
  PWMD11.config = NULL;
  PWMD11.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM11 == TRUE)
  PWMD12.ch_number = 11;
  PWMD12.config = NULL;
  PWMD12.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM12 == TRUE)
  PWMD13.ch_number = 12;
  PWMD13.config = NULL;
  PWMD13.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM13 == TRUE)
  PWMD14.ch_number = 13;
  PWMD14.config = NULL;
  PWMD14.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM14 == TRUE)
  PWMD15.ch_number = 14;
  PWMD15.config = NULL;
  PWMD15.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM15 == TRUE)
  PWMD16.ch_number = 15;
  PWMD16.config = NULL;
  PWMD16.gtm_pwm = &GTM_TOM_0;
#endif

#if (SPC5_PWM_USE_PWM16 == TRUE)
  PWMD17.ch_number = 0;
  PWMD17.config = NULL;
  PWMD17.gtm_pwm = &GTM_TOM_1;
#endif

#if (SPC5_PWM_USE_PWM17 == TRUE)
  PWMD18.ch_number = 1;
  PWMD18.config = NULL;
  PWMD18.gtm_pwm = &GTM_TOM_1;
#endif

#if (SPC5_PWM_USE_PWM18 == TRUE)
  PWMD19.ch_number = 2;
  PWMD19.config = NULL;
  PWMD19.gtm_pwm = &GTM_TOM_1;
#endif

#if (SPC5_PWM_USE_PWM19 == TRUE)
  PWMD20.ch_number = 3;
  PWMD20.config = NULL;
  PWMD20.gtm_pwm = &GTM_TOM_1;
#endif

#if (SPC5_PWM_USE_PWM20 == TRUE)
  PWMD21.ch_number = 4;
  PWMD21.config = NULL;
  PWMD21.gtm_pwm = &GTM_TOM_1;
#endif

#if (SPC5_PWM_USE_PWM21 == TRUE)
  PWMD22.ch_number = 5;
  PWMD22.config = NULL;
  PWMD22.gtm_pwm = &GTM_TOM_1;
#endif

#if (SPC5_PWM_USE_PWM22 == TRUE)
  PWMD23.ch_number = 6;
  PWMD23.config = NULL;
  PWMD23.gtm_pwm = &GTM_TOM_1;
#endif

#if (SPC5_PWM_USE_PWM23 == TRUE)
  PWMD24.ch_number = 7;
  PWMD24.config = NULL;
  PWMD24.gtm_pwm = &GTM_TOM_1;
#endif

#if (SPC5_PWM_USE_PWM24 == TRUE)
  PWMD25.ch_number = 8;
  PWMD25.config = NULL;
  PWMD25.gtm_pwm = &GTM_TOM_1;
#endif

#if (SPC5_PWM_USE_PWM25 == TRUE)
  PWMD26.ch_number = 9;
  PWMD26.config = NULL;
  PWMD26.gtm_pwm = &GTM_TOM_1;
#endif

#if (SPC5_PWM_USE_PWM26 == TRUE)
  PWMD27.ch_number = 10;
  PWMD27.config = NULL;
  PWMD27.gtm_pwm = &GTM_TOM_1;
#endif

#if (SPC5_PWM_USE_PWM27 == TRUE)
  PWMD28.ch_number = 11;
  PWMD28.config = NULL;
  PWMD28.gtm_pwm = &GTM_TOM_1;
#endif

#if (SPC5_PWM_USE_PWM28 == TRUE)
  PWMD29.ch_number = 12;
  PWMD29.config = NULL;
  PWMD29.gtm_pwm = &GTM_TOM_1;
#endif

#if (SPC5_PWM_USE_PWM29 == TRUE)
  PWMD30.ch_number = 13;
  PWMD30.config = NULL;
  PWMD30.gtm_pwm = &GTM_TOM_1;
#endif

#if (SPC5_PWM_USE_PWM30 == TRUE)
  PWMD31.ch_number = 14;
  PWMD31.config = NULL;
  PWMD31.gtm_pwm = &GTM_TOM_1;
#endif

#if (SPC5_PWM_USE_PWM31 == TRUE)
  PWMD32.ch_number = 15;
  PWMD32.config = NULL;
  PWMD32.gtm_pwm = &GTM_TOM_1;
#endif
}

/**
 * @brief   Configures and activates the PWM peripheral.
 *
 * @param[in] pwmp      pointer to a @p PWMDriver object
 * @param[in] config    pointer to a @p PWMConfig object 
 *
 * @api
 */
void pwm_lld_start(PWMDriver *pwmp, const PWMConfig *config) {
  uint32_t ctrl_reg;
  uint32_t ch;
  
  pwmp->config = config;

  /* TO BE REMOVED */
  #define SL_BIT         11UL
  #define CLK_SRC_SR_BIT 12UL
  ctrl_reg = (((uint32_t)config->channels[0].mode << SL_BIT) +
		  ((uint32_t)config->frequency << CLK_SRC_SR_BIT));

  switch(pwmp->ch_number) {
  case 0:
    pwmp->gtm_pwm->CH0_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH0_SR0.R = config->period;
    break;
  case 1:
    pwmp->gtm_pwm->CH1_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH1_SR0.R = config->period;
    break;
  case 2:
    pwmp->gtm_pwm->CH2_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH2_SR0.R = config->period;
    break;
  case 3:
    pwmp->gtm_pwm->CH3_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH3_SR0.R = config->period;
    break;
  case 4:
    pwmp->gtm_pwm->CH4_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH4_SR0.R = config->period;
    break;
  case 5:
    pwmp->gtm_pwm->CH5_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH5_SR0.R = config->period;
    break;
  case 6:
    pwmp->gtm_pwm->CH6_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH6_SR0.R = config->period;
    break;
  case 7:
    pwmp->gtm_pwm->CH7_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH7_SR0.R = config->period;
    break;
  case 8:
    pwmp->gtm_pwm->CH8_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH8_SR0.R = config->period;
    break;
  case 9:
    pwmp->gtm_pwm->CH9_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH9_SR0.R = config->period;
    break;
  case 10:
    pwmp->gtm_pwm->CH10_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH10_SR0.R = config->period;
    break;
  case 11:
    pwmp->gtm_pwm->CH11_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH11_SR0.R = config->period;
	  break;
  case 12:
    pwmp->gtm_pwm->CH12_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH12_SR0.R = config->period;
    break;
  case 13:
    pwmp->gtm_pwm->CH13_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH13_SR0.R = config->period;
    break;
  case 14:
    pwmp->gtm_pwm->CH14_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH14_SR0.R = config->period;
    break;
  case 15:
    pwmp->gtm_pwm->CH15_CTRL.R = ctrl_reg;
    pwmp->gtm_pwm->CH15_SR0.R = config->period;
    break;
  default:
    /* MISRA Check */
    break;
  }

  if (pwmp->ch_number < 8U) {
    ch = 2UL << (pwmp->ch_number * 2U);
    pwmp->gtm_pwm->TGC0_GLB_CTRL.R = (ch << 16UL);
  } else {
    ch = 2UL << ((pwmp->ch_number - 8U) * 2U);
    pwmp->gtm_pwm->TGC1_GLB_CTRL.R = (ch << 16UL);
  }
}

/**
 * @brief   Deactivates the PWM peripheral.
 *
 * @param[in] pwmp      pointer to a @p PWMDriver object
 *
 * @api
 */
void pwm_lld_stop(PWMDriver *pwmp) {

  uint32_t ch;

  pwm_lld_disable_channel(pwmp, pwmp->ch_number);

  if (pwmp->ch_number < 8U) {
    ch = 1UL << (pwmp->ch_number * 2U);
    pwmp->gtm_pwm->TGC0_GLB_CTRL.R = (ch << 16UL);
  } else {
    ch = 1UL << ((pwmp->ch_number - 8U) * 2U);
    pwmp->gtm_pwm->TGC1_GLB_CTRL.R = (ch << 16UL);
  }

}

/**
 * @brief   Enables a PWM channel.
 * @pre     The PWM unit must have been activated using @p pwm_lld_start().
 * @post    The channel is active using the specified configuration.
 * @note    The function has effect at the next cycle start.
 *
 * @param[in] pwmp      pointer to a @p PWMDriver object
 * @param[in] channel   unused
 * @param[in] width     PWM pulse width as clock pulses number
 *
 * @api
 */
void pwm_lld_enable_channel(PWMDriver *pwmp,
                            pwmchannel_t channel,
                            pwmcnt_t width) {
  (void)(channel);
  uint32_t ch;
  
  switch(pwmp->ch_number) {
  case 0:
    pwmp->gtm_pwm->CH0_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH0_SR1.R = width; /* duty cycle */
    break;
  case 1:
    pwmp->gtm_pwm->CH1_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH1_SR1.R = width; /* duty cycle */
    break;
  case 2:
    pwmp->gtm_pwm->CH2_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH2_SR1.R = width; /* duty cycle */
    break;
  case 3:
    pwmp->gtm_pwm->CH3_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH3_SR1.R = width; /* duty cycle */
    break;
  case 4:
    pwmp->gtm_pwm->CH4_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH4_SR1.R = width; /* duty cycle */
    break;
  case 5:
    pwmp->gtm_pwm->CH5_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH5_SR1.R = width; /* duty cycle */
    break;
  case 6:
    pwmp->gtm_pwm->CH6_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH6_SR1.R = width; /* duty cycle */
    break;
  case 7:
    pwmp->gtm_pwm->CH7_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH7_SR1.R = width; /* duty cycle */
    break;
  case 8:
    pwmp->gtm_pwm->CH8_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH8_SR1.R = width; /* duty cycle */
    break;
  case 9:
    pwmp->gtm_pwm->CH9_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH9_SR1.R = width; /* duty cycle */
    break;
  case 10:
    pwmp->gtm_pwm->CH10_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH10_SR1.R = width; /* duty cycle */
    break;
  case 11:
    pwmp->gtm_pwm->CH11_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH11_SR1.R = width; /* duty cycle */
    break;
  case 12:
    pwmp->gtm_pwm->CH12_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH12_SR1.R = width; /* duty cycle */
    break;
  case 13:
    pwmp->gtm_pwm->CH13_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH13_SR1.R = width; /* duty cycle */
    break;
  case 14:
    pwmp->gtm_pwm->CH14_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH14_SR1.R = width; /* duty cycle */
    break;
  case 15:
    pwmp->gtm_pwm->CH15_SR0.R = pwmp->config->period;
    pwmp->gtm_pwm->CH15_SR1.R = width; /* duty cycle */
    break;
  default:
    /* MISRA Check */
    break;
  }

  if (pwmp->ch_number < 8U) {
    ch = 2UL << (pwmp->ch_number * 2U);

    pwmp->gtm_pwm->TGC0_ENDIS_CTRL.R = ch;
    pwmp->gtm_pwm->TGC0_OUTEN_CTRL.R = ch;

    pwmp->gtm_pwm->TGC0_GLB_CTRL.R = 1U; /* HOST_TRIG */
  } else {
    ch = 2UL << ((pwmp->ch_number - 8U) * 2U);

    pwmp->gtm_pwm->TGC1_ENDIS_CTRL.R = ch;
    pwmp->gtm_pwm->TGC1_OUTEN_CTRL.R = ch;

    pwmp->gtm_pwm->TGC1_GLB_CTRL.R = 1U; /* HOST_TRIG */
  }
}

/**
 * @brief   Disables a PWM channel.
 * @pre     The PWM unit must have been activated using @p pwm_lld_start().
 * @post    The channel is disabled and its output line returned to the
 *          idle state.
 * @note    The function has effect at the next cycle start.
 *
 * @param[in] pwmp      pointer to a @p PWMDriver object
 * @param[in] channel   unused
 *
 * @api
 */
void pwm_lld_disable_channel(PWMDriver *pwmp, pwmchannel_t channel) {

  (void)(channel);
  uint32_t ch;

  if (pwmp->ch_number < 8U) {
    ch = 1UL << (pwmp->ch_number * 2U);

    pwmp->gtm_pwm->TGC0_OUTEN_CTRL.R = ch;
    pwmp->gtm_pwm->TGC0_ENDIS_CTRL.R = ch;

    pwmp->gtm_pwm->TGC0_GLB_CTRL.R = 1U; /* HOST_TRIG */
  } else {
    ch = 1UL << ((pwmp->ch_number - 8U) * 2U);

    pwmp->gtm_pwm->TGC1_OUTEN_CTRL.R = ch;
    pwmp->gtm_pwm->TGC1_ENDIS_CTRL.R = ch;

    pwmp->gtm_pwm->TGC1_GLB_CTRL.R = 1U; /* HOST_TRIG */
  }
}

/**
 * @brief   Changes the period the PWM peripheral.
 * @details This function changes the period of a PWM unit that has already
 *          been activated using @p pwm_lld_start().
 * @pre     The PWM unit must have been activated using @p pwm_lld_start().
 * @post    The PWM unit period is changed to the new value.
 * @note    The function has effect at the next cycle start.
 * @note    If a period is specified that is shorter than the pulse width
 *          programmed in one of the channels then the behavior is not
 *          guaranteed.
 *
 * @param[in] pwmp      pointer to a @p PWMDriver object
 * @param[in] period    new cycle time in ticks
 *
 * @api
 */
void pwm_lld_change_period(PWMDriver *pwmp, pwmcnt_t period) {
  
  pwmp->period = period;

  switch(pwmp->ch_number) {
  case 0:
    pwmp->gtm_pwm->CH0_SR0.R = period;
    break;
  case 1:
    pwmp->gtm_pwm->CH1_SR0.R = period;
    break;
  case 2:
    pwmp->gtm_pwm->CH2_SR0.R = period;
    break;
  case 3:
    pwmp->gtm_pwm->CH3_SR0.R = period;
    break;
  case 4:
    pwmp->gtm_pwm->CH4_SR0.R = period;
    break;
  case 5:
    pwmp->gtm_pwm->CH5_SR0.R = period;
    break;
  case 6:
    pwmp->gtm_pwm->CH6_SR0.R = period;
    break;
  case 7:
    pwmp->gtm_pwm->CH7_SR0.R = period;
    break;
  case 8:
    pwmp->gtm_pwm->CH8_SR0.R = period;
    break;
  case 9:
    pwmp->gtm_pwm->CH9_SR0.R = period;
    break;
  case 10:
    pwmp->gtm_pwm->CH10_SR0.R = period;
    break;
  case 11:
    pwmp->gtm_pwm->CH11_SR0.R = period;
    break;
  case 12:
    pwmp->gtm_pwm->CH12_SR0.R = period;
    break;
  case 13:
    pwmp->gtm_pwm->CH13_SR0.R = period;
    break;
  case 14:
    pwmp->gtm_pwm->CH14_SR0.R = period;
    break;
  case 15:
    pwmp->gtm_pwm->CH15_SR0.R = period;
    break;
  default:
	  /* MISRA check */
	  break;
  }

  if (pwmp->ch_number < 8U) {
    pwmp->gtm_pwm->TGC0_GLB_CTRL.R = 1U; /* HOST_TRIG */
  } else {
    pwmp->gtm_pwm->TGC1_GLB_CTRL.R = 1U; /* HOST_TRIG */
  }
}

#endif /* LLD_USE_PWM */

/** @} */
