/****************************************************************************
*
* Copyright © 2015-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY – NOT FOR USE IN PRODUCTION
*****************************************************************************/
/**
 * @file    can_lld.c
 * @brief   SPC5xx CAN low level driver code.
 *
 * @addtogroup CAN
 * @{
 */

#include "can_lld.h"

#if (LLD_USE_CAN == TRUE) || defined(__DOXYGEN__)

/*===========================================================================*/
/* Driver local definitions.                                                 */
/*===========================================================================*/
void can_lld_readRxBuffer(CANDriver *canp, uint32_t msgbuf, CANRxFrame *crfp);
void can_lld_writeTxBuffer(CANDriver *canp, uint32_t msgbuf, const CANTxFrame *ctfp);

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

#if (SPC5_USE_CAN_SUB_0_M_CAN_0 == TRUE) && !defined(__DOXYGEN__)
CANDriver CAND1;
#endif

#if (SPC5_USE_CAN_SUB_0_M_CAN_1 == TRUE) && !defined(__DOXYGEN__)
CANDriver CAND2;
#endif

#if (SPC5_USE_CAN_SUB_0_M_CAN_2 == TRUE) && !defined(__DOXYGEN__)
CANDriver CAND3;
#endif

#if (SPC5_USE_CAN_SUB_0_M_CAN_3 == TRUE) && !defined(__DOXYGEN__)
CANDriver CAND4;
#endif

#if (SPC5_USE_CAN_SUB_1_M_CAN_1 == TRUE) && !defined(__DOXYGEN__)
CANDriver CAND7;
#endif

#if (SPC5_USE_CAN_SUB_1_M_CAN_2 == TRUE) && !defined(__DOXYGEN__)
CANDriver CAND8;
#endif

#if (SPC5_USE_CAN_SUB_1_M_CAN_3 == TRUE) && !defined(__DOXYGEN__)
CANDriver CAND9;
#endif

#if (SPC5_USE_CAN_SUB_1_M_CAN_4 == TRUE) && !defined(__DOXYGEN__)
CANDriver CAND10;
#endif

/*===========================================================================*/
/* Driver local variables and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver local functions.                                                   */
/*===========================================================================*/
/**
 * @brief   Read data from RX Buffer
 *
 * @param[in] canp      pointer to the @p CANDriver object
 * @param[in] msgbuf    Rx buffer message to be read
 * @param[out] crfp     Pointer to CANrxFrame
 * @notapi
 */
void can_lld_readRxBuffer(CANDriver *canp, uint32_t msgbuf, CANRxFrame *crfp) {
  uint32_t address_pointer;
  uint32_t reg_value;

  address_pointer = canp->shared_ram_start_address + ((uint32_t)(canp->mcan->RXBC.B.RBSA) << CAN_SA_BIT_POSITION) + (16UL * msgbuf);
  /* read message */
  if ((*((vuint32_t*)(address_pointer)) >> 30U) == CAN_ID_XTD) {
    crfp->TYPE = CAN_ID_XTD;
    crfp->ID = (*((vuint32_t*)(address_pointer)) & 0x1FFFFFFFUL);
  }
  else {
    crfp->TYPE = CAN_ID_STD;
    crfp->ID = (*((vuint32_t*)(address_pointer)) >> 18U);
  }

  /* Data Lenght Code */
  address_pointer = address_pointer + 4UL;
  reg_value = *(vuint32_t*)(address_pointer);
  crfp->DLC = (uint8_t)((reg_value >> 16) & 0x0FU);

  /* check CANFD frame */
  crfp->OPERATION = (uint8_t)((reg_value >> 21) & 0x01U);

  /* Time Stamp */
  crfp->TIME = (uint16_t)(reg_value & 0x000000FFUL);

  /* Data 0*/
  address_pointer = address_pointer + 4UL;
  reg_value = *(vuint32_t*)(address_pointer);
  crfp->data32[0] = reg_value;

  /* Data 1 */
  address_pointer = address_pointer + 4UL;
  reg_value = *(vuint32_t*)(address_pointer);
  crfp->data32[1] = reg_value;
}

/**
 * @brief   Write data to RX Buffer
 *
 * @param[in] canp      pointer to the @p CANDriver object
 * @param[in] msgbuf    tx buffer message to write
 * @param[in] ctfp     Pointer to CANTxFrame to be write
 * @notapi
 */
void can_lld_writeTxBuffer(CANDriver *canp, uint32_t msgbuf, const CANTxFrame *ctfp) {
  uint32_t address_pointer;
  uint32_t reg_value;

  /* set the pointer to tx buffer address in shared ram */
  address_pointer = canp->shared_ram_start_address + ((uint32_t)(canp->mcan->TXBC.B.TBSA) << CAN_SA_BIT_POSITION) + (16UL * (uint32_t)msgbuf);

  /* Prepare message */
  if (ctfp->TYPE == CAN_ID_XTD) {
    *(vuint32_t*)(address_pointer) = (ctfp->ID | 0x40000000U);
  }
  else {
    *(vuint32_t*)(address_pointer) = (ctfp->ID << 18);
  }
  /* Data Length */
  address_pointer = address_pointer + 4UL;
  reg_value = ((uint32_t)ctfp->DLC << 16);
  *(vuint32_t*)(address_pointer) = reg_value;

  /* CANFD bit settings */
  if (ctfp->OPERATION == CAN_OP_CANFD) {
    *(vuint32_t*)(address_pointer) |= 0x00200000UL;
    if (canp->config->canfd_brs == TRUE) {
      *(vuint32_t*)(address_pointer) |= 0x00100000UL;
    }
  }

  /* Data 0 */
  address_pointer = address_pointer + 4UL;
  *(vuint32_t*)(address_pointer) = (ctfp->data32[0]);

  /* Data 1 */
  address_pointer = address_pointer + 4UL;
  *(vuint32_t*)(address_pointer) = (ctfp->data32[1]);
}
/**
 * @brief   Common ISR handler for interrupt line 0.
 *
 * @param[in] canp      pointer to the @p CANDriver object
 *
 * @notapi
 */
static void can_lld_l0_handler(CANDriver *canp) {
  CANRxFrame crfp;
  uint32_t msgbuf = 0;

  /* check if Transmission complete interrupt occurred on line0 */
  if (canp->mcan->IR.B.TC == 1U) {
    if (canp->mcan->ILS.B.TCL == 0U) {
      /*callback*/
      /* clear flag */
      canp->mcan->IR.R = CAN_IR_TC;
    }
  }

  /* check if Rx buffer interrupt occurred on line 0 */
  if (canp->mcan->IR.B.DRX == 1U) {
    if (canp->mcan->ILS.B.DRXL == 0U) {
      /* callback if configured is called */
      if (canp->config->rx_callback != NULL) {
        for (msgbuf = 0; msgbuf < canp->config->num_of_rx_buffers; msgbuf++) {
          if (((canp->mcan->NDAT1.R) & (1UL << msgbuf)) != 0U) {
            break;
          }
        }
        /* read messag */
        can_lld_readRxBuffer(canp, msgbuf, &crfp);

        /* callback */
        canp->config->rx_callback(msgbuf, crfp);

        /* release rx buffer */
        canp->mcan->NDAT1.R = (1UL << msgbuf);

      }

      /* clear flag */
      canp->mcan->IR.R = CAN_IR_DRX;
    }
  }

  /* Error check */
  if ((canp->mcan->IR.R & MCAN_ERROR_MASK) != 0U) {
    uint32_t psr = (uint32_t)canp->mcan->PSR.R;
    if (canp->config->err_callback != NULL) {
      canp->config->err_callback(canp, psr);
    }
    /* reset all error bits checked */
    canp->mcan->IR.R = MCAN_ERROR_MASK;
  }
}

/**
 * @brief   Common ISR handler for interrupt line 1.
 *
 * @param[in] canp      pointer to the @p CANDriver object
 *
 * @notapi
 */
static void can_lld_l1_handler(CANDriver *canp) {
  CANRxFrame crfp;
  uint32_t msgbuf = 0;

  /* check if Transmission complete interrupt occurred */
  if (canp->mcan->IR.B.TC == 1U) {
    if (canp->mcan->ILS.B.TCL == 1U) {
      /*callback*/
      /* clear flag */
      canp->mcan->IR.R = CAN_IR_TC;
    }
  }

  /* check if Rx buffer interrupt occurred */
  if (canp->mcan->IR.B.DRX == 1U) {
    if (canp->mcan->ILS.B.DRXL == 1U) {
      /* callback if configured is called */
      if (canp->config->rx_callback != NULL) {
        for (msgbuf = 0; msgbuf < canp->config->num_of_rx_buffers; msgbuf++) {
          if (((canp->mcan->NDAT1.R) & (1UL << msgbuf)) != 0U) {
            break;
          }
        }

        /* read message */
        can_lld_readRxBuffer(canp, msgbuf, &crfp);

        /* callback */
        canp->config->rx_callback(msgbuf, crfp);

        /* release rx buffer */
        canp->mcan->NDAT1.R = (1UL << msgbuf);
      }

      /* clear flag */
      canp->mcan->IR.R = CAN_IR_DRX;
    }
  }
}

#if (SPC5_USE_CAN_SUB_0_M_CAN_0 == TRUE)
/**
 * @brief   CAN_SUB_0_M_CAN_0 interrupt handler for Line 0.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_0_M_CAN_0_L0_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l0_handler(&CAND1);

  IRQ_EPILOGUE();
}

/**
 * @brief   CAN_SUB_0_M_CAN_0 interrupt handler for Line 1.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_0_M_CAN_0_L1_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l1_handler(&CAND1);

  IRQ_EPILOGUE();
}
#endif

#if (SPC5_USE_CAN_SUB_0_M_CAN_1 == TRUE)
/**
 * @brief   CAN_SUB_0_M_CAN_1 interrupt handler for Line 0.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_0_M_CAN_1_L0_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l0_handler(&CAND2);

  IRQ_EPILOGUE();
}

/**
 * @brief   CAN_SUB_0_M_CAN_1 interrupt handler for Line 1.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_0_M_CAN_1_L1_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l1_handler(&CAND2);

  IRQ_EPILOGUE();
}
#endif

#if (SPC5_USE_CAN_SUB_0_M_CAN_2 == TRUE)
/**
 * @brief   CAN_SUB_0_M_CAN_2 interrupt handler for Line 0.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_0_M_CAN_2_L0_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l0_handler(&CAND3);

  IRQ_EPILOGUE();
}

/**
 * @brief   CAN_SUB_0_M_CAN_2 interrupt handler for Line 1.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_0_M_CAN_2_L1_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l1_handler(&CAND3);

  IRQ_EPILOGUE();
}
#endif

#if (SPC5_USE_CAN_SUB_0_M_CAN_3 == TRUE)
/**
 * @brief   CAN_SUB_0_M_CAN_3 interrupt handler for Line 0.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_0_M_CAN_3_L0_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l0_handler(&CAND4);

  IRQ_EPILOGUE();
}

/**
 * @brief   CAN_SUB_0_M_CAN_3 interrupt handler for Line 1.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_0_M_CAN_3_L1_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l1_handler(&CAND4);

  IRQ_EPILOGUE();
}
#endif

#if (SPC5_USE_CAN_SUB_0_M_CAN_4 == TRUE)
/**
 * @brief   CAN_SUB_0_M_CAN_4 interrupt handler for Line 0.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_0_M_CAN_4_L0_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l0_handler(&CAND5);

  IRQ_EPILOGUE();
}

/**
 * @brief   CAN_SUB_0_M_CAN_4 interrupt handler for Line 1.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_0_M_CAN_4_L1_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l1_handler(&CAND5);

  IRQ_EPILOGUE();
}
#endif

#if (SPC5_USE_CAN_SUB_1_M_CAN_0 == TRUE)
/**
 * @brief   CAN_SUB_1_M_CAN_0 interrupt handler for Line 0.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_1_M_CAN_0_L0_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l0_handler(&CAND6);

  IRQ_EPILOGUE();
}

/**
 * @brief   CAN_SUB_1_M_CAN_0 interrupt handler for Line 1.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_1_M_CAN_0_L1_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l1_handler(&CAND6);

  IRQ_EPILOGUE();
}
#endif

#if (SPC5_USE_CAN_SUB_1_M_CAN_1 == TRUE)
/**
 * @brief   CAN_SUB_1_M_CAN_1 interrupt handler for Line 0.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_1_M_CAN_1_L0_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l0_handler(&CAND7);

  IRQ_EPILOGUE();
}

/**
 * @brief   CAN_SUB_1_M_CAN_1 interrupt handler for Line 1.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_1_M_CAN_1_L1_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l1_handler(&CAND7);

  IRQ_EPILOGUE();
}
#endif

#if (SPC5_USE_CAN_SUB_1_M_CAN_2 == TRUE)
/**
 * @brief   CAN_SUB_1_M_CAN_2 interrupt handler for Line 0.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_1_M_CAN_2_L0_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l0_handler(&CAND8);

  IRQ_EPILOGUE();
}

/**
 * @brief   CAN_SUB_1_M_CAN_2 interrupt handler for Line 1.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_1_M_CAN_2_L1_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l1_handler(&CAND8);

  IRQ_EPILOGUE();
}
#endif

#if (SPC5_USE_CAN_SUB_1_M_CAN_3 == TRUE)
/**
 * @brief   CAN_SUB_1_M_CAN_3 interrupt handler for Line 0.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_1_M_CAN_3_L0_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l0_handler(&CAND9);

  IRQ_EPILOGUE();
}

/**
 * @brief   CAN_SUB_1_M_CAN_3 interrupt handler for Line 1.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_1_M_CAN_3_L1_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l1_handler(&CAND9);

  IRQ_EPILOGUE();
}
#endif

#if (SPC5_USE_CAN_SUB_1_M_CAN_4 == TRUE)
/**
 * @brief   CAN_SUB_1_M_CAN_4 interrupt handler for Line 0.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_1_M_CAN_4_L0_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l0_handler(&CAND10);

  IRQ_EPILOGUE();
}

/**
 * @brief   CAN_SUB_1_M_CAN_4 interrupt handler for Line 1.
 *
 * @isr
 */
IRQ_HANDLER(SPC5_CAN_SUB_1_M_CAN_4_L1_HANDLER) {

  IRQ_PROLOGUE();

  can_lld_l1_handler(&CAND10);

  IRQ_EPILOGUE();
}
#endif
/*===========================================================================*/
/* Driver exported functions.                                                */
/*===========================================================================*/
/**
 * @brief   Low level CAN driver initialization.
 *
 * @notapi
 */
void can_lld_init(void) {

  uint32_t i;
  uint32_t address_pointer;

  /* Enable CCCU_0 unit */
  SPC5_CCCU_0_ENABLE_CLOCK()
  ;

  /* Enable CCCU_1 unit only in case device has a CCCU1 for SUBSYSTEM 1 */
#if  (SPC5_HAS_CCCU_1 == TRUE)
#if    ((SPC5_USE_CAN_SUB_1_M_CAN_0 == TRUE)  || (SPC5_USE_CAN_SUB_1_M_CAN_1 == TRUE) \
    || (SPC5_USE_CAN_SUB_1_M_CAN_2 == TRUE)  || (SPC5_USE_CAN_SUB_1_M_CAN_3 == TRUE) \
    || (SPC5_USE_CAN_SUB_1_M_CAN_4 == TRUE))
  SPC5_CCCU_1_ENABLE_CLOCK();

#endif
#endif

  /* MCAN SUBSYSTEM 0 */
#if (SPC5_USE_CAN_SUB_0_M_CAN_0 == TRUE)  
  CAND1.config = NULL;
  CAND1.mcan = &SPC5_MCAN_0;
  INTC_PSR(SPC5_CAN_SUB_0_M_CAN_0_L0_NUMBER) = SPC5_CAN_SUB_0_M_CAN_0_L0_PRIORITY;
  INTC_PSR(SPC5_CAN_SUB_0_M_CAN_0_L1_NUMBER) = SPC5_CAN_SUB_0_M_CAN_0_L1_PRIORITY;
  SPC5_CAN_SUB_0_M_CAN_0_ENABLE_CLOCK();
#endif

#if (SPC5_USE_CAN_SUB_0_M_CAN_1 == TRUE)  
  CAND2.config = NULL;
  CAND2.mcan = &SPC5_MCAN_1;
  INTC_PSR(SPC5_CAN_SUB_0_M_CAN_1_L0_NUMBER) = SPC5_CAN_SUB_0_M_CAN_1_L0_PRIORITY;
  INTC_PSR(SPC5_CAN_SUB_0_M_CAN_1_L1_NUMBER) = SPC5_CAN_SUB_0_M_CAN_1_L1_PRIORITY;
  SPC5_CAN_SUB_0_M_CAN_1_ENABLE_CLOCK()
  ;
#endif

#if (SPC5_USE_CAN_SUB_0_M_CAN_2 == TRUE)  
  CAND3.config = NULL;
  CAND3.mcan = &SPC5_MCAN_2;
  INTC_PSR(SPC5_CAN_SUB_0_M_CAN_2_L0_NUMBER) = SPC5_CAN_SUB_0_M_CAN_2_L0_PRIORITY;
  INTC_PSR(SPC5_CAN_SUB_0_M_CAN_2_L1_NUMBER) = SPC5_CAN_SUB_0_M_CAN_2_L1_PRIORITY;
  SPC5_CAN_SUB_0_M_CAN_2_ENABLE_CLOCK()
  ;
#endif

#if (SPC5_USE_CAN_SUB_0_M_CAN_3 == TRUE)  
  CAND4.config = NULL;
  CAND4.mcan = &SPC5_MCAN_3;
  INTC_PSR(SPC5_CAN_SUB_0_M_CAN_3_L0_NUMBER) = SPC5_CAN_SUB_0_M_CAN_3_L0_PRIORITY;
  INTC_PSR(SPC5_CAN_SUB_0_M_CAN_3_L1_NUMBER) = SPC5_CAN_SUB_0_M_CAN_3_L1_PRIORITY;
  SPC5_CAN_SUB_0_M_CAN_3_ENABLE_CLOCK();
#endif

#if (SPC5_USE_CAN_SUB_0_M_CAN_4 == TRUE)  
  CAND5.config = NULL;
  CAND5.mcan = &SPC5_MCAN_4;
  INTC_PSR(SPC5_CAN_SUB_0_M_CAN_4_L0_NUMBER) = SPC5_CAN_SUB_0_M_CAN_4_L0_PRIORITY;
  INTC_PSR(SPC5_CAN_SUB_0_M_CAN_4_L1_NUMBER) = SPC5_CAN_SUB_0_M_CAN_4_L1_PRIORITY;
  SPC5_CAN_SUB_0_M_CAN_4_ENABLE_CLOCK();
#endif

  /* MCAN SUBSYSTEM 1*/
#if (SPC5_USE_CAN_SUB_1_M_CAN_0 == TRUE)  
  CAND6.config = NULL;
  CAND6.mcan = &SPC5_MCAN_5;
  INTC_PSR(SPC5_CAN_SUB_1_M_CAN_0_L0_NUMBER) = SPC5_CAN_SUB_1_M_CAN_0_L0_PRIORITY;
  INTC_PSR(SPC5_CAN_SUB_1_M_CAN_0_L1_NUMBER) = SPC5_CAN_SUB_1_M_CAN_0_L1_PRIORITY;
  SPC5_CAN_SUB_1_M_CAN_0_ENABLE_CLOCK();
#endif

#if (SPC5_USE_CAN_SUB_1_M_CAN_1 == TRUE)  
  CAND7.config = NULL;
  CAND7.mcan = &SPC5_MCAN_6;
  INTC_PSR(SPC5_CAN_SUB_1_M_CAN_1_L0_NUMBER) = SPC5_CAN_SUB_1_M_CAN_1_L0_PRIORITY;
  INTC_PSR(SPC5_CAN_SUB_1_M_CAN_1_L1_NUMBER) = SPC5_CAN_SUB_1_M_CAN_1_L1_PRIORITY;
  SPC5_CAN_SUB_1_M_CAN_1_ENABLE_CLOCK();
#endif

#if (SPC5_USE_CAN_SUB_1_M_CAN_2 == TRUE)  
  CAND8.config = NULL;
  CAND8.mcan = &SPC5_MCAN_7;
  INTC_PSR(SPC5_CAN_SUB_1_M_CAN_2_L0_NUMBER) = SPC5_CAN_SUB_1_M_CAN_2_L0_PRIORITY;
  INTC_PSR(SPC5_CAN_SUB_1_M_CAN_2_L1_NUMBER) = SPC5_CAN_SUB_1_M_CAN_2_L1_PRIORITY;
  SPC5_CAN_SUB_1_M_CAN_2_ENABLE_CLOCK();
#endif

#if (SPC5_USE_CAN_SUB_1_M_CAN_3 == TRUE)  
  CAND9.config = NULL;
  CAND9.mcan = &SPC5_MCAN_8;
  INTC_PSR(SPC5_CAN_SUB_1_M_CAN_3_L0_NUMBER) = SPC5_CAN_SUB_1_M_CAN_3_L0_PRIORITY;
  INTC_PSR(SPC5_CAN_SUB_1_M_CAN_3_L1_NUMBER) = SPC5_CAN_SUB_1_M_CAN_3_L1_PRIORITY;
  SPC5_CAN_SUB_1_M_CAN_3_ENABLE_CLOCK();
#endif

#if (SPC5_USE_CAN_SUB_1_M_CAN_4 == TRUE)  
  CAND10.config = NULL;
  CAND10.mcan = &SPC5_MCAN_9;
  INTC_PSR(SPC5_CAN_SUB_1_M_CAN_4_L0_NUMBER) = SPC5_CAN_SUB_1_M_CAN_4_L0_PRIORITY;
  INTC_PSR(SPC5_CAN_SUB_1_M_CAN_4_L1_NUMBER) = SPC5_CAN_SUB_1_M_CAN_4_L1_PRIORITY;
  SPC5_CAN_SUB_1_M_CAN_4_ENABLE_CLOCK();
#endif

  /* Shared RAM 0 initialization */
#if (SPC5_HAS_CAN_SUB_0_RAM == TRUE)
#if   ((SPC5_USE_CAN_SUB_0_M_CAN_0 == TRUE)  || (SPC5_USE_CAN_SUB_0_M_CAN_1 == TRUE) \
    || (SPC5_USE_CAN_SUB_0_M_CAN_2 == TRUE)  || (SPC5_USE_CAN_SUB_0_M_CAN_3 == TRUE) \
    || (SPC5_USE_CAN_SUB_0_M_CAN_4 == TRUE))
  SPC5_CAN_SUB_0_RAM_ENABLE_CLOCK()
  ;
  for (i = 0; i < CAN_SUB_0_RAM_SIZE; i += 4UL) {
    address_pointer = CAN_SUB_0_RAM + i;
    *(vuint32_t*)(address_pointer) = 0x00000000UL;
  }
#endif
#endif

#if (SPC5_HAS_CAN_SUB_1_RAM == TRUE)
#if   ((SPC5_USE_CAN_SUB_1_M_CAN_0 == TRUE)  || (SPC5_USE_CAN_SUB_1_M_CAN_1 == TRUE) \
    || (SPC5_USE_CAN_SUB_1_M_CAN_2 == TRUE)  || (SPC5_USE_CAN_SUB_1_M_CAN_3 == TRUE) \
    || (SPC5_USE_CAN_SUB_1_M_CAN_4 == TRUE))
  /* Shared RAM 1 initialization */
  SPC5_CAN_SUB_1_RAM_ENABLE_CLOCK();
  for (i = 0; i < CAN_SUB_1_RAM_SIZE; i += 4UL) {
    address_pointer = CAN_SUB_1_RAM + i;
    *(vuint32_t*)(address_pointer) = 0x00000000UL;
  }
#endif
#endif
}

/**
 * @brief   Configures and activates the CAN peripheral.
 *
 * @param[in] canp      pointer to the @p CANDriver object
 * @param[in] config	pointer to the @p CANconfig configuration
 *
 * @notapi
 */
void can_lld_start(CANDriver *canp, const CANConfig *config) {

  uint32_t count;
  uint32_t ram_address_pointer;

#if (MCAN_IP_VER == 2U)
  /* MCAN IP version 2 has a fixed tx buffer address */
  /*define a variable to store it */
  uint32_t txbuf_offset = 0UL;;
#endif
  ram_address_pointer = 0UL;

  osalEnterCritical();

  canp->config = config;

  /* SUBSYSTEM 0 Clock enable */
#if (SPC5_USE_CAN_SUB_0_M_CAN_0 == TRUE)
  if (&CAND1 == canp) {
    ram_address_pointer = SPC5_CAN_SUB_0_M_CAN_0_RAM_START;
    canp->shared_ram_start_address = CAN_SUB_0_RAM;
  }
#endif
#if (SPC5_USE_CAN_SUB_0_M_CAN_1 == TRUE)
  if (&CAND2 == canp) {
    ram_address_pointer = SPC5_CAN_SUB_0_M_CAN_1_RAM_START;
    canp->shared_ram_start_address = CAN_SUB_0_RAM;
    /* Tx Buffer OffSet is fixed for MCAN IP version 2 */
#if (MCAN_IP_VER == 2U)
    txbuf_offset = 0xD00UL;
#endif
  }
#endif
#if (SPC5_USE_CAN_SUB_0_M_CAN_2 == TRUE)
  if (&CAND3 == canp) {
    ram_address_pointer = SPC5_CAN_SUB_0_M_CAN_2_RAM_START;
    canp->shared_ram_start_address = CAN_SUB_0_RAM;
    /* Tx Buffer OffSet is fixed for MCAN IP version 2 */
#if (MCAN_IP_VER == 2U)
    txbuf_offset = 0x1C00UL;
#endif	
  }
#endif
#if (SPC5_USE_CAN_SUB_0_M_CAN_3 == TRUE)
  if (&CAND4 == canp) {
    ram_address_pointer = SPC5_CAN_SUB_0_M_CAN_3_RAM_START;
    canp->shared_ram_start_address = CAN_SUB_0_RAM;
  }
#endif
#if (SPC5_USE_CAN_SUB_0_M_CAN_4 == TRUE)
  if(&CAND5 == canp) {
    ram_address_pointer = SPC5_CAN_SUB_0_M_CAN_4_RAM_START;
    canp->shared_ram_start_address = CAN_SUB_0_RAM;
  }
#endif

  /* SUBSYSTEM 1 Clock enable */
#if (SPC5_USE_CAN_SUB_1_M_CAN_0 == TRUE)
  if(&CAND6 == canp) {
    ram_address_pointer = SPC5_CAN_SUB_1_M_CAN_0_RAM_START;
    canp->shared_ram_start_address = CAN_SUB_1_RAM;
  }
#endif
#if (SPC5_USE_CAN_SUB_1_M_CAN_1 == TRUE)
  if (&CAND7 == canp) {
    ram_address_pointer = SPC5_CAN_SUB_1_M_CAN_1_RAM_START;
    canp->shared_ram_start_address = CAN_SUB_1_RAM;
  }
#endif
#if (SPC5_USE_CAN_SUB_1_M_CAN_2 == TRUE)
  if (&CAND8 == canp) {
    ram_address_pointer = SPC5_CAN_SUB_1_M_CAN_2_RAM_START;
    canp->shared_ram_start_address = CAN_SUB_1_RAM;
  }
#endif
#if (SPC5_USE_CAN_SUB_1_M_CAN_3 == TRUE)
  if (&CAND9 == canp) {
    ram_address_pointer = SPC5_CAN_SUB_1_M_CAN_3_RAM_START;
    canp->shared_ram_start_address = CAN_SUB_1_RAM;
  }
#endif
#if (SPC5_USE_CAN_SUB_1_M_CAN_4 == TRUE)
  if (&CAND10 == canp) {
    ram_address_pointer = SPC5_CAN_SUB_1_M_CAN_4_RAM_START;
    canp->shared_ram_start_address = CAN_SUB_1_RAM;
  }
#endif

  /* Switch in configuration and Initialization mode */
  canp->mcan->CCCR.R = CAN_CCCR_CCE | CAN_CCCR_INIT;
  while (canp->mcan->CCCR.B.INIT != 1U) {
  }

  /* Bypass Clock Calibration on CAN unit for CCCU_1 */
  if (SPC5_CCCU_0.CCFG.R != 0x444U) {
    SPC5_CCCU_0.CCFG.R = 0x444U;
  }

  /* Enable CCCU_1 unit only in case device has a CCCU1 for SUBSYSTEM 1 */
#if  (SPC5_HAS_CCCU_1 == TRUE)
#if    ((SPC5_USE_CAN_SUB_1_M_CAN_0 == TRUE)  || (SPC5_USE_CAN_SUB_1_M_CAN_1 == TRUE) \
    || (SPC5_USE_CAN_SUB_1_M_CAN_2 == TRUE)  || (SPC5_USE_CAN_SUB_1_M_CAN_3 == TRUE) \
    || (SPC5_USE_CAN_SUB_1_M_CAN_4 == TRUE))

  /* * Bypass Clock Calibration on CAN unit for CCCU_1 */
  if (SPC5_CCCU_1.CCFG.R != 0x444U) {
    SPC5_CCCU_1.CCFG.R = 0x444U;
  }

#endif
#endif
  /* enable loop back */
  if (canp->config->loopback != CAN_NO_LOOPBACK) {
    canp->mcan->CCCR.B.TEST = 1U;
    canp->mcan->TEST.B.LBCK = 1U;
    if (canp->config->loopback == CAN_INTERNAL_LOOPBACK) {
      canp->mcan->CCCR.B.MON = 1U;
    }
  }

  /* Bit rate setting. NBTP register */
  canp->mcan->NBTP.B.NSJW = canp->config->nsjw;
  canp->mcan->NBTP.B.NTSEG1 = canp->config->ntseg1;
  canp->mcan->NBTP.B.NTSEG2 = canp->config->ntseg2;
  canp->mcan->NBTP.B.NBRP = canp->config->pres - 1U;

#if (BYPASS_CANFD_CONF == FALSE)
  /* CANFD Settings */
  if (canp->config->canfd_enabled == TRUE) {
    canp->mcan->CCCR.B.FDOE = 1U;
    if (canp->config->canfd_brs == TRUE) {
      canp->mcan->CCCR.B.BRSE = 1U;
    }
    else {
      canp->mcan->CCCR.B.BRSE = 0U;
    }
    /* Bit rate setting. DBTP register */
    canp->mcan->DBTP.B.DSJW = canp->config->dsjw;
    canp->mcan->DBTP.B.DTSEG1 = canp->config->dtseg1;
    canp->mcan->DBTP.B.DTSEG2 = canp->config->dtseg2;
    canp->mcan->DBTP.B.DBRP = canp->config->canfd_pres - 1U;
  }
#endif
  /* Global Filter Initialization */
  canp->mcan->GFC.B.ANFS = 0x03U; /*reject messages don't match filtering */

  /* Shared RAM Initialization */
  /*standard filters*/
  canp->mcan->SIDFC.B.FLSSA = (uint16_t)(ram_address_pointer >> CAN_SA_BIT_POSITION);
  canp->mcan->SIDFC.B.LSS = canp->config->numof_std_filters;
  ram_address_pointer = ram_address_pointer + (4UL * (uint32_t)canp->config->numof_std_filters);
  /* if Start address bit position is 4 then round the pointer to multiple of 16 */
#if (CAN_SA_BIT_POSITION == 0x04U)
  ram_address_pointer = CAN_ROUND16(ram_address_pointer);
#endif

  /*extended filters*/
  canp->mcan->XIDFC.B.FLESA = (uint16_t)(ram_address_pointer >> CAN_SA_BIT_POSITION);
  canp->mcan->XIDFC.B.LSE = canp->config->numof_xtd_filters;
  ram_address_pointer = ram_address_pointer + (8UL * (uint32_t)canp->config->numof_xtd_filters);
#if (CAN_SA_BIT_POSITION == 0x04U)
  ram_address_pointer = CAN_ROUND16(ram_address_pointer);
#endif

  /* Rx buffers */
  canp->mcan->RXBC.B.RBSA = (uint16_t)(ram_address_pointer >> CAN_SA_BIT_POSITION); /* word adrress */
  /* Tx Buffer OffSet is fixed for MCAN IP version 2       */
  /* if IP>2 then the end of RXbuf will be start for TXbuf */
#if (MCAN_IP_VER == 2U)
  ram_address_pointer = txbuf_offset;
#else
  ram_address_pointer = ram_address_pointer + ((8UL + 8UL) * (uint32_t)canp->config->num_of_rx_buffers);
#endif	
#if (CAN_SA_BIT_POSITION == 0x04U)
  ram_address_pointer = CAN_ROUND16(ram_address_pointer);
#endif

  /* Tx Buffers */
  canp->mcan->TXBC.B.TBSA = (uint16_t)(ram_address_pointer >> CAN_SA_BIT_POSITION); /* word adrress */
  canp->mcan->TXBC.B.NDTB = canp->config->num_of_tx_buffers;
  // ram_address_pointer = ram_address_pointer + ((8UL + 8UL) * (uint32_t)canp->config->num_of_tx_buffers);

  /* standard filter configuration */
  for (count = 0; count < (uint32_t)canp->config->numof_std_filters; count++) {
    uint32_t val;
    uint32_t filter_offset;

    val = canp->config->STD_Filter[count].SFID2;
    val += ((uint32_t)canp->config->STD_Filter[count].SFID1 << 16);
    val += ((uint32_t)canp->config->STD_Filter[count].SFEC << 27);
    val += ((uint32_t)canp->config->STD_Filter[count].SFT << 30);
    filter_offset = canp->shared_ram_start_address + ((uint32_t)(canp->mcan->SIDFC.B.FLSSA) << CAN_SA_BIT_POSITION) + (4UL * count);
    *(vuint32_t*)(filter_offset) = val;
  }

  /* Extended filter configuration */
  for (count = 0; count < canp->config->numof_xtd_filters; count++) {
    uint32_t val;
    uint32_t filter_offset;

    /* Word F0 */
    val = canp->config->XTD_Filter[count].EFID1;
    val += ((uint32_t)canp->config->XTD_Filter[count].EFEC << 29);
    filter_offset = canp->shared_ram_start_address + ((uint32_t)(canp->mcan->XIDFC.B.FLESA) << CAN_SA_BIT_POSITION) + (8UL * count);
    *(vuint32_t*)(filter_offset) = val;
    /* Word F1 */
    val = canp->config->XTD_Filter[count].EFID2;
    val += ((uint32_t)canp->config->XTD_Filter[count].EFT << 30);
    filter_offset = canp->shared_ram_start_address + ((uint32_t)(canp->mcan->XIDFC.B.FLESA) << CAN_SA_BIT_POSITION) + (8UL * count) + 4U;
    *(vuint32_t*)(filter_offset) = val;
  }

  /* Enable Interrupt for RX buffer */
  if (canp->config->can_rx_int_line != CAN_RX_INT_DISABLE) {
    canp->mcan->IE.B.DRXE = 1U;
    /* Assing interrupt to lines */
    canp->mcan->ILS.B.DRXL = canp->config->can_rx_int_line;
  }

  /* Enable Interrupt for Transmission complete */
  if (canp->config->can_tx_int_line != CAN_TX_INT_DISABLE) {
    canp->mcan->IE.B.TCE = 1U;
    for (count = 0; count < canp->config->num_of_tx_buffers; count++) {
      canp->mcan->TXBTIE.R += (1UL << count);
    }
    /* Assing interrupt to lines */
    canp->mcan->ILS.B.TCL = canp->config->can_tx_int_line;
  }

  /* If error callback is defined , Enable on Line 0 interrupts for the following errors:
   *  
   *  - WDI:  Watchdog Interrupt
   *  - BO:   BusOff
   *  - EW:   Warning Status
   *  - EP:   Error Passive
   *  - ELO:  Error Logging Overflow
   *  - BEU:  Bit Error Uncorrected
   *  - BEC:  Bit Error Corrected
   *  - TOO:  Timeout
   *  - ARA:  Access to reserved address           (MCAN IP v3)
   *  - PED:  Protocol Error In Data Phase         (MCAN IP v3)
   *  - PEA:  Protocol error in Arbitration Phase  (MCAN IP v3)
   *  - MRAF: Message RAM access Failure           (MCAN IP v3)
   *  - UMDE: Unprocessed Message Discarded        (MCAN IP v2)
   *  - STE:  Stuff Error                          (MCAN IP v2)
   *  - FOE:  Format Error                         (MCAN IP v2)
   *  - ACKE: Acknowledge error                    (MCAN IP v2)
   *  - BE:   Bit Error                            (MCAN IP v2)
   *  - CRCE: CRC Error                            (MCAN IP v2)
   *
   *  MCAN_ERROR_MASK contains bit map for these errors
   */

  if (canp->config->err_callback != NULL) {
    canp->mcan->IE.R |= MCAN_ERROR_MASK;
  }
  /* enable both interrupt lines */
  canp->mcan->ILE.R = 0x3U;

  /* Exit Init Mode */
  canp->mcan->CCCR.B.ASM = 0;
  canp->mcan->CCCR.B.INIT = 0U;
  while (canp->mcan->CCCR.B.INIT == 1U) {

  }

  osalExitCritical();
}

/**
 * @brief   Deactivates the CAN peripheral.
 *
 * @param[in] canp      pointer to the @p CANDriver object
 *
 * @api
 */
void can_lld_stop(CANDriver *canp) {
  uint32_t i;
  uint32_t ram_address_pointer = 0UL;
  uint32_t ram_size = 0UL;
  uint32_t address_pointer;

  osalEnterCritical();

  /* Stop MCAN */
  canp->mcan->CCCR.B.INIT = 1U;

  /* Disable interrupts */
  canp->mcan->IE.R = 0UL;
  canp->mcan->ILE.R = 0UL;
  canp->mcan->ILS.R = 0UL;

  /* erase shared RAM associated to MCAN driver */
#if (SPC5_USE_CAN_SUB_0_M_CAN_0 == TRUE)
  if (&CAND1 == canp) {
    ram_address_pointer = CAN_SUB_0_RAM + SPC5_CAN_SUB_0_M_CAN_0_RAM_START;
    ram_size = SPC5_CAN_SUB_0_M_CAN_0_RAM_SIZE;
  }
#endif
#if (SPC5_USE_CAN_SUB_0_M_CAN_1 == TRUE)
  if (&CAND2 == canp) {
    ram_address_pointer = CAN_SUB_0_RAM + SPC5_CAN_SUB_0_M_CAN_1_RAM_START;
    ram_size = SPC5_CAN_SUB_0_M_CAN_1_RAM_SIZE;
  }
#endif
#if (SPC5_USE_CAN_SUB_0_M_CAN_2 == TRUE)
  if (&CAND3 == canp) {
    ram_address_pointer = CAN_SUB_0_RAM + SPC5_CAN_SUB_0_M_CAN_2_RAM_START;
    ram_size = SPC5_CAN_SUB_0_M_CAN_2_RAM_SIZE;
  }
#endif
#if (SPC5_USE_CAN_SUB_0_M_CAN_3 == TRUE)
  if (&CAND4 == canp) {
    ram_address_pointer = CAN_SUB_0_RAM + SPC5_CAN_SUB_0_M_CAN_3_RAM_START;
    ram_size = SPC5_CAN_SUB_0_M_CAN_3_RAM_SIZE;
  }
#endif
#if (SPC5_USE_CAN_SUB_0_M_CAN_4 == TRUE)
  if (&CAND5 == canp) {
    ram_address_pointer = CAN_SUB_0_RAM + SPC5_CAN_SUB_0_M_CAN_4_RAM_START;
    ram_size = SPC5_CAN_SUB_0_M_CAN_4_RAM_SIZE;
  }
#endif
#if (SPC5_USE_CAN_SUB_1_M_CAN_0 == TRUE)
  if (&CAND6 == canp) {
    ram_address_pointer = CAN_SUB_1_RAM + SPC5_CAN_SUB_1_M_CAN_0_RAM_START;
    ram_size = SPC5_CAN_SUB_1_M_CAN_0_RAM_SIZE;
  }
#endif
#if (SPC5_USE_CAN_SUB_1_M_CAN_1 == TRUE)
  if (&CAND7 == canp) {
    ram_address_pointer = CAN_SUB_1_RAM + SPC5_CAN_SUB_1_M_CAN_1_RAM_START;
    ram_size = SPC5_CAN_SUB_1_M_CAN_1_RAM_SIZE;
  }
#endif
#if (SPC5_USE_CAN_SUB_1_M_CAN_2 == TRUE)
  if (&CAND8 == canp) {
    ram_address_pointer = CAN_SUB_1_RAM + SPC5_CAN_SUB_1_M_CAN_2_RAM_START;
    ram_size = SPC5_CAN_SUB_1_M_CAN_2_RAM_SIZE;
  }
#endif
#if (SPC5_USE_CAN_SUB_1_M_CAN_3 == TRUE)
  if (&CAND9 == canp) {
    ram_address_pointer = CAN_SUB_1_RAM + SPC5_CAN_SUB_1_M_CAN_3_RAM_START;
    ram_size = SPC5_CAN_SUB_1_M_CAN_3_RAM_SIZE;
  }
#endif
#if (SPC5_USE_CAN_SUB_1_M_CAN_4 == TRUE)
  if (&CAND10 == canp) {
    ram_address_pointer = CAN_SUB_1_RAM + SPC5_CAN_SUB_1_M_CAN_4_RAM_START;
    ram_size = SPC5_CAN_SUB_1_M_CAN_4_RAM_SIZE;
  }
#endif
  for (i = 0; i < ram_size; i += 4UL) {
    address_pointer = ram_address_pointer + i;
    *(vuint32_t*)(address_pointer) = 0x00000000UL;
  }

  /* Remove configuration */
  canp->config = NULL;

  osalExitCritical();
}

/**
 * @brief   Inserts a frame into the transmit queue.
 *
 * @param[in] canp      pointer to the @p CANDriver object
 * @param[in] ctfp      pointer to the CAN frame to be transmitted
 * @param[in] msgbuf    Tx buffer number,  @p CAN_ANY_TXBUFFER for the first free TX Buffer
 *
 * @return              operation result
 *
 * @api
 */
uint32_t can_lld_transmit(CANDriver *canp, uint32_t msgbuf, const CANTxFrame *ctfp) {

  uint32_t count;
  uint8_t txbuffer;

  txbuffer = 0xFFU;

  /* if CAN_ANY_TXBUFFER serach the first tx buffer free*/
  if (msgbuf == CAN_ANY_TXBUFFER) {
    for (count = 0; count < canp->config->num_of_tx_buffers; count++) {
      if (((canp->mcan->TXBRP.R) & (1UL << count)) == 0U) {
        txbuffer = (uint8_t)count;
        break;
      }
    }
  }
  /* else check if msgbox if free to transmit */
  else {
    if (((canp->mcan->TXBRP.R) & (1UL << msgbuf)) == 0U) {
      txbuffer = (uint8_t)msgbuf;
    }
  }
  /*if txbuffer value is not assigned No tx buffer available */
  if (txbuffer == 0xFFU) {
    return CAN_MSG_WAIT;
  }
  else {

    osalEnterCritical();

    /*Write Tx Buffer */
    can_lld_writeTxBuffer(canp, txbuffer, ctfp);

    /* send message */
    canp->mcan->TXBAR.R = (1UL << txbuffer);

  }

  osalExitCritical();

  return CAN_MSG_OK;
}

/**
 * @brief   read a frame from RX buffer/FIFO.
 *
 * @param[in] canp      pointer to the @p CANDriver object
 * @param[in] msgbuf    Rx buffer number or FIFO,  @p CAN_ANY_RXBUFFER for the first free RX Buffer
 * @param[in] crfp      pointer to the CAN frame to be read
 *
 * @return              operation result
 *
 * @api
 */
uint32_t can_lld_receive(CANDriver *canp, uint32_t msgbuf, CANRxFrame *crfp) {

  uint32_t count;
  uint8_t rxbuffer;

  rxbuffer = 0xFFU;

  if (msgbuf == CAN_ANY_RXBUFFER) {
    for (count = 0; count < canp->config->num_of_rx_buffers; count++) {
      if (((canp->mcan->NDAT1.R) & (1UL << count)) != 0U) {
        rxbuffer = (uint8_t)count;
        break;
      }
    }
  }
  else {
    if (((canp->mcan->NDAT1.R) & (1UL << msgbuf)) != 0U) {
      rxbuffer = (uint8_t)msgbuf;
    }
  }
  /*if rxbuffer value is not assigned No tx buffer available */
  if (rxbuffer == 0xFFU) {
    return CAN_MSG_WAIT;
  }
  else {
    osalEnterCritical();

    /* Read Message */
    can_lld_readRxBuffer(canp, rxbuffer, crfp);

    /* release rx buffer */
    canp->mcan->NDAT1.R = (1UL << rxbuffer);
  }

  osalExitCritical();

  return CAN_MSG_OK;
}

#endif /* LLD_USE_CAN */

/** @} */

