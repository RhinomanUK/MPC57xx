/****************************************************************************
*
* Copyright (c) 2021 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY - NOT FOR USE IN PRODUCTION
*****************************************************************************/
/**
 * @file    swirq.h
 * @brief   Software IRQ module header.
 *
 * @addtogroup SWIRQ
 * @{
 */

#ifndef _SWIRQ_H_
#define _SWIRQ_H_

#include "platform.h"

/*===========================================================================*/
/* Module constants.                                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Module macros.                                                            */
/*===========================================================================*/

/*===========================================================================*/
/* Inline functions.                                                            */
/*===========================================================================*/

/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/
#ifdef __cplusplus
extern "C" {
#endif

void swirqInit(void);
void swirq_enable(uint8_t irq, uint8_t prio, uint32_t core);
void swirq_disable(uint8_t irq);
void swirq_set(uint8_t irq);
void swirq_clear(uint8_t irq);

#ifdef __cplusplus
}
#endif

#endif /* _SWIRQ_H_ */

/** @} */
