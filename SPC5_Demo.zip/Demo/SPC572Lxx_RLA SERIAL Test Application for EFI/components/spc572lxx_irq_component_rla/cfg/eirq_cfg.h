/****************************************************************************
*
* Copyright (c) 2015-2020 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY - NOT FOR USE IN PRODUCTION
*****************************************************************************/
/**
 * @file    eirq_cfg.h
 * @brief   External Interrupt configuration and management.
 *
 * @addtogroup EIRQ
 * @{
 */ 
 
#ifndef _EIRQ_CFG_H_
#define _EIRQ_CFG_H_

/*===========================================================================*/
/* Driver constants.                                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver exported variables.                                                */
/*===========================================================================*/

/*===========================================================================*/
/* Derived constants and error checks.                                       */
/*===========================================================================*/

/*===========================================================================*/
/* Driver data structures and types.                                         */
/*===========================================================================*/

/*===========================================================================*/
/* Driver macros.                                                            */
/*===========================================================================*/

#define SPC5_EIRQ_GROUP_0_IRQ_PRIORITY      INTC_PSR_ENABLE(INTC_PSR_MAINCORE,6)
#define SPC5_EIRQ_GROUP_1_IRQ_PRIORITY      INTC_PSR_ENABLE(INTC_PSR_MAINCORE,6)

/* Interrupt groups */
#define SPC5_SIUL_EIRQ_HAS_GROUP_0          TRUE
#define SPC5_SIUL_EIRQ_HAS_GROUP_1          TRUE
#define SPC5_SIUL_EIRQ_HAS_GROUP_2          FALSE
#define SPC5_SIUL_EIRQ_HAS_GROUP_3          FALSE
 
/* Interrupt handlers and vector numbers */
#define SPC5_SIUL_EIRQ_GROUP_0_HANDLER      vector243
#define SPC5_SIUL_EIRQ_GROUP_1_HANDLER      vector244
#define SPC5_SIUL_EIRQ_GROUP_0_INT_NUMBER   243
#define SPC5_SIUL_EIRQ_GROUP_1_INT_NUMBER   244

/* Interrupt handlers and vector numbers */
#define SPC5_SIUL_EIRQ_GROUP_0_SET_PRIO()   INTC_PSR(SPC5_SIUL_EIRQ_GROUP_0_INT_NUMBER) = SPC5_EIRQ_GROUP_0_IRQ_PRIORITY
#define SPC5_SIUL_EIRQ_GROUP_1_SET_PRIO()   INTC_PSR(SPC5_SIUL_EIRQ_GROUP_1_INT_NUMBER) = SPC5_EIRQ_GROUP_1_IRQ_PRIORITY
#define SPC5_SIUL_EIRQ_GROUP_2_SET_PRIO()   
#define SPC5_SIUL_EIRQ_GROUP_3_SET_PRIO()   

/* Interrupt number (min/max) per group */
#define SPC5_SIUL_EIRQ_GROUP_0_MIN          0U
#define SPC5_SIUL_EIRQ_GROUP_0_MAX          5U
#define SPC5_SIUL_EIRQ_GROUP_1_MIN          10U
#define SPC5_SIUL_EIRQ_GROUP_1_MAX          10U


/*===========================================================================*/
/* External declarations.                                                    */
/*===========================================================================*/
#ifdef __cplusplus
extern "C" {
#endif
#ifdef __cplusplus
}
#endif

#endif /* _EIRQ_CFG_H_ */

/** @} */
