/****************************************************************************
*
* Copyright © 2017-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY – NOT FOR USE IN PRODUCTION
*****************************************************************************/

#include "board.h"
#include "clock.h"

/*
 * Initial setup of all defined pads, the list is terminated
 * by a {-1, 0, 0}.
 */
static const spc_mscr_io_init_t spc_mscr_io_init[] = {
  {(int16_t)MSCR_IO_INDEX(PORT_A, PA_LED1), PAL_LOW,    (iomode_t)(PAL_SPC5_SSS(0) | PAL_MODE_OUTPUT_PUSHPULL)},
  {(int16_t)MSCR_IO_INDEX(PORT_A, PA_LED3), PAL_LOW,    (iomode_t)(PAL_SPC5_SSS(0) | PAL_MODE_OUTPUT_PUSHPULL)},
  {(int16_t)MSCR_IO_INDEX(PORT_C, LIN0_TXD), PAL_LOW,    (iomode_t)(PAL_SPC5_SSS(6) | PAL_MODE_OUTPUT_PUSHPULL)},
  {-1, 0, 0}
};

/*
 * Initial setup of MSCR_MUX registers, the list is terminated by
 * a {0, -1, 0}.
 */
static const spc_mscr_mux_init_t spc_mscr_mux_init[] = {
  {(int16_t)MSCR_IO_INDEX(PORT_A, 11U), (int16_t)MSCR_MUX_LIN0_RXD, 2},
  {0, -1, 0}
};

/**
 * @brief   PAL setup.
 */
static const PALConfig pal_default_config = {
  spc_mscr_io_init,
  spc_mscr_mux_init
};

/*
 * Board-specific initialization code.
 */
void boardInit(void) {

  pal_init(&pal_default_config);
}
