/****************************************************************************
*
* Copyright © 2016-2019 STMicroelectronics - All Rights Reserved
*
* License terms: STMicroelectronics Proprietary in accordance with licensing
* terms SLA0089 at www.st.com.
* 
* THIS SOFTWARE IS DISTRIBUTED "AS IS," AND ALL WARRANTIES ARE DISCLAIMED, 
* INCLUDING MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*
* EVALUATION ONLY – NOT FOR USE IN PRODUCTION
*****************************************************************************/

#ifndef _BOARD_H_
#define _BOARD_H_

#include "pal.h"

/*
 * Setup for a generic SPC572Lxx board.
 */

/*
 * Board identifiers.
 */
#define BOARD_EFI
#define BOARD_NAME                  "STMicroelectronics SPC572L Generic Board"

/*
 * I/O definitions.
 */
#define PA_LED1                     1U
#define PA_LED3                     13U
#define LIN0_TXD                    2U

/*
 * MSCR_MUX definitions.
 */
#define MSCR_MUX_LIN0_RXD           336U

/*
 * Support macros.
 */
#define MSCR_IO_INDEX(port, pin)  (((port) * 16U) + (pin))

#if !defined(_FROM_ASM_)
#ifdef __cplusplus
extern "C" {
#endif
  void boardInit(void);
#ifdef __cplusplus
}
#endif
#endif /* _FROM_ASM_ */

#endif /* _BOARD_H_ */
