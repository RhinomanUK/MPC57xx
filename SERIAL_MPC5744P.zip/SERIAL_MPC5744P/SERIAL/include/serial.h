/*
 * Serial.h
 *
 *  J Holland 22nd October 2021
 *	UARTs run in FIFO mode
 *  Set Rx and Tx software buffer length in the header file
 *
 *	module clock is PBRIDGE
 *	baud rate clock is HALFSYS_CLK
 *
 *	Note: Serial0 is connected to the LIN transceiver on the MPC5744P-DEV-KIT
 *	copyright RhinoPower Ltd 2021
 */

#ifndef SERIAL_H_
#define SERIAL_H_

#include "project.h"

#define	RXBUFFERSIZE			16
// #define	RXBUFFERSIZE		32
// #define	RXBUFFERSIZE		64
// #define	RXBUFFERSIZE		128
// #define	RXBUFFERSIZE		256

// #define	TXBUFFERSIZE		16
// #define	TXBUFFERSIZE		32
// #define	TXBUFFERSIZE		64
 #define	TXBUFFERSIZE		128
// #define	TXBUFFERSIZE		256

#if RXBUFFERSIZE == 16			
	#define	RXBUFFROTATEMSK		0x0F
#elif  RXBUFFERSIZE == 32		
	#define	RXBUFROTATEMSK 		0x1F
#elif  RXBUFFERSIZE == 64
	#define	RXBUFFROTATEMSK 	0x3F
#elif  RXBUFFERSIZE == 128
	#define	RXBUFFROTATEMSK 	0x7F
#elif  RXBUFFERSIZE == 256
	#define	RXBUFFROTATEMSK 	0xFF
#else
	#error "Rx Buffer Size invalid"
#endif

#if TXBUFFERSIZE == 16
	#define	TXBUFFROTATEMSK 	0x0F
#elif TXBUFFERSIZE == 32
	#define	TXBUFFROTATEMSK 	0x1F
#elif TXBUFFERSIZE == 64
	#define	TXBUFFROTATEMSK 	0x3F
#elif TXBUFFERSIZE == 128
	#define	TXBUFFROTATEMSK 	0x7F
#elif TXBUFFERSIZE == 256
	#define	TXBUFROTATEMSK 		0xFF
#else
	#error"Tx Buffer Size invalid"
#endif


// Serial0 (UART0) functions
extern void Serial0_begin ( uint32_t BaudRate );
extern uint8_t Serial0_write( uint8_t TxData );
extern uint8_t Serial0_writeBytes( const uint8_t* TxData, uint8_t noOfBytes );
extern uint8_t Serial0_writeString( const uint8_t* TxStr );		// sends a null terminated string without the null terminator
extern uint8_t Serial0_readData( uint8_t* RxData );
extern uint8_t Serial0_available(void);
extern uint8_t Serial0_availableForWrite(void);

// Serial1 (UART1) functions
extern void Serial1_begin ( uint32_t BaudRate );
extern uint8_t Serial1_write( uint8_t TxData );
extern uint8_t Serial1_writeBytes( const uint8_t* TxData, uint8_t noOfBytes );
extern uint8_t Serial1_writeString( const uint8_t* TxStr );
extern uint8_t Serial1_read( uint8_t* RxData );
extern uint8_t Serial1_available(void);
extern uint8_t Serial1_availableForWrite(void);


#endif /* SERIAL_H_ */
