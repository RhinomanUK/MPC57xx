/*
 * Serial.c
 *
 *  J Holland 22nd October 2021
 *	UART runs in FIFO mode
 *  Set Rx and Tx software buffer length in the header file
 *	
 *	module clock is PBRIDGE
 *	baud rate clock is HALFSYS_CLK
 *
 *	Note: Serial0 is connected to the LIN transceiver on the MPC5744P-DEV-KIT
 *	copyright RhinoPower Ltd 2021
 */

#include "serial.h"
#include "project.h"				// needed for SYSTEM_CLOCK and typedefs


#define	TFF_CLR_MSK			0x00000002		// write a '1' to clear an interrupt flag
#define	RFF_CLR_MSK			0x00000004

/* UART0 declarations */
static uint8_t uart0_rxBuffer[RXBUFFERSIZE];
static uint8_t uart0_rxWrPointer = 0;
static uint8_t uart0_rxRdPointer = 0;
static uint8_t uart0_nRxBytes = 0;

static uint8_t uart0_txBuffer[TXBUFFERSIZE];
static uint8_t uart0_txWrPointer = 0;
static uint8_t uart0_txRdPointer = 0;
static uint8_t uart0_rxBufferCount = 0;
static uint8_t uart0_rxBufferOverflow = 0;
static uint8_t uart0_txBufferCount = 0;
static uint8_t uart0_txBufferFull = 0;
static uint8_t uart0_txPending = 0;

/* UART1 declarations */
static uint8_t uart1_rxBuffer[RXBUFFERSIZE];
static uint8_t uart1_rxWrPointer = 0;
static uint8_t uart1_rxRdPointer = 0;
static uint8_t uart1_nRxBytes = 0;

static uint8_t uart1_txBuffer[TXBUFFERSIZE];
static uint8_t uart1_txWrPointer = 0;
static uint8_t uart1_txRdPointer = 0;
static uint8_t uart1_rxBufferCount = 0;
static uint8_t uart1_rxBufferOverflow = 0;
static uint8_t uart1_txBufferCount = 0;
static uint8_t uart1_txBufferFull = 0;
static uint8_t uart1_txPending = 0;


// internal functions

uint8_t txLINFlexD_0( uint8_t Data );
uint8_t rxLINFlexD_0( uint8_t* RxData );
uint8_t txLINFlexD_1( uint8_t Data );
uint8_t rxLINFlexD_1( void );
uint8_t serial0_transmit( void );
uint8_t serial1_transmit( void );
uint8_t rxLINFlexD_1( void );
void	uart0_txISR( void );
void	uart0_rxISR( void);
void	uart1_txISR( void );
void	uart1_rxISR( void);


/*****************************************************************************/
/************************ SERIAL0 Functions **********************************/
/*****************************************************************************/

uint8_t Serial0_write( uint8_t TxData )
{
	uint8_t bytetoSentToBuffer = 0;
	
	if(!uart0_txBufferFull)
	{
		uart0_txBuffer[uart0_txWrPointer] = TxData;
		uart0_txWrPointer++;
		uart0_txWrPointer &= TXBUFFROTATEMSK;
		uart0_txBufferCount++;
		bytetoSentToBuffer = 1;
		if( uart0_txBufferCount == TXBUFFERSIZE)
		{
			uart0_txBufferFull = 1;
		}
		if(!uart0_txPending)					// if a transmission is in progress data will be sent from the tx_isr
		{
			serial0_transmit();					// if not start a transmission
			uart0_txPending = 1;

		}


	}
	return bytetoSentToBuffer;
}

/*****************************************************************************/

uint8_t Serial0_writeBytes( const uint8_t* TxData, uint8_t noOfBytes )
{
	uint8_t byteCount = 0;

	while( byteCount != noOfBytes )
	{
			if( Serial0_write(TxData[byteCount] ))
			{
				byteCount++;
			}
			else
			{
				byteCount = noOfBytes;		// force an exit from the while loop
			}
	}
	return noOfBytes;
}

/*****************************************************************************/

uint8_t Serial0_writeString( const uint8_t* TxStr )
{
	uint8_t byteCount = 0;

		while( TxStr[byteCount]!='\0' )
		{
			Serial1_write(TxStr[byteCount] );
			byteCount++;
		}

	return byteCount;
}

/*****************************************************************************/

uint8_t serial0_transmit( void )
{
	uint8_t byteSent = 0;

	byteSent = txLINFlexD_0( uart0_txBuffer[uart0_txRdPointer] );
	if(byteSent)
	{
		uart0_txRdPointer++;
		uart0_txRdPointer &= TXBUFFROTATEMSK;
		uart0_txBufferCount--;
		uart0_txBufferFull = 0;						// can't be full because we just made a space
	}
return byteSent;
}

/*****************************************************************************/

uint8_t Serial0_availableForWrite(void)
{
	return (TXBUFFERSIZE - uart0_txBufferCount);
}

/*****************************************************************************/
			
uint8_t Serial0_read( uint8_t* RxData )
{
	uint8_t nBytes = 0;

	if(uart0_rxBufferCount)
	{
		*RxData = uart0_rxBuffer[uart0_rxRdPointer];
		uart0_rxRdPointer++;
		uart0_rxRdPointer &= RXBUFFROTATEMSK;
		uart0_rxBufferCount--;
		nBytes = 1;
	}

	return nBytes;
}	

/*****************************************************************************/

uint8_t Serial0_readBytes( uint8_t* RxData, uint8_t noOfBytes )
{
	uint8_t byteCount = 0;
	uint8_t tmpByte;
	
	while( byteCount != noOfBytes )
	{
			if( !Serial0_read(&tmpByte) )
			{ 
				RxData[byteCount] = tmpByte;
				byteCount++;
			}
			else
			{
				byteCount = noOfBytes;		// force an exit from the while loop
			}
	}	
	return noOfBytes;
	
}

/*****************************************************************************/

uint8_t Serial0_available(void)
{
	return (uart0_rxBufferCount);
}

/*****************************************************************************/

void Serial0_begin ( uint32_t BaudRate )
{
  uint32_t Fraction;
  uint32_t Integer;

  LINFlexD_0.LINCR1.B.INIT = 1;     		/* Enter Initialization Mode */
  LINFlexD_0.LINCR1.B.SLEEP = 0;    		/* Exit Sleep Mode */
  LINFlexD_0.UARTCR.B.UART = 1;     		/* UART Enable- Req'd before UART config.*/
  LINFlexD_0.UARTCR.R = 0x0033;     		/* UART Ena, 1 byte tx, no parity, 8 data*/
  LINFlexD_0.UARTSR.B.SZF = 1;      		/* Clear the Zero status bit */
  LINFlexD_0.UARTSR.B.DRFRFE = 1;   		/* Clear DRFRFE flag - W1C */
  
  BaudRate  = HALFSYS_CLK / BaudRate; 		// UART uses HALFSYS_CLK = SYSTEM CLOCK /2;
  Integer   = BaudRate / 16;
  Fraction  = BaudRate - (Integer * 16);

  LINFlexD_0.LINIBRR.R = Integer;
  LINFlexD_0.LINFBRR.R = Fraction;

  LINFlexD_0.LINIER.B.DTIE = 1;				// enable interrupts in init mode?
  LINFlexD_0.LINIER.B.DRIE = 1;


  LINFlexD_0.LINCR1.B.INIT = 0;     		/* Exit Initialization Mode */


  /* Configure LINFlexD_0 TxD Pin. */
  SIUL2.MSCR[190].B.SSS = 1; 				// Pad PB2 IMCR = 190, LIN0 TX = 1. (LINBus on MPC5744P-DEV-KIT)
  SIUL2.MSCR[PB2].B.OBE = 1; 				// Enable output buffer
  SIUL2.MSCR[PB2].B.SRC = 3; 				// Full drive-strength without slew rate control

  /* Configure LINFlexD_0 RxD Pin. */
  SIUL2.MSCR[PB3].B.IBE = 1; 				// Pad PB3: Enable input buffer
  SIUL2.IMCR[165].B.SSS = 1; 			// PB3 IMCR = 165, LIN0_RX = 1
  
  /*Tx/Rx interrupts enable*/
  INTC_0.PSR[376].B.PRC_SELN0 = 1;  	/* Rx IRQ is sent to Core 0 (0=no request sent)*/
  INTC_0.PSR[376].B.PRIN =10;       	/* IRQ priority = 10 (15 = highest) */
  INTC_0.PSR[377].B.PRC_SELN0 = 1;  	/* Tx IRQ is sent to Core 0 (0=no request sent)*/
  INTC_0.PSR[377].B.PRIN =10;       	/* IRQ priority = 10 (15 = highest) */


}

/*************************** Internal Serial0 functions ***********************************/


uint8_t txLINFlexD_0( uint8_t Data )
{
  uint8_t nBytes = 1;

  if( !LINFlexD_0.UARTSR.B.DTFTFF )			/* if tx buffer not full */
  {
		LINFlexD_0.BDRL.B.DATA0 = Data;     /* Transmit 8 bits Data */
  }
  else
  {
		nBytes = 0;							/* no bytes sent */
  }

  return nBytes;
}

/*****************************************************************************/

void	uart0_rxISR( void )
{

	LINFlexD_0.UARTSR.R |= TFF_CLR_MSK;						// clear interrupt flag

	if(uart0_rxBufferCount == (RXBUFFERSIZE + 1))			// are we going to exceed the buffer size
	{
		uart0_rxBufferOverflow = 1;							// if yes then we will overflow
	}
	else
	{
		uart0_rxBufferOverflow = 0;
		uart0_rxBufferCount++;								// buffer count is never more than max buffer size
	}
	
	uart0_rxBuffer[uart0_rxWrPointer] = LINFlexD_0.BDRM.B.DATA4;
	uart0_rxWrPointer++;
  
}

/*****************************************************************************/

void	uart0_txISR( void )
{
	
	LINFlexD_0.UARTSR.R |= TFF_CLR_MSK;						/* Clear DTF interrupt flag */
	if( uart0_txBufferCount)								// while there is data to send
	{
		serial0_transmit();
	}
	else
	{
		uart0_txPending = 0;
	}
}


/*******************************************************************************/
/************************ SERIAL1 Functions ************************************/
/*******************************************************************************/

uint8_t Serial1_write( uint8_t TxData )
{
	uint8_t bytetoSentToBuffer = 0;
	
	if(!uart1_txBufferFull)
	{
		uart1_txBuffer[uart1_txWrPointer] = TxData;
		uart1_txWrPointer++;
		uart1_txWrPointer &= TXBUFFROTATEMSK;
		uart1_txBufferCount++;
		bytetoSentToBuffer = 1;
		if( uart1_txBufferCount == TXBUFFERSIZE)
		{
			uart1_txBufferFull = 1;
		}
		if(!uart1_txPending)					// if a transmission is in progress data will be sent from the tx_isr
		{
			serial1_transmit();					// if not start a transmission
			uart1_txPending = 1;

		}


	}
	return bytetoSentToBuffer;
}

/*****************************************************************************/

uint8_t Serial1_writeBytes( const uint8_t* TxData, uint8_t noOfBytes )
{
	uint8_t byteCount = 0;

	while( byteCount != noOfBytes )
	{
			if( Serial1_write(TxData[byteCount] ))
			{
				byteCount++;
			}
			else
			{
				byteCount = noOfBytes;		// force an exit from the while loop
			}
	}
	return noOfBytes;
}

/*****************************************************************************/

uint8_t Serial1_writeString( const uint8_t* TxStr )
{
	uint8_t byteCount = 0;

		while( TxStr[byteCount]!='\0' )
		{
			Serial1_write(TxStr[byteCount] );
			byteCount++;
		}

	return byteCount;
}

/*****************************************************************************/

uint8_t serial1_transmit( void )
{
	uint8_t byteSent = 0;

	byteSent = txLINFlexD_1( uart1_txBuffer[uart1_txRdPointer] );
	if(byteSent)
	{
		uart1_txRdPointer++;
		uart1_txRdPointer &= TXBUFFROTATEMSK;
		uart1_txBufferCount--;
		uart1_txBufferFull = 0;						// can't be full because we just made a space
	}
return byteSent;
}

/*****************************************************************************/

uint8_t Serial1_availableForWrite(void)
{
	return (TXBUFFERSIZE - uart1_txBufferCount);
}

/*****************************************************************************/
			
uint8_t Serial1_read( uint8_t* RxData )
{
	uint8_t nBytes = 0;

	if(uart1_rxBufferCount)
	{
		*RxData = uart1_rxBuffer[uart1_rxRdPointer];
		uart1_rxRdPointer++;
		uart1_rxRdPointer &= RXBUFFROTATEMSK;
		uart1_rxBufferCount--;
		nBytes = 1;
	}

	return nBytes;
}	

/*****************************************************************************/

uint8_t Serial1_readBytes( uint8_t* RxData, uint8_t noOfBytes )
{
	uint8_t byteCount = 0;
	uint8_t tmpByte;
	
	while( byteCount != noOfBytes )
	{
			if( !Serial1_read(&tmpByte) )
			{ 
				RxData[byteCount] = tmpByte;
				byteCount++;
			}
			else
			{
				byteCount = noOfBytes;		// force an exit from the while loop
			}
	}	
	return noOfBytes;
	
}

/*****************************************************************************/

uint8_t Serial1_available(void)
{
	return (uart1_rxBufferCount);
}

/*****************************************************************************/

void Serial1_begin ( uint32_t BaudRate )
{
  uint32_t Fraction;
  uint32_t Integer;

  LINFlexD_1.LINCR1.B.INIT = 1;     		/* Enter Initialization Mode */
  LINFlexD_1.LINCR1.B.SLEEP = 0;    		/* Exit Sleep Mode */
  LINFlexD_1.UARTCR.B.UART = 1;     		/* UART Enable- Req'd before UART config.*/
  LINFlexD_1.UARTCR.R = 0x0033;     		/* UART Ena, 1 byte tx, no parity, 8 data*/
  LINFlexD_1.UARTSR.B.SZF = 1;      		/* Clear the Zero status bit */
  LINFlexD_1.UARTSR.B.DRFRFE = 1;   		/* Clear DRFRFE flag - W1C */
  
  
  BaudRate  = HALFSYS_CLK / BaudRate;
  Integer   = BaudRate / 16;
  Fraction  = BaudRate - (Integer * 16);

  LINFlexD_1.LINIBRR.R = Integer;
  LINFlexD_1.LINFBRR.R = Fraction;

  LINFlexD_1.LINIER.B.DTIE = 1;				// enable interrupts in init mode
  LINFlexD_1.LINIER.B.DRIE = 1;

  LINFlexD_1.LINCR1.B.INIT = 0;     		/* Exit Initialization Mode */

  /* Configure LINFlexD_1 TxD Pin. */
  SIUL2.MSCR[57].B.SSS = 2; 				// Pad PD9 IMCR=57, LINTx = 2: Set to LINFlex_1 TxD.
  SIUL2.MSCR[PD9].B.OBE = 1; 				// Enable output buffer
  SIUL2.MSCR[PD9].B.SRC = 3; 				// Full drive-strength without slew rate control

  /* Configure LINFlexD_1 RxD Pin. */
  SIUL2.MSCR[PD12].B.IBE = 1; 				// Pad PD12: Enable input buffer
  SIUL2.IMCR[166].B.SSS = 2; 				// PD12 IMCR=93, LIN1_RX = 2
  
  /*Tx/Rx HW? interrupts enable*/
  INTC_0.PSR[380].B.PRC_SELN0 = 1;  	/* Rx IRQ sent to Core 0 */
  INTC_0.PSR[380].B.PRIN = 10;       	/* IRQ priority = 10 (15 = highest) */
  INTC_0.PSR[381].B.PRC_SELN0 = 1;  	/* Tx IRQ sent to Core 0 */
  INTC_0.PSR[381].B.PRIN = 10;       	/* IRQ priority = 10 (15 = highest) */

}


/*************************** Internal Serial1 functions ***********************************/


uint8_t txLINFlexD_1( uint8_t Data )
{
  uint8_t nBytes = 1;

  if( !LINFlexD_1.UARTSR.B.DTFTFF )			/* if tx buffer not full */
  {
		LINFlexD_1.BDRL.B.DATA0 = Data;     /* Transmit 8 bits Data */
  }
  else
  {
		nBytes = 0;							/* no bytes sent */
  }

  return nBytes;
}


/*****************************************************************************/

void	uart1_rxISR( void )
{
	LINFlexD_1.UARTSR.R |= TFF_CLR_MSK;						// clear interrupt flag

	if(uart1_rxBufferCount == (RXBUFFERSIZE + 1))			// are we going to exceed the buffer size
	{
		uart1_rxBufferOverflow = 1;							// if yes then we will overflow
	}
	else
	{
		uart1_rxBufferOverflow = 0;
		uart1_rxBufferCount++;								// buffer count is never more than max buffer size
	}
	
	uart1_rxBuffer[uart1_rxWrPointer] = LINFlexD_1.BDRM.B.DATA4;
	uart1_rxWrPointer++;
	
}

/*****************************************************************************/

void	uart1_txISR( void )
{
	LINFlexD_1.UARTSR.R |= TFF_CLR_MSK;						/* Clear DTF interrupt flag */
	if( uart1_txBufferCount)								// while there is data to send
	{
		serial1_transmit();
	}
	else
	{
		uart1_txPending = 0;
	}
}

