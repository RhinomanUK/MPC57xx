/* main.c - SERIAL example for MPC5744P-DEV-KIT

********************************************************************************
* File              main.c
* Author            James Holland
* Version           1.0
* Date              1st November 2021
 *	copyright RhinoPower Ltd 2021
********************************************************************************
* Detailed Description:
* A simple programme to demonstrate the use of the RhinoPower serial library
* sends some strings to a terminal
* receives data from the terminal
* ------------------------------------------------------------------------------
* Test HW:         DEVKIT-MPC5744P
* MCU:             MPC5744P
* Terminal:        19200, 8N1, None
* Fsys:            160 MHz PLL on 40MHz external oscillator
* Debugger:        OpenSDA
* Target:          FLASH
* EVB connection:  None
* UART RX pin:	   PD12
* UART TX pin:	   PD9
*
*******************************************************************************/

#include "project.h"
#include "serial.h"
#include "mode_entry.h"

extern void xcptn_xmpl(void);
void peri_clock_gating(void);

__attribute__ ((section(".text")))
int main(void)
{
	
	uint8_t txTestMsg1[10] = { 'L','i','s','t',' ','g','a','m','e','s'};
	uint8_t txTestMsg2[] = { "\rFALKEN's MAZE\rBLACKJACK\rGIN RUMMY\rHEARTS\rBRIDGE\rCHECKERS" };
	uint8_t txTestMsg3[] = { "\rCHESS\rPOKER\rFIGHTER COMBAT\rGUERRILLA ENGAGEMENT\rDESERT WARFARE\rAIR-TO-GROUND ACTIONS" };
	uint8_t txTestMsg4[] = { "\rTHEATERWIDE TACTICAL WARFARE\rTHEATERWIDE BIOTOXIC AND CHEMICAL WARFARE\rGLOBAL THERMONUCLEAR WAR\r" };
	static uint16_t bytesReceived = 0;
	uint8_t rxByte;
	uint8_t rxData[128];



	xcptn_xmpl ();              /* Configure and Enable Interrupts */

	peri_clock_gating();       	/* Config gating/enabling peri. clocks for modes*/
								/* Configuraiton occurs after mode transition */
	system160mhz();            	/* sysclk=160MHz, dividers configured, mode trans*/

	// initGPIO();

	Serial1_begin(19200);

	//	write a single byte
	Serial1_write( '?');

	// write an array of bytes
	Serial1_writeBytes(txTestMsg1, sizeof(txTestMsg1));

	// write some strings

	while(Serial1_availableForWrite()<60){}
	Serial1_writeString(txTestMsg2);

	while(Serial1_availableForWrite()<90){}
	Serial1_writeString(txTestMsg3);

	while(Serial1_availableForWrite()<100){}
	Serial1_writeString(txTestMsg4);

	// send a single byte
	Serial1_write('?');



	while(1)
	{
		if(Serial1_read( &rxByte ))
		{
			rxData[bytesReceived] = rxByte;
			bytesReceived++;
			if(bytesReceived == 128){				// just restart from zero if the buffer overflows
				bytesReceived = 0;
			}
		}

	}

	return 0;
}

/*****************************************************************************/
/* peri_clock_gating                                                         */
/* Description: Configures enabling clocks to peri modules or gating them off*/
/*              Default PCTL[RUN_CFG]=0, so by default RUN_PC[0] is selected.*/
/*              RUN_PC[0] is configured here to gate off all clocks.         */
/*****************************************************************************/

void peri_clock_gating (void) {
  MC_ME.RUN_PC[0].R = 0x00000000;  /* gate off clock for all RUN modes */
  MC_ME.RUN_PC[1].R = 0x000000FE;  /* config. peri clock for all RUN modes */

  MC_ME.PCTL91.B.RUN_CFG = 0x1; 	//LINFlexD_1: Select peripheral config RUN_PC[1]. No LINFlex_D_2 on Panther
}
